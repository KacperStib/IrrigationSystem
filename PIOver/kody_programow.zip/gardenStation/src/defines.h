// pinout
#define VALVE1 5
#define VALVE2 6
#define VALVE3 7
#define VALVE4 10
#define RAIN_SENSOR 0

// in minutes
#define WATERING_TIME 10
#define RAIN_DELAY 480 // 8 hours