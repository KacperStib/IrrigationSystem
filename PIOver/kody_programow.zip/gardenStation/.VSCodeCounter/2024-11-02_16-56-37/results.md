# Summary

Date : 2024-11-02 16:56:37

Directory c:\\Users\\Janek\\Desktop\\inz\\ArduinoPrototype\\PIOver\\gardenStation\\src

Total : 4 files,  138 codes, 19 comments, 30 blanks, all 187 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C++ | 4 | 138 | 19 | 30 | 187 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 4 | 138 | 19 | 30 | 187 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)