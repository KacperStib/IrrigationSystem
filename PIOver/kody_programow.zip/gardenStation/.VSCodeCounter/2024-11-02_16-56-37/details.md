# Details

Date : 2024-11-02 16:56:37

Directory c:\\Users\\Janek\\Desktop\\inz\\ArduinoPrototype\\PIOver\\gardenStation\\src

Total : 4 files,  138 codes, 19 comments, 30 blanks, all 187 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [gardenStation/src/defines.h](/gardenStation/src/defines.h) | C++ | 7 | 2 | 1 | 10 |
| [gardenStation/src/espnow_simplified.cpp](/gardenStation/src/espnow_simplified.cpp) | C++ | 24 | 5 | 7 | 36 |
| [gardenStation/src/espnow_simplified.h](/gardenStation/src/espnow_simplified.h) | C++ | 19 | 1 | 5 | 25 |
| [gardenStation/src/main.cpp](/gardenStation/src/main.cpp) | C++ | 88 | 11 | 17 | 116 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)