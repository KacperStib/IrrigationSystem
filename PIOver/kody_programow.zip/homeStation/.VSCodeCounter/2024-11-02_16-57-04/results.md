# Summary

Date : 2024-11-02 16:57:04

Directory c:\\Users\\Janek\\Desktop\\inz\\ArduinoPrototype\\PIOver\\homeStation\\src

Total : 23 files,  1444 codes, 122 comments, 423 blanks, all 1989 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C | 7 | 821 | 41 | 241 | 1,103 |
| C++ | 16 | 623 | 81 | 182 | 886 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 23 | 1,444 | 122 | 423 | 1,989 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)