# Diff Details

Date : 2024-11-02 16:57:04

Directory c:\\Users\\Janek\\Desktop\\inz\\ArduinoPrototype\\PIOver\\homeStation\\src

Total : 1627 files,  -747485 codes, -57139 comments, -52390 blanks, all -857014 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [homeStation/lib/Bonezegei_DS1307/README.md](/homeStation/lib/Bonezegei_DS1307/README.md) | Markdown | -8 | 0 | -6 | -14 |
| [homeStation/lib/Bonezegei_DS1307/examples/getTimeandDate/getTimeandDate.ino](/homeStation/lib/Bonezegei_DS1307/examples/getTimeandDate/getTimeandDate.ino) | C++ | -20 | -5 | -10 | -35 |
| [homeStation/lib/Bonezegei_DS1307/examples/setTimeAndDate/setTimeAndDate.ino](/homeStation/lib/Bonezegei_DS1307/examples/setTimeAndDate/setTimeAndDate.ino) | C++ | -24 | -5 | -10 | -39 |
| [homeStation/lib/Bonezegei_DS1307/library.properties](/homeStation/lib/Bonezegei_DS1307/library.properties) | Java Properties | -10 | 0 | -1 | -11 |
| [homeStation/lib/Bonezegei_DS1307/src/Bonezegei_DS1307.cpp](/homeStation/lib/Bonezegei_DS1307/src/Bonezegei_DS1307.cpp) | C++ | -169 | -9 | -32 | -210 |
| [homeStation/lib/Bonezegei_DS1307/src/Bonezegei_DS1307.h](/homeStation/lib/Bonezegei_DS1307/src/Bonezegei_DS1307.h) | C++ | -40 | -6 | -10 | -56 |
| [homeStation/lib/CompileTime/README.md](/homeStation/lib/CompileTime/README.md) | Markdown | -32 | 0 | -11 | -43 |
| [homeStation/lib/CompileTime/examples/CompileTime/CompileTime.ino](/homeStation/lib/CompileTime/examples/CompileTime/CompileTime.ino) | C++ | -27 | -10 | -7 | -44 |
| [homeStation/lib/CompileTime/library.properties](/homeStation/lib/CompileTime/library.properties) | Java Properties | -10 | 0 | -1 | -11 |
| [homeStation/lib/CompileTime/src/CompileTime.cpp](/homeStation/lib/CompileTime/src/CompileTime.cpp) | C++ | -142 | -17 | -29 | -188 |
| [homeStation/lib/CompileTime/src/CompileTime.h](/homeStation/lib/CompileTime/src/CompileTime.h) | C++ | -14 | -9 | -7 | -30 |
| [homeStation/lib/TFT_eSPI/CMakeLists.txt](/homeStation/lib/TFT_eSPI/CMakeLists.txt) | CMake | -3 | 0 | -1 | -4 |
| [homeStation/lib/TFT_eSPI/Extensions/Button.cpp](/homeStation/lib/TFT_eSPI/Extensions/Button.cpp) | C++ | -86 | -8 | -14 | -108 |
| [homeStation/lib/TFT_eSPI/Extensions/Button.h](/homeStation/lib/TFT_eSPI/Extensions/Button.h) | C++ | -27 | -10 | -8 | -45 |
| [homeStation/lib/TFT_eSPI/Extensions/Smooth_font.cpp](/homeStation/lib/TFT_eSPI/Extensions/Smooth_font.cpp) | C++ | -362 | -141 | -80 | -583 |
| [homeStation/lib/TFT_eSPI/Extensions/Smooth_font.h](/homeStation/lib/TFT_eSPI/Extensions/Smooth_font.h) | C++ | -42 | -5 | -15 | -62 |
| [homeStation/lib/TFT_eSPI/Extensions/Sprite.cpp](/homeStation/lib/TFT_eSPI/Extensions/Sprite.cpp) | C++ | -1,921 | -380 | -398 | -2,699 |
| [homeStation/lib/TFT_eSPI/Extensions/Sprite.h](/homeStation/lib/TFT_eSPI/Extensions/Sprite.h) | C++ | -80 | -64 | -45 | -189 |
| [homeStation/lib/TFT_eSPI/Extensions/Touch.cpp](/homeStation/lib/TFT_eSPI/Extensions/Touch.cpp) | C++ | -219 | -66 | -65 | -350 |
| [homeStation/lib/TFT_eSPI/Extensions/Touch.h](/homeStation/lib/TFT_eSPI/Extensions/Touch.h) | C++ | -17 | -18 | -8 | -43 |
| [homeStation/lib/TFT_eSPI/Fonts/Custom/Orbitron_Light_24.h](/homeStation/lib/TFT_eSPI/Fonts/Custom/Orbitron_Light_24.h) | C++ | -194 | -4 | -2 | -200 |
| [homeStation/lib/TFT_eSPI/Fonts/Custom/Orbitron_Light_32.h](/homeStation/lib/TFT_eSPI/Fonts/Custom/Orbitron_Light_32.h) | C++ | -194 | -4 | -2 | -200 |
| [homeStation/lib/TFT_eSPI/Fonts/Custom/Roboto_Thin_24.h](/homeStation/lib/TFT_eSPI/Fonts/Custom/Roboto_Thin_24.h) | C++ | -194 | -4 | -2 | -200 |
| [homeStation/lib/TFT_eSPI/Fonts/Custom/Satisfy_24.h](/homeStation/lib/TFT_eSPI/Fonts/Custom/Satisfy_24.h) | C++ | -194 | -4 | -2 | -200 |
| [homeStation/lib/TFT_eSPI/Fonts/Custom/Yellowtail_32.h](/homeStation/lib/TFT_eSPI/Fonts/Custom/Yellowtail_32.h) | C++ | -194 | -4 | -2 | -200 |
| [homeStation/lib/TFT_eSPI/Fonts/Font16.c](/homeStation/lib/TFT_eSPI/Fonts/Font16.c) | C | -528 | -7 | -98 | -633 |
| [homeStation/lib/TFT_eSPI/Fonts/Font16.h](/homeStation/lib/TFT_eSPI/Fonts/Font16.h) | C++ | -8 | 0 | -3 | -11 |
| [homeStation/lib/TFT_eSPI/Fonts/Font32rle.c](/homeStation/lib/TFT_eSPI/Fonts/Font32rle.c) | C | -956 | -10 | -100 | -1,066 |
| [homeStation/lib/TFT_eSPI/Fonts/Font32rle.h](/homeStation/lib/TFT_eSPI/Fonts/Font32rle.h) | C++ | -8 | 0 | -3 | -11 |
| [homeStation/lib/TFT_eSPI/Fonts/Font64rle.c](/homeStation/lib/TFT_eSPI/Fonts/Font64rle.c) | C | -273 | -7 | -20 | -300 |
| [homeStation/lib/TFT_eSPI/Fonts/Font64rle.h](/homeStation/lib/TFT_eSPI/Fonts/Font64rle.h) | C++ | -8 | 0 | -3 | -11 |
| [homeStation/lib/TFT_eSPI/Fonts/Font72rle.c](/homeStation/lib/TFT_eSPI/Fonts/Font72rle.c) | C | -344 | -8 | -18 | -370 |
| [homeStation/lib/TFT_eSPI/Fonts/Font72rle.h](/homeStation/lib/TFT_eSPI/Fonts/Font72rle.h) | C++ | -8 | 0 | -3 | -11 |
| [homeStation/lib/TFT_eSPI/Fonts/Font72x53rle.c](/homeStation/lib/TFT_eSPI/Fonts/Font72x53rle.c) | C | -218 | -9 | -19 | -246 |
| [homeStation/lib/TFT_eSPI/Fonts/Font72x53rle.h](/homeStation/lib/TFT_eSPI/Fonts/Font72x53rle.h) | C++ | -8 | 0 | -3 | -11 |
| [homeStation/lib/TFT_eSPI/Fonts/Font7srle.c](/homeStation/lib/TFT_eSPI/Fonts/Font7srle.c) | C | -240 | -9 | -18 | -267 |
| [homeStation/lib/TFT_eSPI/Fonts/Font7srle.h](/homeStation/lib/TFT_eSPI/Fonts/Font7srle.h) | C++ | -8 | 0 | -3 | -11 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMono12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMono12pt7b.h) | C++ | -223 | -1 | -4 | -228 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMono18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMono18pt7b.h) | C++ | -359 | -1 | -4 | -364 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMono24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMono24pt7b.h) | C++ | -573 | -1 | -4 | -578 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMono9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMono9pt7b.h) | C++ | -172 | -1 | -4 | -177 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBold12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBold12pt7b.h) | C++ | -246 | -1 | -4 | -251 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBold18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBold18pt7b.h) | C++ | -419 | -1 | -4 | -424 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBold24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBold24pt7b.h) | C++ | -668 | -1 | -4 | -673 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBold9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBold9pt7b.h) | C++ | -185 | -1 | -4 | -190 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBoldOblique12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBoldOblique12pt7b.h) | C++ | -265 | -1 | -4 | -270 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBoldOblique18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBoldOblique18pt7b.h) | C++ | -456 | -1 | -4 | -461 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBoldOblique24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBoldOblique24pt7b.h) | C++ | -738 | -1 | -4 | -743 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBoldOblique9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoBoldOblique9pt7b.h) | C++ | -199 | -1 | -4 | -204 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoOblique12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoOblique12pt7b.h) | C++ | -244 | -1 | -4 | -249 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoOblique18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoOblique18pt7b.h) | C++ | -394 | -1 | -4 | -399 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoOblique24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoOblique24pt7b.h) | C++ | -639 | -1 | -4 | -644 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoOblique9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeMonoOblique9pt7b.h) | C++ | -183 | -1 | -4 | -188 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSans12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSans12pt7b.h) | C++ | -266 | -1 | -4 | -271 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSans18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSans18pt7b.h) | C++ | -448 | -1 | -4 | -453 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSans24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSans24pt7b.h) | C++ | -723 | -1 | -4 | -728 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSans9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSans9pt7b.h) | C++ | -197 | -1 | -4 | -202 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBold12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBold12pt7b.h) | C++ | -284 | -1 | -4 | -289 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBold18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBold18pt7b.h) | C++ | -477 | -1 | -4 | -482 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBold24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBold24pt7b.h) | C++ | -780 | -1 | -4 | -785 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBold9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBold9pt7b.h) | C++ | -204 | -1 | -4 | -209 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBoldOblique12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBoldOblique12pt7b.h) | C++ | -313 | -1 | -4 | -318 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBoldOblique18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBoldOblique18pt7b.h) | C++ | -541 | -1 | -4 | -546 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBoldOblique24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBoldOblique24pt7b.h) | C++ | -889 | -1 | -4 | -894 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBoldOblique9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansBoldOblique9pt7b.h) | C++ | -223 | -1 | -4 | -228 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansOblique12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansOblique12pt7b.h) | C++ | -298 | -1 | -4 | -303 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansOblique18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansOblique18pt7b.h) | C++ | -514 | -1 | -4 | -519 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansOblique24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansOblique24pt7b.h) | C++ | -836 | -1 | -4 | -841 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansOblique9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSansOblique9pt7b.h) | C++ | -216 | -1 | -4 | -221 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerif12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerif12pt7b.h) | C++ | -255 | -1 | -4 | -260 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerif18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerif18pt7b.h) | C++ | -425 | -1 | -4 | -430 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerif24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerif24pt7b.h) | C++ | -686 | -1 | -4 | -691 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerif9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerif9pt7b.h) | C++ | -191 | -1 | -4 | -196 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBold12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBold12pt7b.h) | C++ | -267 | -1 | -4 | -272 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBold18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBold18pt7b.h) | C++ | -458 | -1 | -4 | -463 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBold24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBold24pt7b.h) | C++ | -755 | -1 | -4 | -760 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBold9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBold9pt7b.h) | C++ | -198 | -1 | -4 | -203 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBoldItalic12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBoldItalic12pt7b.h) | C++ | -288 | -1 | -4 | -293 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBoldItalic18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBoldItalic18pt7b.h) | C++ | -496 | -1 | -4 | -501 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBoldItalic24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBoldItalic24pt7b.h) | C++ | -789 | -1 | -4 | -794 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBoldItalic9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifBoldItalic9pt7b.h) | C++ | -211 | -1 | -4 | -216 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifItalic12pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifItalic12pt7b.h) | C++ | -267 | -1 | -4 | -272 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifItalic18pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifItalic18pt7b.h) | C++ | -446 | -1 | -4 | -451 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifItalic24pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifItalic24pt7b.h) | C++ | -733 | -1 | -4 | -738 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifItalic9pt7b.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/FreeSerifItalic9pt7b.h) | C++ | -198 | -1 | -4 | -203 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/TomThumb.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/TomThumb.h) | C++ | -421 | -48 | -6 | -475 |
| [homeStation/lib/TFT_eSPI/Fonts/GFXFF/gfxfont.h](/homeStation/lib/TFT_eSPI/Fonts/GFXFF/gfxfont.h) | C++ | -66 | -9 | -21 | -96 |
| [homeStation/lib/TFT_eSPI/Fonts/glcdfont.c](/homeStation/lib/TFT_eSPI/Fonts/glcdfont.c) | C | -261 | -2 | -5 | -268 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32.c](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32.c) | C | -542 | -202 | -111 | -855 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32.h](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32.h) | C++ | -355 | -153 | -84 | -592 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32_C3.c](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32_C3.c) | C | -555 | -199 | -108 | -862 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32_C3.h](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32_C3.h) | C++ | -362 | -153 | -84 | -599 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32_S3.c](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32_S3.c) | C | -575 | -213 | -111 | -899 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32_S3.h](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP32_S3.h) | C++ | -400 | -127 | -86 | -613 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP8266.c](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP8266.c) | C | -283 | -100 | -65 | -448 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP8266.h](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_ESP8266.h) | C++ | -148 | -55 | -43 | -246 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_Generic.c](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_Generic.c) | C | -122 | -97 | -45 | -264 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_Generic.h](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_Generic.h) | C++ | -104 | -51 | -34 | -189 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_RP2040.c](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_RP2040.c) | C | -401 | -210 | -108 | -719 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_RP2040.h](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_RP2040.h) | C++ | -297 | -102 | -101 | -500 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_STM32.c](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_STM32.c) | C | -432 | -180 | -85 | -697 |
| [homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_STM32.h](/homeStation/lib/TFT_eSPI/Processors/TFT_eSPI_STM32.h) | C++ | -723 | -213 | -144 | -1,080 |
| [homeStation/lib/TFT_eSPI/Processors/pio_16bit_parallel.pio.h](/homeStation/lib/TFT_eSPI/Processors/pio_16bit_parallel.pio.h) | C++ | -46 | -9 | -8 | -63 |
| [homeStation/lib/TFT_eSPI/Processors/pio_8bit_parallel.pio.h](/homeStation/lib/TFT_eSPI/Processors/pio_8bit_parallel.pio.h) | C++ | -53 | -9 | -9 | -71 |
| [homeStation/lib/TFT_eSPI/Processors/pio_8bit_parallel_18bpp.pio.h](/homeStation/lib/TFT_eSPI/Processors/pio_8bit_parallel_18bpp.pio.h) | C++ | -57 | -8 | -9 | -74 |
| [homeStation/lib/TFT_eSPI/Processors/pio_SPI.pio.h](/homeStation/lib/TFT_eSPI/Processors/pio_SPI.pio.h) | C++ | -57 | -9 | -9 | -75 |
| [homeStation/lib/TFT_eSPI/Processors/pio_SPI_18bit.pio.h](/homeStation/lib/TFT_eSPI/Processors/pio_SPI_18bit.pio.h) | C++ | -57 | -9 | -9 | -75 |
| [homeStation/lib/TFT_eSPI/README.md](/homeStation/lib/TFT_eSPI/README.md) | Markdown | -135 | 0 | -93 | -228 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/EPD_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/EPD_Defines.h) | C++ | -20 | -1 | -7 | -28 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/GC9A01_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/GC9A01_Defines.h) | C++ | -28 | -4 | -9 | -41 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/GC9A01_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/GC9A01_Init.h) | C++ | -186 | -1 | -46 | -233 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/GC9A01_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/GC9A01_Rotation.h) | C++ | -52 | -1 | -4 | -57 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357B_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357B_Defines.h) | C++ | -35 | -4 | -14 | -53 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357B_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357B_Init.h) | C++ | -51 | -7 | -19 | -77 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357B_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357B_Rotation.h) | C++ | -44 | -1 | -2 | -47 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357C_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357C_Defines.h) | C++ | -35 | -4 | -14 | -53 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357C_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357C_Init.h) | C++ | -77 | -14 | -26 | -117 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357C_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357C_Rotation.h) | C++ | -44 | -1 | -2 | -47 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357D_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357D_Defines.h) | C++ | -67 | -4 | -26 | -97 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357D_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357D_Init.h) | C++ | -86 | -10 | -23 | -119 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357D_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/HX8357D_Rotation.h) | C++ | -24 | -1 | -2 | -27 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9163_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9163_Defines.h) | C++ | -48 | -6 | -12 | -66 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9163_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9163_Init.h) | C++ | -30 | -7 | -4 | -41 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9163_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9163_Rotation.h) | C++ | -40 | -1 | -4 | -45 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9225_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9225_Defines.h) | C++ | -66 | -6 | -13 | -85 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9225_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9225_Init.h) | C++ | -90 | -2 | -13 | -105 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9225_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9225_Rotation.h) | C++ | -35 | -1 | -4 | -40 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9341_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9341_Defines.h) | C++ | -112 | -7 | -25 | -144 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9341_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9341_Init.h) | C++ | -195 | -5 | -48 | -248 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9341_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9341_Rotation.h) | C++ | -76 | -2 | -5 | -83 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9481_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9481_Defines.h) | C++ | -26 | -4 | -13 | -43 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9481_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9481_Init.h) | C++ | -550 | -40 | -146 | -736 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9481_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9481_Rotation.h) | C++ | -24 | -1 | -2 | -27 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9486_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9486_Defines.h) | C++ | -46 | -7 | -12 | -65 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9486_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9486_Init.h) | C++ | -66 | -6 | -13 | -85 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9486_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9486_Rotation.h) | C++ | -44 | -1 | -3 | -48 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9488_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9488_Defines.h) | C++ | -26 | -4 | -13 | -43 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9488_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9488_Init.h) | C++ | -70 | -7 | -23 | -100 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9488_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ILI9488_Rotation.h) | C++ | -24 | -1 | -2 | -27 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/R61581_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/R61581_Defines.h) | C++ | -26 | -4 | -13 | -43 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/R61581_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/R61581_Init.h) | C++ | -53 | -7 | -21 | -81 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/R61581_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/R61581_Rotation.h) | C++ | -24 | -1 | -2 | -27 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/RM68120_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/RM68120_Defines.h) | C++ | -36 | -6 | -11 | -53 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/RM68120_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/RM68120_Init.h) | C++ | -228 | -31 | -11 | -270 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/RM68120_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/RM68120_Rotation.h) | C++ | -25 | -1 | -3 | -29 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/RM68140_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/RM68140_Defines.h) | C++ | -26 | -4 | -13 | -43 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/RM68140_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/RM68140_Init.h) | C++ | -51 | -7 | -20 | -78 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/RM68140_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/RM68140_Rotation.h) | C++ | -40 | -1 | -4 | -45 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/S6D02A1_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/S6D02A1_Defines.h) | C++ | -41 | -6 | -12 | -59 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/S6D02A1_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/S6D02A1_Init.h) | C++ | -36 | -7 | -5 | -48 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/S6D02A1_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/S6D02A1_Rotation.h) | C++ | -24 | -1 | -4 | -29 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1351_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1351_Defines.h) | C++ | -16 | -2 | -3 | -21 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1351_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1351_Init.h) | C++ | -35 | 0 | -1 | -36 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1351_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1351_Rotation.h) | C++ | -28 | -1 | -6 | -35 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1963_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1963_Defines.h) | C++ | -45 | -5 | -10 | -60 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1963_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1963_Init.h) | C++ | -300 | -2 | -96 | -398 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1963_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/SSD1963_Rotation.h) | C++ | -24 | -1 | -5 | -30 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7735_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7735_Defines.h) | C++ | -135 | -9 | -36 | -180 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7735_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7735_Init.h) | C++ | -199 | -9 | -11 | -219 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7735_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7735_Rotation.h) | C++ | -128 | -1 | -4 | -133 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_2_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_2_Defines.h) | C++ | -147 | -9 | -23 | -179 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_2_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_2_Init.h) | C++ | -15 | -3 | -4 | -22 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_2_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_2_Rotation.h) | C++ | -132 | -1 | -8 | -141 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_Defines.h) | C++ | -145 | -9 | -22 | -176 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_Init.h) | C++ | -168 | -23 | -47 | -238 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7789_Rotation.h) | C++ | -132 | -1 | -8 | -141 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7796_Defines.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7796_Defines.h) | C++ | -82 | -4 | -22 | -108 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7796_Init.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7796_Init.h) | C++ | -77 | -6 | -24 | -107 |
| [homeStation/lib/TFT_eSPI/TFT_Drivers/ST7796_Rotation.h](/homeStation/lib/TFT_eSPI/TFT_Drivers/ST7796_Rotation.h) | C++ | -72 | -2 | -5 | -79 |
| [homeStation/lib/TFT_eSPI/TFT_config.h](/homeStation/lib/TFT_eSPI/TFT_config.h) | C++ | -222 | -43 | -56 | -321 |
| [homeStation/lib/TFT_eSPI/TFT_eSPI.cpp](/homeStation/lib/TFT_eSPI/TFT_eSPI.cpp) | C++ | -4,097 | -1,025 | -1,037 | -6,159 |
| [homeStation/lib/TFT_eSPI/TFT_eSPI.h](/homeStation/lib/TFT_eSPI/TFT_eSPI.h) | C++ | -574 | -255 | -183 | -1,012 |
| [homeStation/lib/TFT_eSPI/Tools/Create_Smooth_Font/Create_font/FontFiles/Final-Frontier28.h](/homeStation/lib/TFT_eSPI/Tools/Create_Smooth_Font/Create_font/FontFiles/Final-Frontier28.h) | C++ | -1,587 | 0 | -2 | -1,589 |
| [homeStation/lib/TFT_eSPI/Tools/bmp2array4bit/README.md](/homeStation/lib/TFT_eSPI/Tools/bmp2array4bit/README.md) | Markdown | -18 | 0 | -9 | -27 |
| [homeStation/lib/TFT_eSPI/Tools/bmp2array4bit/bmp2array4bit.py](/homeStation/lib/TFT_eSPI/Tools/bmp2array4bit/bmp2array4bit.py) | Python | -162 | -30 | -60 | -252 |
| [homeStation/lib/TFT_eSPI/User_Setup.h](/homeStation/lib/TFT_eSPI/User_Setup.h) | C++ | -20 | -289 | -81 | -390 |
| [homeStation/lib/TFT_eSPI/User_Setup_Select.h](/homeStation/lib/TFT_eSPI/User_Setup_Select.h) | C++ | -118 | -131 | -56 | -305 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup0_Sprite.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup0_Sprite.h) | C++ | -24 | -12 | -12 | -48 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup100_RP2040_ILI9488_parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup100_RP2040_ILI9488_parallel.h) | C++ | -22 | -21 | -11 | -54 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup101_RP2040_ILI9481_parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup101_RP2040_ILI9481_parallel.h) | C++ | -22 | -21 | -11 | -54 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup102_RP2040_ILI9341_parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup102_RP2040_ILI9341_parallel.h) | C++ | -22 | -21 | -11 | -54 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup103_RP2040_ILI9486_parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup103_RP2040_ILI9486_parallel.h) | C++ | -22 | -21 | -11 | -54 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup104_RP2040_ST7796_parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup104_RP2040_ST7796_parallel.h) | C++ | -22 | -21 | -11 | -54 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup105_RP2040_ST7796_16bit_parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup105_RP2040_ST7796_16bit_parallel.h) | C++ | -30 | -19 | -11 | -60 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup106_RP2040_ILI9481_16bit_parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup106_RP2040_ILI9481_16bit_parallel.h) | C++ | -31 | -36 | -10 | -77 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup107_RP2040_ILI9341_16bit_parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup107_RP2040_ILI9341_16bit_parallel.h) | C++ | -31 | -25 | -9 | -65 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup108_RP2040_ST7735.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup108_RP2040_ST7735.h) | C++ | -22 | -15 | -7 | -44 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup10_RPi_touch_ILI9486.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup10_RPi_touch_ILI9486.h) | C++ | -17 | -5 | -12 | -34 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup11_RPi_touch_ILI9486.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup11_RPi_touch_ILI9486.h) | C++ | -20 | -3 | -10 | -33 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup12_M5Stack_Basic_Core.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup12_M5Stack_Basic_Core.h) | C++ | -20 | -3 | -10 | -33 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup135_ST7789.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup135_ST7789.h) | C++ | -19 | -22 | -16 | -57 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup136_LilyGo_TTV.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup136_LilyGo_TTV.h) | C++ | -19 | -6 | -10 | -35 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup137_LilyGo_TDisplay_RP2040.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup137_LilyGo_TDisplay_RP2040.h) | C++ | -21 | -5 | -8 | -34 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup138_Pico_Explorer_Base_RP2040_ST7789.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup138_Pico_Explorer_Base_RP2040_ST7789.h) | C++ | -21 | -3 | -9 | -33 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup13_ILI9481_Parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup13_ILI9481_Parallel.h) | C++ | -24 | -2 | -11 | -37 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup14_ILI9341_Parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup14_ILI9341_Parallel.h) | C++ | -24 | -2 | -11 | -37 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup15_HX8357D.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup15_HX8357D.h) | C++ | -16 | -9 | -12 | -37 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup16_ILI9488_Parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup16_ILI9488_Parallel.h) | C++ | -24 | -2 | -11 | -37 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup17_ePaper.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup17_ePaper.h) | C++ | -13 | 0 | -4 | -17 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup18_ST7789.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup18_ST7789.h) | C++ | -14 | -16 | -16 | -46 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup19_RM68140_Parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup19_RM68140_Parallel.h) | C++ | -24 | -2 | -11 | -37 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup1_ILI9341.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup1_ILI9341.h) | C++ | -16 | -5 | -14 | -35 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup200_GC9A01.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup200_GC9A01.h) | C++ | -18 | -5 | -9 | -32 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup201_WT32_SC01.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup201_WT32_SC01.h) | C++ | -23 | -16 | -11 | -50 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup202_SSD1351_128.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup202_SSD1351_128.h) | C++ | -25 | -17 | -11 | -53 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup203_ST7789.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup203_ST7789.h) | C++ | -19 | -22 | -16 | -57 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup204_ESP32_TouchDown.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup204_ESP32_TouchDown.h) | C++ | -22 | -2 | -8 | -32 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup205_ESP32_TouchDown_S3.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup205_ESP32_TouchDown_S3.h) | C++ | -25 | -2 | -9 | -36 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup206_LilyGo_T_Display_S3.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup206_LilyGo_T_Display_S3.h) | C++ | -32 | -3 | -13 | -48 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup207_LilyGo_T_HMI.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup207_LilyGo_T_HMI.h) | C++ | -30 | -6 | -13 | -49 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup209_LilyGo_T_Dongle_S3.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup209_LilyGo_T_Dongle_S3.h) | C++ | -23 | -16 | -13 | -52 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup20_ILI9488.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup20_ILI9488.h) | C++ | -18 | -44 | -9 | -71 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup210_LilyGo_T_Embed_S3.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup210_LilyGo_T_Embed_S3.h) | C++ | -24 | -7 | -12 | -43 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup211_LilyGo_T_QT_Pro_S3.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup211_LilyGo_T_QT_Pro_S3.h) | C++ | -24 | -8 | -13 | -45 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup212_LilyGo_T_PicoPro.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup212_LilyGo_T_PicoPro.h) | C++ | -26 | -5 | -14 | -45 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup213_LilyGo_T_Beam_Shield.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup213_LilyGo_T_Beam_Shield.h) | C++ | -24 | -3 | -10 | -37 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup21_ILI9488.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup21_ILI9488.h) | C++ | -19 | -6 | -11 | -36 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup22_TTGO_T4.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup22_TTGO_T4.h) | C++ | -20 | -5 | -12 | -37 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup22_TTGO_T4_v1.3.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup22_TTGO_T4_v1.3.h) | C++ | -21 | -3 | -11 | -35 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup23_TTGO_TM.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup23_TTGO_TM.h) | C++ | -24 | -6 | -14 | -44 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup24_ST7789.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup24_ST7789.h) | C++ | -18 | -22 | -15 | -55 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup250_ESP32_S3_Box_Lite.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup250_ESP32_S3_Box_Lite.h) | C++ | -22 | -1 | -10 | -33 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup251_ESP32_S3_Box.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup251_ESP32_S3_Box.h) | C++ | -20 | -1 | -8 | -29 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup25_TTGO_T_Display.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup25_TTGO_T_Display.h) | C++ | -23 | -4 | -14 | -41 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup26_TTGO_T_Wristband.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup26_TTGO_T_Wristband.h) | C++ | -22 | -5 | -11 | -38 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup27_RPi_ST7796_ESP32.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup27_RPi_ST7796_ESP32.h) | C++ | -20 | -60 | -23 | -103 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup28_RPi_ST7796_ESP8266.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup28_RPi_ST7796_ESP8266.h) | C++ | -18 | -63 | -26 | -107 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup29_ILI9341_STM32.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup29_ILI9341_STM32.h) | C++ | -19 | -54 | -24 | -97 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup29b_ILI9341_STM32.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup29b_ILI9341_STM32.h) | C++ | -24 | -100 | -17 | -141 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup2_ST7735.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup2_ST7735.h) | C++ | -18 | -11 | -17 | -46 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup301_BW16_ST7735.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup301_BW16_ST7735.h) | C++ | -22 | -9 | -17 | -48 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup302_Waveshare_ESP32S3_GC9A01.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup302_Waveshare_ESP32S3_GC9A01.h) | C++ | -23 | -2 | -8 | -33 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup30_ILI9341_Parallel_STM32.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup30_ILI9341_Parallel_STM32.h) | C++ | -26 | -16 | -12 | -54 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup31_ST7796_Parallel_STM32.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup31_ST7796_Parallel_STM32.h) | C++ | -26 | -16 | -11 | -53 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup32_ILI9341_STM32F103.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup32_ILI9341_STM32F103.h) | C++ | -18 | -29 | -15 | -62 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup33_RPi_ILI9486_STM32.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup33_RPi_ILI9486_STM32.h) | C++ | -17 | -32 | -19 | -68 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup34_ILI9481_Parallel_STM32.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup34_ILI9481_Parallel_STM32.h) | C++ | -26 | -16 | -10 | -52 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup35_ILI9341_STM32_Port_Bus.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup35_ILI9341_STM32_Port_Bus.h) | C++ | -29 | -19 | -12 | -60 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup36_RPi_touch_ST7796.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup36_RPi_touch_ST7796.h) | C++ | -20 | -2 | -11 | -33 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup3_ILI9163.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup3_ILI9163.h) | C++ | -17 | -7 | -14 | -38 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup42_ILI9341_ESP32.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup42_ILI9341_ESP32.h) | C++ | -19 | -9 | -9 | -37 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup43_ST7735.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup43_ST7735.h) | C++ | -26 | -14 | -13 | -53 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup44_TTGO_CameraPlus.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup44_TTGO_CameraPlus.h) | C++ | -20 | -6 | -7 | -33 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup45_TTGO_T_Watch.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup45_TTGO_T_Watch.h) | C++ | -18 | -6 | -9 | -33 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup46_GC9A01_ESP32.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup46_GC9A01_ESP32.h) | C++ | -19 | -3 | -7 | -29 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup47_ST7735.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup47_ST7735.h) | C++ | -22 | -17 | -13 | -52 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup4_S6D02A1.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup4_S6D02A1.h) | C++ | -15 | -7 | -12 | -34 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup50_SSD1963_Parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup50_SSD1963_Parallel.h) | C++ | -25 | -52 | -19 | -96 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup51_LilyPi_ILI9481.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup51_LilyPi_ILI9481.h) | C++ | -20 | -1 | -6 | -27 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup52_LilyPi_ST7796.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup52_LilyPi_ST7796.h) | C++ | -21 | -1 | -7 | -29 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup5_RPi_ILI9486.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup5_RPi_ILI9486.h) | C++ | -15 | -4 | -12 | -31 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup60_RP2040_ILI9341.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup60_RP2040_ILI9341.h) | C++ | -19 | -136 | -33 | -188 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup60_RP2040_RPI_MHS.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup60_RP2040_RPI_MHS.h) | C++ | -21 | -3 | -33 | -57 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup61_RP2040_ILI9341_PIO_SPI.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup61_RP2040_ILI9341_PIO_SPI.h) | C++ | -17 | -18 | -10 | -45 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup62_RP2040_Nano_Connect_ILI9341.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup62_RP2040_Nano_Connect_ILI9341.h) | C++ | -30 | -136 | -33 | -199 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup66_Seeed_XIAO_Round.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup66_Seeed_XIAO_Round.h) | C++ | -21 | -2 | -7 | -30 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup6_RPi_Wr_ILI9486.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup6_RPi_Wr_ILI9486.h) | C++ | -16 | -4 | -13 | -33 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup70_ESP32_S2_ILI9341.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup70_ESP32_S2_ILI9341.h) | C++ | -20 | -7 | -11 | -38 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup70b_ESP32_S3_ILI9341.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup70b_ESP32_S3_ILI9341.h) | C++ | -19 | -9 | -10 | -38 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup70c_ESP32_C3_ILI9341.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup70c_ESP32_C3_ILI9341.h) | C++ | -19 | -22 | -16 | -57 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup70d_ILI9488_S3_Parallel.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup70d_ILI9488_S3_Parallel.h) | C++ | -24 | -3 | -10 | -37 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup70f_ESP32_S2_ST7735.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup70f_ESP32_S2_ST7735.h) | C++ | -23 | -7 | -15 | -45 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup70h_ESP32_S3_GC9A01.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup70h_ESP32_S3_GC9A01.h) | C++ | -20 | -4 | -39 | -63 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup71_ESP32_S2_ST7789.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup71_ESP32_S2_ST7789.h) | C++ | -18 | -3 | -9 | -30 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup72_ESP32_ST7789_172x320.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup72_ESP32_ST7789_172x320.h) | C++ | -21 | -2 | -9 | -32 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup7_ST7735_128x128.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup7_ST7735_128x128.h) | C++ | -18 | -10 | -18 | -46 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup8_ILI9163_128x128.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup8_ILI9163_128x128.h) | C++ | -17 | -6 | -14 | -37 |
| [homeStation/lib/TFT_eSPI/User_Setups/Setup9_ST7735_Overlap.h](/homeStation/lib/TFT_eSPI/User_Setups/Setup9_ST7735_Overlap.h) | C++ | -19 | -18 | -20 | -57 |
| [homeStation/lib/TFT_eSPI/User_Setups/SetupX_Template.h](/homeStation/lib/TFT_eSPI/User_Setups/SetupX_Template.h) | C++ | -16 | -274 | -77 | -367 |
| [homeStation/lib/TFT_eSPI/User_Setups/User_Custom_Fonts.h](/homeStation/lib/TFT_eSPI/User_Setups/User_Custom_Fonts.h) | C++ | -7 | -26 | -9 | -42 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/Arduino_Life/Arduino_Life.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/Arduino_Life/Arduino_Life.ino) | C++ | -94 | -45 | -32 | -171 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/Pong_v3/Pong_v3.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/Pong_v3/Pong_v3.ino) | C++ | -150 | -9 | -64 | -223 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/RLE_Font_test/RLE_Font_test.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/RLE_Font_test/RLE_Font_test.ino) | C++ | -128 | -16 | -44 | -188 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_Char_times/TFT_Char_times.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_Char_times/TFT_Char_times.ino) | C++ | -70 | -18 | -41 | -129 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_Clock/TFT_Clock.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_Clock/TFT_Clock.ino) | C++ | -90 | -21 | -24 | -135 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_Clock_Digital/TFT_Clock_Digital.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_Clock_Digital/TFT_Clock_Digital.ino) | C++ | -79 | -37 | -20 | -136 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_Ellipse/TFT_Ellipse.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_Ellipse/TFT_Ellipse.ino) | C++ | -29 | -7 | -15 | -51 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_Meter_5/TFT_Meter_5.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_Meter_5/TFT_Meter_5.ino) | C++ | -114 | -52 | -45 | -211 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_Print_Test/TFT_Print_Test.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_Print_Test/TFT_Print_Test.ino) | C++ | -27 | -27 | -17 | -71 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_Rainbow/TFT_Rainbow.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_Rainbow/TFT_Rainbow.ino) | C++ | -83 | -21 | -24 | -128 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_flash_jpg/TFT_flash_jpg.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_flash_jpg/TFT_flash_jpg.ino) | C++ | -105 | -62 | -46 | -213 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_flash_jpg/jpeg1.h](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_flash_jpg/jpeg1.h) | C++ | -208 | -1 | -3 | -212 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_flash_jpg/jpeg2.h](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_flash_jpg/jpeg2.h) | C++ | -296 | -1 | -3 | -300 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_flash_jpg/jpeg3.h](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_flash_jpg/jpeg3.h) | C++ | -280 | -1 | -3 | -284 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_flash_jpg/jpeg4.h](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_flash_jpg/jpeg4.h) | C++ | -164 | -1 | -3 | -168 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_graphicstest_PDQ3/TFT_graphicstest_PDQ3.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_graphicstest_PDQ3/TFT_graphicstest_PDQ3.ino) | C++ | -533 | -35 | -144 | -712 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/TFT_graphicstest_small/TFT_graphicstest_small.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/TFT_graphicstest_small/TFT_graphicstest_small.ino) | C++ | -210 | -27 | -38 | -275 |
| [homeStation/lib/TFT_eSPI/examples/160 x 128/UTFT_demo_fast/UTFT_demo_fast.ino](/homeStation/lib/TFT_eSPI/examples/160%20x%20128/UTFT_demo_fast/UTFT_demo_fast.ino) | C++ | -249 | -38 | -57 | -344 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/All_Free_Fonts_Demo/All_Free_Fonts_Demo.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/All_Free_Fonts_Demo/All_Free_Fonts_Demo.ino) | C++ | -271 | -94 | -32 | -397 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/All_Free_Fonts_Demo/Free_Fonts.h](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/All_Free_Fonts_Demo/Free_Fonts.h) | C++ | -263 | -54 | -61 | -378 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/Cellular_Automata/Cellular_Automata.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/Cellular_Automata/Cellular_Automata.ino) | C++ | -94 | -39 | -33 | -166 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/Free_Font_Demo/Free_Font_Demo.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/Free_Font_Demo/Free_Font_Demo.ino) | C++ | -172 | -78 | -71 | -321 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/Free_Font_Demo/Free_Fonts.h](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/Free_Font_Demo/Free_Fonts.h) | C++ | -263 | -54 | -61 | -378 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/Keypad_240x320/Keypad_240x320.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/Keypad_240x320/Keypad_240x320.ino) | C++ | -167 | -61 | -57 | -285 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/RLE_Font_test/RLE_Font_test.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/RLE_Font_test/RLE_Font_test.ino) | C++ | -224 | -15 | -64 | -303 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/Read_ID_bitbash/Read_ID_bitbash.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/Read_ID_bitbash/Read_ID_bitbash.ino) | C++ | -93 | -51 | -25 | -169 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_ArcFill/TFT_ArcFill.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_ArcFill/TFT_ArcFill.ino) | C++ | -109 | -27 | -33 | -169 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Char_times/TFT_Char_times.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Char_times/TFT_Char_times.ino) | C++ | -88 | -14 | -41 | -143 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Clock/TFT_Clock.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Clock/TFT_Clock.ino) | C++ | -90 | -34 | -25 | -149 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Clock_Digital/TFT_Clock_Digital.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Clock_Digital/TFT_Clock_Digital.ino) | C++ | -71 | -41 | -23 | -135 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Custom_Fonts/TFT_Custom_Fonts.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Custom_Fonts/TFT_Custom_Fonts.ino) | C++ | -66 | -56 | -29 | -151 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Ellipse/TFT_Ellipse.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Ellipse/TFT_Ellipse.ino) | C++ | -29 | -6 | -15 | -50 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_FillArcSpiral/TFT_FillArcSpiral.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_FillArcSpiral/TFT_FillArcSpiral.ino) | C++ | -103 | -26 | -26 | -155 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Float_Test/TFT_Float_Test.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Float_Test/TFT_Float_Test.ino) | C++ | -39 | -35 | -30 | -104 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Mandlebrot/TFT_Mandlebrot.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Mandlebrot/TFT_Mandlebrot.ino) | C++ | -72 | -6 | -17 | -95 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Matrix/TFT_Matrix.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Matrix/TFT_Matrix.ino) | C++ | -58 | -18 | -18 | -94 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Meter_linear/TFT_Meter_linear.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Meter_linear/TFT_Meter_linear.ino) | C++ | -113 | -55 | -45 | -213 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Meters/TFT_Meters.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Meters/TFT_Meters.ino) | C++ | -175 | -63 | -60 | -298 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Pie_Chart/TFT_Pie_Chart.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Pie_Chart/TFT_Pie_Chart.ino) | C++ | -44 | -19 | -26 | -89 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Pong/TFT_Pong.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Pong/TFT_Pong.ino) | C++ | -148 | -12 | -64 | -224 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Print_Test/TFT_Print_Test.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Print_Test/TFT_Print_Test.ino) | C++ | -32 | -28 | -18 | -78 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Rainbow_one_lib/TFT_Rainbow_one_lib.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Rainbow_one_lib/TFT_Rainbow_one_lib.ino) | C++ | -104 | -26 | -27 | -157 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Read_Reg/TFT_Read_Reg.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Read_Reg/TFT_Read_Reg.ino) | C++ | -74 | -36 | -34 | -144 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Spiro/TFT_Spiro.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Spiro/TFT_Spiro.ino) | C++ | -70 | -7 | -23 | -100 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Starfield/TFT_Starfield.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Starfield/TFT_Starfield.ino) | C++ | -62 | -11 | -17 | -90 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_String_Align/TFT_String_Align.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_String_Align/TFT_String_Align.ino) | C++ | -61 | -27 | -34 | -122 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_Terminal/TFT_Terminal.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_Terminal/TFT_Terminal.ino) | C++ | -62 | -63 | -24 | -149 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_graphicstest_PDQ/TFT_graphicstest_PDQ.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_graphicstest_PDQ/TFT_graphicstest_PDQ.ino) | C++ | -576 | -42 | -137 | -755 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/TFT_graphicstest_one_lib/TFT_graphicstest_one_lib.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/TFT_graphicstest_one_lib/TFT_graphicstest_one_lib.ino) | C++ | -246 | -59 | -66 | -371 |
| [homeStation/lib/TFT_eSPI/examples/320 x 240/UTFT_demo/UTFT_demo.ino](/homeStation/lib/TFT_eSPI/examples/320%20x%20240/UTFT_demo/UTFT_demo.ino) | C++ | -238 | -41 | -56 | -335 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/Cellular_Automata/Cellular_Automata.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/Cellular_Automata/Cellular_Automata.ino) | C++ | -94 | -39 | -33 | -166 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/Demo_3D_cube/Demo_3D_cube.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/Demo_3D_cube/Demo_3D_cube.ino) | C++ | -232 | -33 | -84 | -349 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/Free_Font_Demo/Free_Font_Demo.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/Free_Font_Demo/Free_Font_Demo.ino) | C++ | -152 | -62 | -76 | -290 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/Free_Font_Demo/Free_Fonts.h](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/Free_Font_Demo/Free_Fonts.h) | C++ | -263 | -55 | -62 | -380 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/Graph_2/Graph_2.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/Graph_2/Graph_2.ino) | C++ | -171 | -97 | -61 | -329 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/Keypad_480x320/Keypad_480x320.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/Keypad_480x320/Keypad_480x320.ino) | C++ | -167 | -64 | -57 | -288 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_Char_times/TFT_Char_times.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_Char_times/TFT_Char_times.ino) | C++ | -89 | -22 | -41 | -152 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_Ellipse/TFT_Ellipse.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_Ellipse/TFT_Ellipse.ino) | C++ | -29 | -6 | -17 | -52 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_Meter_4/TFT_Meter_4.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_Meter_4/TFT_Meter_4.ino) | C++ | -113 | -56 | -46 | -215 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_Meters/TFT_Meters.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_Meters/TFT_Meters.ino) | C++ | -174 | -68 | -58 | -300 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_Padding_demo/TFT_Padding_demo.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_Padding_demo/TFT_Padding_demo.ino) | C++ | -84 | -61 | -64 | -209 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_Print_Test/TFT_Print_Test.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_Print_Test/TFT_Print_Test.ino) | C++ | -33 | -27 | -18 | -78 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_Rainbow480/TFT_Rainbow480.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_Rainbow480/TFT_Rainbow480.ino) | C++ | -107 | -26 | -26 | -159 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_String_Align/TFT_String_Align.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_String_Align/TFT_String_Align.ino) | C++ | -66 | -37 | -43 | -146 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_flash_jpg/TFT_flash_jpg.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_flash_jpg/TFT_flash_jpg.ino) | C++ | -113 | -73 | -56 | -242 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_flash_jpg/jpeg1.h](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_flash_jpg/jpeg1.h) | C++ | -764 | -2 | -3 | -769 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_flash_jpg/jpeg2.h](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_flash_jpg/jpeg2.h) | C++ | -208 | -2 | -3 | -213 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_flash_jpg/jpeg3.h](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_flash_jpg/jpeg3.h) | C++ | -608 | -2 | -4 | -614 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_flash_jpg/jpeg4.h](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_flash_jpg/jpeg4.h) | C++ | -653 | -2 | -4 | -659 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_graphicstest_one_lib/TFT_graphicstest_one_lib.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_graphicstest_one_lib/TFT_graphicstest_one_lib.ino) | C++ | -251 | -59 | -62 | -372 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_ring_meter/Alert.h](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_ring_meter/Alert.h) | C++ | -35 | -3 | -4 | -42 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/TFT_ring_meter/TFT_ring_meter.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/TFT_ring_meter/TFT_ring_meter.ino) | C++ | -164 | -62 | -56 | -282 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/Touch_Controller_Demo/Touch_Controller_Demo.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/Touch_Controller_Demo/Touch_Controller_Demo.ino) | C++ | -53 | -5 | -19 | -77 |
| [homeStation/lib/TFT_eSPI/examples/480 x 320/UTFT_Demo_480x320/UTFT_Demo_480x320.ino](/homeStation/lib/TFT_eSPI/examples/480%20x%20320/UTFT_Demo_480x320/UTFT_Demo_480x320.ino) | C++ | -238 | -31 | -58 | -327 |
| [homeStation/lib/TFT_eSPI/examples/DMA test/Bouncy_Circles/Bouncy_Circles.ino](/homeStation/lib/TFT_eSPI/examples/DMA%20test/Bouncy_Circles/Bouncy_Circles.ino) | C++ | -130 | -45 | -34 | -209 |
| [homeStation/lib/TFT_eSPI/examples/DMA test/Flash_Jpg_DMA/Flash_Jpg_DMA.ino](/homeStation/lib/TFT_eSPI/examples/DMA%20test/Flash_Jpg_DMA/Flash_Jpg_DMA.ino) | C++ | -53 | -35 | -24 | -112 |
| [homeStation/lib/TFT_eSPI/examples/DMA test/Flash_Jpg_DMA/panda.h](/homeStation/lib/TFT_eSPI/examples/DMA%20test/Flash_Jpg_DMA/panda.h) | C++ | -793 | -22 | -2 | -817 |
| [homeStation/lib/TFT_eSPI/examples/DMA test/SpriteRotatingCube/SpriteRotatingCube.ino](/homeStation/lib/TFT_eSPI/examples/DMA%20test/SpriteRotatingCube/SpriteRotatingCube.ino) | C++ | -226 | -102 | -67 | -395 |
| [homeStation/lib/TFT_eSPI/examples/DMA test/boing_ball/boing_ball.ino](/homeStation/lib/TFT_eSPI/examples/DMA%20test/boing_ball/boing_ball.ino) | C++ | -106 | -45 | -33 | -184 |
| [homeStation/lib/TFT_eSPI/examples/DMA test/boing_ball/graphic.h](/homeStation/lib/TFT_eSPI/examples/DMA%20test/boing_ball/graphic.h) | C++ | -1,371 | -2 | -5 | -1,378 |
| [homeStation/lib/TFT_eSPI/examples/GUI Widgets/Buttons/Button_demo/Button_demo.ino](/homeStation/lib/TFT_eSPI/examples/GUI%20Widgets/Buttons/Button_demo/Button_demo.ino) | C++ | -144 | -17 | -31 | -192 |
| [homeStation/lib/TFT_eSPI/examples/GUI Widgets/Buttons/Button_demo/Free_Fonts.h](/homeStation/lib/TFT_eSPI/examples/GUI%20Widgets/Buttons/Button_demo/Free_Fonts.h) | C++ | -263 | -54 | -61 | -378 |
| [homeStation/lib/TFT_eSPI/examples/GUI Widgets/Graphs/Graph_demo_1/Graph_demo_1.ino](/homeStation/lib/TFT_eSPI/examples/GUI%20Widgets/Graphs/Graph_demo_1/Graph_demo_1.ino) | C++ | -42 | -20 | -19 | -81 |
| [homeStation/lib/TFT_eSPI/examples/GUI Widgets/Graphs/Graph_demo_2/Graph_demo_2.ino](/homeStation/lib/TFT_eSPI/examples/GUI%20Widgets/Graphs/Graph_demo_2/Graph_demo_2.ino) | C++ | -55 | -27 | -24 | -106 |
| [homeStation/lib/TFT_eSPI/examples/GUI Widgets/Meters/Analogue_meters/Analogue_meters.ino](/homeStation/lib/TFT_eSPI/examples/GUI%20Widgets/Meters/Analogue_meters/Analogue_meters.ino) | C++ | -42 | -27 | -19 | -88 |
| [homeStation/lib/TFT_eSPI/examples/GUI Widgets/Sliders/Slider_demo/Free_Fonts.h](/homeStation/lib/TFT_eSPI/examples/GUI%20Widgets/Sliders/Slider_demo/Free_Fonts.h) | C++ | -263 | -54 | -61 | -378 |
| [homeStation/lib/TFT_eSPI/examples/GUI Widgets/Sliders/Slider_demo/Slider_demo.ino](/homeStation/lib/TFT_eSPI/examples/GUI%20Widgets/Sliders/Slider_demo/Slider_demo.ino) | C++ | -124 | -38 | -40 | -202 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/Animated_Eyes_1.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/Animated_Eyes_1.ino) | C++ | -70 | -41 | -28 | -139 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/config.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/config.h) | C++ | -36 | -42 | -16 | -94 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/catEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/catEye.h) | C++ | -11,584 | 0 | -17 | -11,601 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/defaultEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/defaultEye.h) | C++ | -13,330 | -4 | -16 | -13,350 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/doeEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/doeEye.h) | C++ | -15,632 | 0 | -15 | -15,647 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/dragonEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/dragonEye.h) | C++ | -17,004 | 0 | -15 | -17,019 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/goatEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/goatEye.h) | C++ | -12,794 | 0 | -14 | -12,808 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/logo.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/logo.h) | C++ | -96 | -1 | -5 | -102 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/naugaEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/naugaEye.h) | C++ | -7,599 | 0 | -11 | -7,610 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/newtEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/newtEye.h) | C++ | -13,332 | 0 | -15 | -13,347 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/noScleraEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/noScleraEye.h) | C++ | -17,004 | 0 | -15 | -17,019 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/owlEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/owlEye.h) | C++ | -7,599 | 0 | -11 | -7,610 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/terminatorEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/data/terminatorEye.h) | C++ | -13,332 | 0 | -15 | -13,347 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/eye_functions.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/eye_functions.ino) | C++ | -310 | -71 | -49 | -430 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/user.cpp](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/user.cpp) | C++ | -6 | -54 | -6 | -66 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/user_bat.cpp](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/user_bat.cpp) | C++ | -63 | -7 | -14 | -84 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/user_xmas.cpp](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_1/user_xmas.cpp) | C++ | -40 | -10 | -15 | -65 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/Animated_Eyes_2.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/Animated_Eyes_2.ino) | C++ | -70 | -47 | -30 | -147 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/config.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/config.h) | C++ | -36 | -42 | -16 | -94 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/catEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/catEye.h) | C++ | -11,584 | 0 | -17 | -11,601 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/defaultEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/defaultEye.h) | C++ | -13,330 | -4 | -16 | -13,350 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/doeEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/doeEye.h) | C++ | -15,632 | 0 | -15 | -15,647 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/dragonEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/dragonEye.h) | C++ | -17,004 | 0 | -15 | -17,019 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/goatEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/goatEye.h) | C++ | -12,794 | 0 | -14 | -12,808 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/logo.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/logo.h) | C++ | -96 | -1 | -5 | -102 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/naugaEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/naugaEye.h) | C++ | -7,599 | 0 | -11 | -7,610 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/newtEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/newtEye.h) | C++ | -13,332 | 0 | -15 | -13,347 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/noScleraEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/noScleraEye.h) | C++ | -17,004 | 0 | -15 | -17,019 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/owlEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/owlEye.h) | C++ | -7,599 | 0 | -11 | -7,610 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/terminatorEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/data/terminatorEye.h) | C++ | -13,332 | 0 | -15 | -13,347 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/eye_functions.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/eye_functions.ino) | C++ | -310 | -71 | -49 | -430 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/user.cpp](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/user.cpp) | C++ | -6 | -54 | -6 | -66 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/user_bat.cpp](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/user_bat.cpp) | C++ | -63 | -7 | -14 | -84 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/user_xmas.cpp](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/user_xmas.cpp) | C++ | -40 | -10 | -15 | -65 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/wiring.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Animated_Eyes_2/wiring.ino) | C++ | 0 | -31 | -1 | -32 |
| [homeStation/lib/TFT_eSPI/examples/Generic/ESP32_SDcard_jpeg/ESP32_SDcard_jpeg.ino](/homeStation/lib/TFT_eSPI/examples/Generic/ESP32_SDcard_jpeg/ESP32_SDcard_jpeg.ino) | C++ | -148 | -67 | -54 | -269 |
| [homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/ESP8266_uncannyEyes.ino](/homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/ESP8266_uncannyEyes.ino) | C++ | -225 | -150 | -68 | -443 |
| [homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/defaultEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/defaultEye.h) | C++ | -11,957 | 0 | -10 | -11,967 |
| [homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/dragonEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/dragonEye.h) | C++ | -15,629 | 0 | -10 | -15,639 |
| [homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/goatEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/goatEye.h) | C++ | -11,421 | 0 | -10 | -11,431 |
| [homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/noScleraEye.h](/homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/noScleraEye.h) | C++ | -15,629 | 0 | -10 | -15,639 |
| [homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/screenshotToConsole.ino](/homeStation/lib/TFT_eSPI/examples/Generic/ESP8266_uncannyEyes/screenshotToConsole.ino) | C++ | -146 | -57 | -18 | -221 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Gradient_Fill/Gradient_Fill.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Gradient_Fill/Gradient_Fill.ino) | C++ | -18 | -15 | -6 | -39 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Julia_Set/Julia_Set.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Julia_Set/Julia_Set.ino) | C++ | -51 | -16 | -17 | -84 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Local_Custom_Fonts/Local_Custom_Fonts.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Local_Custom_Fonts/Local_Custom_Fonts.ino) | C++ | -27 | -73 | -22 | -122 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Local_Custom_Fonts/MyFont.h](/homeStation/lib/TFT_eSPI/examples/Generic/Local_Custom_Fonts/MyFont.h) | C++ | -3,355 | -5 | -7 | -3,367 |
| [homeStation/lib/TFT_eSPI/examples/Generic/On_Off_Button/On_Off_Button.ino](/homeStation/lib/TFT_eSPI/examples/Generic/On_Off_Button/On_Off_Button.ino) | C++ | -133 | -36 | -38 | -207 |
| [homeStation/lib/TFT_eSPI/examples/Generic/TFT_Button_Label_Datum/TFT_Button_Label_Datum.ino](/homeStation/lib/TFT_eSPI/examples/Generic/TFT_Button_Label_Datum/TFT_Button_Label_Datum.ino) | C++ | -118 | -38 | -37 | -193 |
| [homeStation/lib/TFT_eSPI/examples/Generic/TFT_Flash_Bitmap/Alert.h](/homeStation/lib/TFT_eSPI/examples/Generic/TFT_Flash_Bitmap/Alert.h) | C++ | -35 | -2 | -3 | -40 |
| [homeStation/lib/TFT_eSPI/examples/Generic/TFT_Flash_Bitmap/Close.h](/homeStation/lib/TFT_eSPI/examples/Generic/TFT_Flash_Bitmap/Close.h) | C++ | -35 | -2 | -3 | -40 |
| [homeStation/lib/TFT_eSPI/examples/Generic/TFT_Flash_Bitmap/Info.h](/homeStation/lib/TFT_eSPI/examples/Generic/TFT_Flash_Bitmap/Info.h) | C++ | -35 | -2 | -3 | -40 |
| [homeStation/lib/TFT_eSPI/examples/Generic/TFT_Flash_Bitmap/TFT_Flash_Bitmap.ino](/homeStation/lib/TFT_eSPI/examples/Generic/TFT_Flash_Bitmap/TFT_Flash_Bitmap.ino) | C++ | -30 | -28 | -15 | -73 |
| [homeStation/lib/TFT_eSPI/examples/Generic/TFT_SPIFFS_BMP/BMP_functions.ino](/homeStation/lib/TFT_eSPI/examples/Generic/TFT_SPIFFS_BMP/BMP_functions.ino) | C++ | -64 | -8 | -19 | -91 |
| [homeStation/lib/TFT_eSPI/examples/Generic/TFT_SPIFFS_BMP/TFT_SPIFFS_BMP.ino](/homeStation/lib/TFT_eSPI/examples/Generic/TFT_SPIFFS_BMP/TFT_SPIFFS_BMP.ino) | C++ | -26 | -23 | -16 | -65 |
| [homeStation/lib/TFT_eSPI/examples/Generic/TFT_Screen_Capture/TFT_Screen_Capture.ino](/homeStation/lib/TFT_eSPI/examples/Generic/TFT_Screen_Capture/TFT_Screen_Capture.ino) | C++ | -123 | -50 | -35 | -208 |
| [homeStation/lib/TFT_eSPI/examples/Generic/TFT_Screen_Capture/processing_sketch.ino](/homeStation/lib/TFT_eSPI/examples/Generic/TFT_Screen_Capture/processing_sketch.ino) | C++ | 0 | -533 | -3 | -536 |
| [homeStation/lib/TFT_eSPI/examples/Generic/TFT_Screen_Capture/screenServer.ino](/homeStation/lib/TFT_eSPI/examples/Generic/TFT_Screen_Capture/screenServer.ino) | C++ | -94 | -68 | -35 | -197 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Touch_calibrate/Touch_calibrate.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Touch_calibrate/Touch_calibrate.ino) | C++ | -49 | -29 | -27 | -105 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Viewport_Demo/Viewport_Demo.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Viewport_Demo/Viewport_Demo.ino) | C++ | -56 | -30 | -28 | -114 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Viewport_Demo/Viewport_commands.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Viewport_Demo/Viewport_commands.ino) | C++ | 0 | -40 | 0 | -40 |
| [homeStation/lib/TFT_eSPI/examples/Generic/Viewport_graphicstest/Viewport_graphicstest.ino](/homeStation/lib/TFT_eSPI/examples/Generic/Viewport_graphicstest/Viewport_graphicstest.ino) | C++ | -252 | -62 | -69 | -383 |
| [homeStation/lib/TFT_eSPI/examples/Generic/alphaBlend_Test/alphaBlend_Test.ino](/homeStation/lib/TFT_eSPI/examples/Generic/alphaBlend_Test/alphaBlend_Test.ino) | C++ | -92 | -78 | -25 | -195 |
| [homeStation/lib/TFT_eSPI/examples/Generic/drawXBitmap/drawXBitmap.ino](/homeStation/lib/TFT_eSPI/examples/Generic/drawXBitmap/drawXBitmap.ino) | C++ | -21 | -21 | -20 | -62 |
| [homeStation/lib/TFT_eSPI/examples/Generic/drawXBitmap/xbm.h](/homeStation/lib/TFT_eSPI/examples/Generic/drawXBitmap/xbm.h) | C++ | -33 | -11 | -7 | -51 |
| [homeStation/lib/TFT_eSPI/examples/PNG Images/Flash_PNG/Flash_PNG.ino](/homeStation/lib/TFT_eSPI/examples/PNG%20Images/Flash_PNG/Flash_PNG.ino) | C++ | -37 | -31 | -15 | -83 |
| [homeStation/lib/TFT_eSPI/examples/PNG Images/Flash_PNG/panda.h](/homeStation/lib/TFT_eSPI/examples/PNG%20Images/Flash_PNG/panda.h) | C++ | -11,424 | -1 | 0 | -11,425 |
| [homeStation/lib/TFT_eSPI/examples/PNG Images/Flash_transparent_PNG/Flash_transparent_PNG.ino](/homeStation/lib/TFT_eSPI/examples/PNG%20Images/Flash_transparent_PNG/Flash_transparent_PNG.ino) | C++ | -38 | -31 | -22 | -91 |
| [homeStation/lib/TFT_eSPI/examples/PNG Images/Flash_transparent_PNG/SpongeBob.h](/homeStation/lib/TFT_eSPI/examples/PNG%20Images/Flash_transparent_PNG/SpongeBob.h) | C++ | -1,354 | -1 | -1 | -1,356 |
| [homeStation/lib/TFT_eSPI/examples/PNG Images/Flash_transparent_PNG/png_support.ino](/homeStation/lib/TFT_eSPI/examples/PNG%20Images/Flash_transparent_PNG/png_support.ino) | C++ | -8 | -7 | -5 | -20 |
| [homeStation/lib/TFT_eSPI/examples/PNG Images/LittleFS_PNG/LittleFS_PNG.ino](/homeStation/lib/TFT_eSPI/examples/PNG%20Images/LittleFS_PNG/LittleFS_PNG.ino) | C++ | -55 | -32 | -17 | -104 |
| [homeStation/lib/TFT_eSPI/examples/PNG Images/LittleFS_PNG/PNG_FS_Support.ino](/homeStation/lib/TFT_eSPI/examples/PNG%20Images/LittleFS_PNG/PNG_FS_Support.ino) | C++ | -21 | -2 | -6 | -29 |
| [homeStation/lib/TFT_eSPI/examples/PNG Images/LittleFS_PNG_DMA/LittleFS_PNG_DMA.ino](/homeStation/lib/TFT_eSPI/examples/PNG%20Images/LittleFS_PNG_DMA/LittleFS_PNG_DMA.ino) | C++ | -57 | -36 | -19 | -112 |
| [homeStation/lib/TFT_eSPI/examples/PNG Images/LittleFS_PNG_DMA/PNG_FS_Support.ino](/homeStation/lib/TFT_eSPI/examples/PNG%20Images/LittleFS_PNG_DMA/PNG_FS_Support.ino) | C++ | -21 | -2 | -6 | -29 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_1_Array/Font_Demo_1_Array.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_1_Array/Font_Demo_1_Array.ino) | C++ | -71 | -48 | -47 | -166 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_1_Array/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_1_Array/Notes.ino) | C++ | 0 | -56 | -1 | -57 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_1_Array/NotoSansBold15.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_1_Array/NotoSansBold15.h) | C++ | -675 | -17 | -3 | -695 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_1_Array/NotoSansBold36.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_1_Array/NotoSansBold36.h) | C++ | -2,763 | -17 | -3 | -2,783 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_2_Array/Font_Demo_2_Array.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_2_Array/Font_Demo_2_Array.ino) | C++ | -112 | -45 | -59 | -216 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_2_Array/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_2_Array/Notes.ino) | C++ | 0 | -56 | -1 | -57 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_2_Array/NotoSansBold15.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_2_Array/NotoSansBold15.h) | C++ | -675 | -17 | -3 | -695 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_2_Array/NotoSansBold36.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_2_Array/NotoSansBold36.h) | C++ | -2,763 | -17 | -3 | -2,783 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_3_Array/Font_Demo_3_Array.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_3_Array/Font_Demo_3_Array.ino) | C++ | -87 | -61 | -65 | -213 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_3_Array/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_3_Array/Notes.ino) | C++ | 0 | -61 | -1 | -62 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_3_Array/NotoSansBold15.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_3_Array/NotoSansBold15.h) | C++ | -675 | -17 | -3 | -695 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_3_Array/NotoSansBold36.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_3_Array/NotoSansBold36.h) | C++ | -2,763 | -17 | -3 | -2,783 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_3_Array/NotoSansMonoSCB20.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_3_Array/NotoSansMonoSCB20.h) | C++ | -964 | -17 | -3 | -984 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_4_Array/Font_Demo_4_Array.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_4_Array/Font_Demo_4_Array.ino) | C++ | -41 | -44 | -35 | -120 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_4_Array/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_4_Array/Notes.ino) | C++ | 0 | -56 | -1 | -57 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_4_Array/NotoSansBold15.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_4_Array/NotoSansBold15.h) | C++ | -675 | -17 | -3 | -695 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Font_Demo_4_Array/NotoSansBold36.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Font_Demo_4_Array/NotoSansBold36.h) | C++ | -2,763 | -17 | -3 | -2,783 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Print_Smooth_Font/Final_Frontier_28.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Print_Smooth_Font/Final_Frontier_28.h) | C++ | -1,583 | -17 | -3 | -1,603 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Print_Smooth_Font/Print_Smooth_Font.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Print_Smooth_Font/Print_Smooth_Font.ino) | C++ | -95 | -48 | -33 | -176 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Smooth_font_gradient/NotoSansBold15.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Smooth_font_gradient/NotoSansBold15.h) | C++ | -675 | -17 | -3 | -695 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Smooth_font_gradient/NotoSansBold36.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Smooth_font_gradient/NotoSansBold36.h) | C++ | -2,763 | -17 | -3 | -2,783 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Smooth_font_gradient/Smooth_font_gradient.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Smooth_font_gradient/Smooth_font_gradient.ino) | C++ | -44 | -30 | -22 | -96 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Smooth_font_reading_TFT/NotoSansBold15.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Smooth_font_reading_TFT/NotoSansBold15.h) | C++ | -675 | -17 | -3 | -695 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Smooth_font_reading_TFT/NotoSansBold36.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Smooth_font_reading_TFT/NotoSansBold36.h) | C++ | -2,763 | -17 | -3 | -2,783 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Smooth_font_reading_TFT/Smooth_font_reading_TFT.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Smooth_font_reading_TFT/Smooth_font_reading_TFT.ino) | C++ | -84 | -31 | -24 | -139 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Unicode_test/Final_Frontier_28.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Unicode_test/Final_Frontier_28.h) | C++ | -1,583 | -17 | -3 | -1,603 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Unicode_test/Latin_Hiragana_24.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Unicode_test/Latin_Hiragana_24.h) | C++ | -3,407 | -17 | -3 | -3,427 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Unicode_test/Unicode_Test_72.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Unicode_test/Unicode_Test_72.h) | C++ | -2,282 | -17 | -3 | -2,302 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/FLASH_Array/Unicode_test/Unicode_test.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/FLASH_Array/Unicode_test/Unicode_test.ino) | C++ | -57 | -46 | -45 | -148 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Font_Demo_1/Font_Demo_1.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Font_Demo_1/Font_Demo_1.ino) | C++ | -85 | -48 | -51 | -184 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Font_Demo_1/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Font_Demo_1/Notes.ino) | C++ | 0 | -56 | -1 | -57 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Font_Demo_2/Font_Demo_2.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Font_Demo_2/Font_Demo_2.ino) | C++ | -127 | -45 | -63 | -235 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Font_Demo_2/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Font_Demo_2/Notes.ino) | C++ | 0 | -56 | -1 | -57 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Font_Demo_3/Font_Demo_3.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Font_Demo_3/Font_Demo_3.ino) | C++ | -102 | -61 | -69 | -232 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Font_Demo_3/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Font_Demo_3/Notes.ino) | C++ | 0 | -61 | -1 | -62 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Font_Demo_4/Font_Demo_4.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Font_Demo_4/Font_Demo_4.ino) | C++ | -56 | -46 | -39 | -141 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Font_Demo_4/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Font_Demo_4/Notes.ino) | C++ | 0 | -56 | -1 | -57 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Print_Smooth_Font/Print_Smooth_Font.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Print_Smooth_Font/Print_Smooth_Font.ino) | C++ | -63 | -55 | -32 | -150 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Smooth_font_gradient/Smooth_font_gradient.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Smooth_font_gradient/Smooth_font_gradient.ino) | C++ | -59 | -34 | -28 | -121 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Smooth_font_reading_TFT/Smooth_font_reading_TFT.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Smooth_font_reading_TFT/Smooth_font_reading_TFT.ino) | C++ | -99 | -38 | -29 | -166 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Unicode_test/LittleFS_functions.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Unicode_test/LittleFS_functions.ino) | C++ | -22 | -9 | -9 | -40 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/LittleFS/Unicode_test/Unicode_test.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/LittleFS/Unicode_test/Unicode_test.ino) | C++ | -68 | -45 | -40 | -153 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SD_Card/ESP32_Smooth_Font_SD/ESP32_Smooth_Font_SD.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SD_Card/ESP32_Smooth_Font_SD/ESP32_Smooth_Font_SD.ino) | C++ | -91 | -51 | -33 | -175 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Font_Demo_1/Font_Demo_1.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Font_Demo_1/Font_Demo_1.ino) | C++ | -83 | -51 | -51 | -185 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Font_Demo_1/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Font_Demo_1/Notes.ino) | C++ | 0 | -56 | -1 | -57 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Font_Demo_2/Font_Demo_2.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Font_Demo_2/Font_Demo_2.ino) | C++ | -125 | -48 | -63 | -236 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Font_Demo_2/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Font_Demo_2/Notes.ino) | C++ | 0 | -56 | -1 | -57 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Font_Demo_3/Font_Demo_3.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Font_Demo_3/Font_Demo_3.ino) | C++ | -100 | -64 | -68 | -232 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Font_Demo_3/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Font_Demo_3/Notes.ino) | C++ | 0 | -61 | -1 | -62 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Font_Demo_4/Font_Demo_4.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Font_Demo_4/Font_Demo_4.ino) | C++ | -54 | -48 | -39 | -141 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Font_Demo_4/Notes.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Font_Demo_4/Notes.ino) | C++ | 0 | -56 | -1 | -57 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Print_Smooth_Font/Print_Smooth_Font.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Print_Smooth_Font/Print_Smooth_Font.ino) | C++ | -103 | -58 | -35 | -196 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Smooth_font_gradient/Smooth_font_gradient.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Smooth_font_gradient/Smooth_font_gradient.ino) | C++ | -57 | -37 | -28 | -122 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Smooth_font_reading_TFT/Smooth_font_reading_TFT.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Smooth_font_reading_TFT/Smooth_font_reading_TFT.ino) | C++ | -97 | -40 | -29 | -166 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Unicode_test/SPIFFS_functions.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Unicode_test/SPIFFS_functions.ino) | C++ | -63 | -9 | -12 | -84 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Fonts/SPIFFS/Unicode_test/Unicode_test.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Fonts/SPIFFS/Unicode_test/Unicode_test.ino) | C++ | -60 | -44 | -45 | -149 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Graphics/Anti-aliased_Clock/Anti-aliased_Clock.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Graphics/Anti-aliased_Clock/Anti-aliased_Clock.ino) | C++ | -84 | -51 | -45 | -180 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Graphics/Anti-aliased_Clock/NTP_Time.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Graphics/Anti-aliased_Clock/NTP_Time.h) | C++ | -207 | -85 | -73 | -365 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Graphics/Anti-aliased_Clock/NotoSansBold15.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Graphics/Anti-aliased_Clock/NotoSansBold15.h) | C++ | -676 | -18 | -3 | -697 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Graphics/Arc_meter_demo/Arc_meter_demo.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Graphics/Arc_meter_demo/Arc_meter_demo.ino) | C++ | -126 | -42 | -41 | -209 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Graphics/Arc_meter_demo/NotoSans_Bold.h](/homeStation/lib/TFT_eSPI/examples/Smooth%20Graphics/Arc_meter_demo/NotoSans_Bold.h) | C++ | -727 | -3 | -3 | -733 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Graphics/Colour_Wheel/Colour_Wheel.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Graphics/Colour_Wheel/Colour_Wheel.ino) | C++ | -31 | -9 | -8 | -48 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Graphics/Draw_Arc/Draw_Arc.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Graphics/Draw_Arc/Draw_Arc.ino) | C++ | -25 | -15 | -14 | -54 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Graphics/Draw_Smooth_Circles/Draw_Smooth_Circles.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Graphics/Draw_Smooth_Circles/Draw_Smooth_Circles.ino) | C++ | -67 | -16 | -16 | -99 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Graphics/Smooth_Arc/Smooth_Arc.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Graphics/Smooth_Arc/Smooth_Arc.ino) | C++ | -25 | -10 | -12 | -47 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Graphics/Smooth_Graphics_Demo/Smooth_Graphics_Demo.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Graphics/Smooth_Graphics_Demo/Smooth_Graphics_Demo.ino) | C++ | -98 | -46 | -38 | -182 |
| [homeStation/lib/TFT_eSPI/examples/Smooth Graphics/Smooth_Rounded_Rectangles/Smooth_Rounded_Rectangles.ino](/homeStation/lib/TFT_eSPI/examples/Smooth%20Graphics/Smooth_Rounded_Rectangles/Smooth_Rounded_Rectangles.ino) | C++ | -36 | -5 | -10 | -51 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Animated_dial/Animated_dial.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Animated_dial/Animated_dial.ino) | C++ | -106 | -63 | -47 | -216 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Animated_dial/NotoSansBold36.h](/homeStation/lib/TFT_eSPI/examples/Sprite/Animated_dial/NotoSansBold36.h) | C++ | -361 | -18 | -2 | -381 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Animated_dial/dial.h](/homeStation/lib/TFT_eSPI/examples/Sprite/Animated_dial/dial.h) | C++ | -1,133 | -17 | -2 | -1,152 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/One_bit_Sprite_Demo/One_bit_Sprite_Demo.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/One_bit_Sprite_Demo/One_bit_Sprite_Demo.ino) | C++ | -43 | -42 | -22 | -107 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/One_bit_Yin_Yang/One_bit_Yin_Yang.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/One_bit_Yin_Yang/One_bit_Yin_Yang.ino) | C++ | -45 | -29 | -24 | -98 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Orrery/Orrery.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Orrery/Orrery.ino) | C++ | -92 | -34 | -38 | -164 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Orrery/astronomy.c](/homeStation/lib/TFT_eSPI/examples/Sprite/Orrery/astronomy.c) | C | -5,562 | -2,206 | -1,055 | -8,823 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Orrery/astronomy.h](/homeStation/lib/TFT_eSPI/examples/Sprite/Orrery/astronomy.h) | C++ | -411 | -421 | -73 | -905 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Rotated_Sprite_1/Rotated_Sprite_1.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Rotated_Sprite_1/Rotated_Sprite_1.ino) | C++ | -93 | -35 | -59 | -187 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Rotated_Sprite_2/Rotated_Sprite_2.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Rotated_Sprite_2/Rotated_Sprite_2.ino) | C++ | -78 | -56 | -48 | -182 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Rotated_Sprite_3/Rotated_Sprite_3.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Rotated_Sprite_3/Rotated_Sprite_3.ino) | C++ | -45 | -70 | -26 | -141 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_RLE_Font_test/Sprite_RLE_Font_test.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_RLE_Font_test/Sprite_RLE_Font_test.ino) | C++ | -135 | -15 | -48 | -198 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_TFT_Rainbow/Sprite_TFT_Rainbow.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_TFT_Rainbow/Sprite_TFT_Rainbow.ino) | C++ | -89 | -24 | -28 | -141 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_draw/Sprite_draw.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_draw/Sprite_draw.ino) | C++ | -66 | -48 | -28 | -142 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_draw_4bit/Sprite_draw_4bit.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_draw_4bit/Sprite_draw_4bit.ino) | C++ | -105 | -54 | -40 | -199 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_image_4bit/Sprite_image_4bit.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_image_4bit/Sprite_image_4bit.ino) | C++ | -92 | -37 | -24 | -153 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_image_4bit/sample_images.h](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_image_4bit/sample_images.h) | C++ | -2 | 0 | -1 | -3 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_image_4bit/starImage.cpp](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_image_4bit/starImage.cpp) | C++ | -1,282 | -1 | -161 | -1,444 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll/Sprite_scroll.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll/Sprite_scroll.ino) | C++ | -57 | -40 | -22 | -119 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll_16bit/Sprite_scroll_16bit.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll_16bit/Sprite_scroll_16bit.ino) | C++ | -88 | -67 | -40 | -195 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll_1bit/Sprite_scroll_1bit.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll_1bit/Sprite_scroll_1bit.ino) | C++ | -60 | -48 | -24 | -132 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll_4bit/Sprite_scroll_4bit.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll_4bit/Sprite_scroll_4bit.ino) | C++ | -78 | -39 | -25 | -142 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll_8bit/Sprite_scroll_8bit.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll_8bit/Sprite_scroll_8bit.ino) | C++ | -89 | -76 | -41 | -206 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll_wrap_1bit/Sprite_scroll_wrap_1bit.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Sprite_scroll_wrap_1bit/Sprite_scroll_wrap_1bit.ino) | C++ | -65 | -37 | -38 | -140 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Transparent_Sprite_Demo/Transparent_Sprite_Demo.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Transparent_Sprite_Demo/Transparent_Sprite_Demo.ino) | C++ | -58 | -53 | -34 | -145 |
| [homeStation/lib/TFT_eSPI/examples/Sprite/Transparent_Sprite_Demo_4bit/Transparent_Sprite_Demo_4bit.ino](/homeStation/lib/TFT_eSPI/examples/Sprite/Transparent_Sprite_Demo_4bit/Transparent_Sprite_Demo_4bit.ino) | C++ | -46 | -73 | -28 | -147 |
| [homeStation/lib/TFT_eSPI/examples/Test and diagnostics/Colour_Test/Colour_Test.ino](/homeStation/lib/TFT_eSPI/examples/Test%20and%20diagnostics/Colour_Test/Colour_Test.ino) | C++ | -49 | -51 | -36 | -136 |
| [homeStation/lib/TFT_eSPI/examples/Test and diagnostics/Read_User_Setup/Read_User_Setup.ino](/homeStation/lib/TFT_eSPI/examples/Test%20and%20diagnostics/Read_User_Setup/Read_User_Setup.ino) | C++ | -132 | -25 | -32 | -189 |
| [homeStation/lib/TFT_eSPI/examples/Test and diagnostics/TFT_ReadWrite_Test/TFT_ReadWrite_Test.ino](/homeStation/lib/TFT_eSPI/examples/Test%20and%20diagnostics/TFT_ReadWrite_Test/TFT_ReadWrite_Test.ino) | C++ | -24 | -3 | -11 | -38 |
| [homeStation/lib/TFT_eSPI/examples/Test and diagnostics/Test_Touch_Controller/Test_Touch_Controller.ino](/homeStation/lib/TFT_eSPI/examples/Test%20and%20diagnostics/Test_Touch_Controller/Test_Touch_Controller.ino) | C++ | -16 | -15 | -19 | -50 |
| [homeStation/lib/TFT_eSPI/examples/ePaper/Floyd_Steinberg/EPD_Support.h](/homeStation/lib/TFT_eSPI/examples/ePaper/Floyd_Steinberg/EPD_Support.h) | C++ | -63 | -36 | -19 | -118 |
| [homeStation/lib/TFT_eSPI/examples/ePaper/Floyd_Steinberg/Floyd_Steinberg.ino](/homeStation/lib/TFT_eSPI/examples/ePaper/Floyd_Steinberg/Floyd_Steinberg.ino) | C++ | -73 | -61 | -55 | -189 |
| [homeStation/lib/TFT_eSPI/examples/ePaper/Floyd_Steinberg/Floyd_Steinberg_BMP.ino](/homeStation/lib/TFT_eSPI/examples/ePaper/Floyd_Steinberg/Floyd_Steinberg_BMP.ino) | C++ | -94 | -70 | -37 | -201 |
| [homeStation/lib/TFT_eSPI/examples/ePaper/Floyd_Steinberg/SPIFFS.ino](/homeStation/lib/TFT_eSPI/examples/ePaper/Floyd_Steinberg/SPIFFS.ino) | C++ | -68 | -10 | -15 | -93 |
| [homeStation/lib/TFT_eSPI/library.json](/homeStation/lib/TFT_eSPI/library.json) | JSON | -22 | 0 | -1 | -23 |
| [homeStation/lib/TFT_eSPI/library.properties](/homeStation/lib/TFT_eSPI/library.properties) | Java Properties | -10 | 0 | -2 | -12 |
| [homeStation/lib/TFT_eWidget/README.md](/homeStation/lib/TFT_eWidget/README.md) | Markdown | -2 | 0 | -2 | -4 |
| [homeStation/lib/TFT_eWidget/examples/Buttons/Button_demo/Button_demo.ino](/homeStation/lib/TFT_eWidget/examples/Buttons/Button_demo/Button_demo.ino) | C++ | -144 | -17 | -31 | -192 |
| [homeStation/lib/TFT_eWidget/examples/Buttons/Button_demo/Free_Fonts.h](/homeStation/lib/TFT_eWidget/examples/Buttons/Button_demo/Free_Fonts.h) | C++ | -263 | -54 | -61 | -378 |
| [homeStation/lib/TFT_eWidget/examples/Graphs/Graph_demo_1/Graph_demo_1.ino](/homeStation/lib/TFT_eWidget/examples/Graphs/Graph_demo_1/Graph_demo_1.ino) | C++ | -42 | -20 | -19 | -81 |
| [homeStation/lib/TFT_eWidget/examples/Graphs/Graph_demo_2/Graph_demo_2.ino](/homeStation/lib/TFT_eWidget/examples/Graphs/Graph_demo_2/Graph_demo_2.ino) | C++ | -55 | -27 | -24 | -106 |
| [homeStation/lib/TFT_eWidget/examples/Graphs/Reflow_graph_demo/Free_Fonts.h](/homeStation/lib/TFT_eWidget/examples/Graphs/Reflow_graph_demo/Free_Fonts.h) | C++ | -263 | -54 | -61 | -378 |
| [homeStation/lib/TFT_eWidget/examples/Graphs/Reflow_graph_demo/Reflow_graph_demo.ino](/homeStation/lib/TFT_eWidget/examples/Graphs/Reflow_graph_demo/Reflow_graph_demo.ino) | C++ | -86 | -8 | -24 | -118 |
| [homeStation/lib/TFT_eWidget/examples/Meters/Analogue_meters/Analogue_meters.ino](/homeStation/lib/TFT_eWidget/examples/Meters/Analogue_meters/Analogue_meters.ino) | C++ | -42 | -27 | -19 | -88 |
| [homeStation/lib/TFT_eWidget/examples/Sliders/Slider_demo/Free_Fonts.h](/homeStation/lib/TFT_eWidget/examples/Sliders/Slider_demo/Free_Fonts.h) | C++ | -263 | -54 | -61 | -378 |
| [homeStation/lib/TFT_eWidget/examples/Sliders/Slider_demo/Slider_demo.ino](/homeStation/lib/TFT_eWidget/examples/Sliders/Slider_demo/Slider_demo.ino) | C++ | -124 | -38 | -40 | -202 |
| [homeStation/lib/TFT_eWidget/library.json](/homeStation/lib/TFT_eWidget/library.json) | JSON | -22 | 0 | -1 | -23 |
| [homeStation/lib/TFT_eWidget/library.properties](/homeStation/lib/TFT_eWidget/library.properties) | Java Properties | -10 | 0 | -2 | -12 |
| [homeStation/lib/TFT_eWidget/src/TFT_eWidget.cpp](/homeStation/lib/TFT_eWidget/src/TFT_eWidget.cpp) | C++ | -1 | 0 | -1 | -2 |
| [homeStation/lib/TFT_eWidget/src/TFT_eWidget.h](/homeStation/lib/TFT_eWidget/src/TFT_eWidget.h) | C++ | -15 | -9 | -4 | -28 |
| [homeStation/lib/TFT_eWidget/src/widgets/button/ButtonWidget.cpp](/homeStation/lib/TFT_eWidget/src/widgets/button/ButtonWidget.cpp) | C++ | -131 | -8 | -25 | -164 |
| [homeStation/lib/TFT_eWidget/src/widgets/button/ButtonWidget.h](/homeStation/lib/TFT_eWidget/src/widgets/button/ButtonWidget.h) | C++ | -40 | -19 | -21 | -80 |
| [homeStation/lib/TFT_eWidget/src/widgets/graph/GraphWidget.cpp](/homeStation/lib/TFT_eWidget/src/widgets/graph/GraphWidget.cpp) | C++ | -164 | -86 | -33 | -283 |
| [homeStation/lib/TFT_eWidget/src/widgets/graph/GraphWidget.h](/homeStation/lib/TFT_eWidget/src/widgets/graph/GraphWidget.h) | C++ | -47 | -11 | -23 | -81 |
| [homeStation/lib/TFT_eWidget/src/widgets/graph/TraceWidget.cpp](/homeStation/lib/TFT_eWidget/src/widgets/graph/TraceWidget.cpp) | C++ | -34 | -28 | -11 | -73 |
| [homeStation/lib/TFT_eWidget/src/widgets/graph/TraceWidget.h](/homeStation/lib/TFT_eWidget/src/widgets/graph/TraceWidget.h) | C++ | -28 | -7 | -14 | -49 |
| [homeStation/lib/TFT_eWidget/src/widgets/meter/Meter.cpp](/homeStation/lib/TFT_eWidget/src/widgets/meter/Meter.cpp) | C++ | -149 | -45 | -41 | -235 |
| [homeStation/lib/TFT_eWidget/src/widgets/meter/Meter.h](/homeStation/lib/TFT_eWidget/src/widgets/meter/Meter.h) | C++ | -37 | -11 | -14 | -62 |
| [homeStation/lib/TFT_eWidget/src/widgets/slider/SliderWidget.cpp](/homeStation/lib/TFT_eWidget/src/widgets/slider/SliderWidget.cpp) | C++ | -170 | -69 | -39 | -278 |
| [homeStation/lib/TFT_eWidget/src/widgets/slider/SliderWidget.h](/homeStation/lib/TFT_eWidget/src/widgets/slider/SliderWidget.h) | C++ | -65 | -14 | -29 | -108 |
| [homeStation/lib/lv_conf.h](/homeStation/lib/lv_conf.h) | C++ | -326 | -288 | -171 | -785 |
| [homeStation/lib/lvgl/CMakeLists.txt](/homeStation/lib/lvgl/CMakeLists.txt) | CMake | -14 | 0 | -4 | -18 |
| [homeStation/lib/lvgl/README.md](/homeStation/lib/lvgl/README.md) | Markdown | -153 | 0 | -34 | -187 |
| [homeStation/lib/lvgl/README_pt_BR.md](/homeStation/lib/lvgl/README_pt_BR.md) | Markdown | -174 | 0 | -33 | -207 |
| [homeStation/lib/lvgl/README_zh.md](/homeStation/lib/lvgl/README_zh.md) | Markdown | -155 | 0 | -39 | -194 |
| [homeStation/lib/lvgl/SConscript](/homeStation/lib/lvgl/SConscript) | Python | -6 | -1 | -5 | -12 |
| [homeStation/lib/lvgl/component.mk](/homeStation/lib/lvgl/component.mk) | Makefile | -30 | -1 | -4 | -35 |
| [homeStation/lib/lvgl/demos/README.md](/homeStation/lib/lvgl/demos/README.md) | Markdown | -68 | 0 | -30 | -98 |
| [homeStation/lib/lvgl/demos/benchmark/README.md](/homeStation/lib/lvgl/demos/benchmark/README.md) | Markdown | -95 | 0 | -40 | -135 |
| [homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_alpha16.c](/homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_alpha16.c) | C | -119 | 0 | -9 | -128 |
| [homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_argb.c](/homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_argb.c) | C | -427 | -3 | -8 | -438 |
| [homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_chroma_keyed.c](/homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_chroma_keyed.c) | C | -427 | -4 | -8 | -439 |
| [homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_indexed16.c](/homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_indexed16.c) | C | -135 | 0 | -9 | -144 |
| [homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_rgb.c](/homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_rgb.c) | C | -427 | -4 | -7 | -438 |
| [homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_rgb565a8.c](/homeStation/lib/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_rgb565a8.c) | C | -218 | -1 | -6 | -225 |
| [homeStation/lib/lvgl/demos/benchmark/assets/lv_font_bechmark_montserrat_12_compr_az.c.c](/homeStation/lib/lvgl/demos/benchmark/assets/lv_font_bechmark_montserrat_12_compr_az.c.c) | C | -207 | -58 | -54 | -319 |
| [homeStation/lib/lvgl/demos/benchmark/assets/lv_font_bechmark_montserrat_16_compr_az.c.c](/homeStation/lib/lvgl/demos/benchmark/assets/lv_font_bechmark_montserrat_16_compr_az.c.c) | C | -245 | -58 | -55 | -358 |
| [homeStation/lib/lvgl/demos/benchmark/assets/lv_font_bechmark_montserrat_28_compr_az.c.c](/homeStation/lib/lvgl/demos/benchmark/assets/lv_font_bechmark_montserrat_28_compr_az.c.c) | C | -395 | -58 | -56 | -509 |
| [homeStation/lib/lvgl/demos/benchmark/lv_demo_benchmark.c](/homeStation/lib/lvgl/demos/benchmark/lv_demo_benchmark.c) | C | -916 | -70 | -235 | -1,221 |
| [homeStation/lib/lvgl/demos/benchmark/lv_demo_benchmark.h](/homeStation/lib/lvgl/demos/benchmark/lv_demo_benchmark.h) | C++ | -16 | -23 | -15 | -54 |
| [homeStation/lib/lvgl/demos/keypad_encoder/README.md](/homeStation/lib/lvgl/demos/keypad_encoder/README.md) | Markdown | -9 | 0 | -5 | -14 |
| [homeStation/lib/lvgl/demos/keypad_encoder/lv_demo_keypad_encoder.c](/homeStation/lib/lvgl/demos/keypad_encoder/lv_demo_keypad_encoder.c) | C | -153 | -28 | -49 | -230 |
| [homeStation/lib/lvgl/demos/keypad_encoder/lv_demo_keypad_encoder.h](/homeStation/lib/lvgl/demos/keypad_encoder/lv_demo_keypad_encoder.h) | C++ | -12 | -19 | -10 | -41 |
| [homeStation/lib/lvgl/demos/lv_demos.h](/homeStation/lib/lvgl/demos/lv_demos.h) | C++ | -25 | -19 | -16 | -60 |
| [homeStation/lib/lvgl/demos/lv_demos.mk](/homeStation/lib/lvgl/demos/lv_demos.mk) | Makefile | -1 | 0 | -1 | -2 |
| [homeStation/lib/lvgl/demos/music/README.md](/homeStation/lib/lvgl/demos/music/README.md) | Markdown | -21 | 0 | -7 | -28 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_corner_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_corner_large.c) | C | -155 | -4 | -5 | -164 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_list_pause.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_list_pause.c) | C | -264 | -3 | -7 | -274 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_list_pause_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_list_pause_large.c) | C | -447 | -4 | -6 | -457 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_list_play.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_list_play.c) | C | -264 | -3 | -7 | -274 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_list_play_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_list_play_large.c) | C | -447 | -4 | -6 | -457 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_loop.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_loop.c) | C | -120 | -3 | -7 | -130 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_loop_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_loop_large.c) | C | -171 | -4 | -6 | -181 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_next.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_next.c) | C | -272 | -3 | -7 | -282 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_next_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_next_large.c) | C | -467 | -4 | -6 | -477 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_pause.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_pause.c) | C | -332 | -3 | -7 | -342 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_pause_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_pause_large.c) | C | -595 | -4 | -7 | -606 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_play.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_play.c) | C | -332 | -3 | -7 | -342 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_play_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_play_large.c) | C | -595 | -4 | -8 | -607 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_prev.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_prev.c) | C | -272 | -3 | -7 | -282 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_prev_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_prev_large.c) | C | -467 | -4 | -7 | -478 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_rnd.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_rnd.c) | C | -120 | -3 | -7 | -130 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_rnd_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_btn_rnd_large.c) | C | -171 | -4 | -7 | -182 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_corner_left.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_corner_left.c) | C | -96 | -3 | -7 | -106 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_corner_left_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_corner_left_large.c) | C | -155 | -4 | -9 | -168 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_corner_right.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_corner_right.c) | C | -96 | -3 | -7 | -106 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_corner_right_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_corner_right_large.c) | C | -155 | -4 | -9 | -168 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_1.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_1.c) | C | -724 | -4 | -7 | -735 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_1_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_1_large.c) | C | -1,739 | -4 | -8 | -1,751 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_2.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_2.c) | C | -724 | -4 | -7 | -735 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_2_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_2_large.c) | C | -1,739 | -4 | -7 | -1,750 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_3.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_3.c) | C | -724 | -4 | -7 | -735 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_3_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_cover_3_large.c) | C | -1,739 | -4 | -7 | -1,750 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_1.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_1.c) | C | -120 | -4 | -7 | -131 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_1_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_1_large.c) | C | -147 | -4 | -9 | -160 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_2.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_2.c) | C | -120 | -4 | -7 | -131 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_2_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_2_large.c) | C | -151 | -4 | -8 | -163 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_3.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_3.c) | C | -120 | -4 | -7 | -131 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_3_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_3_large.c) | C | -155 | -4 | -8 | -167 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_4.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_4.c) | C | -120 | -4 | -7 | -131 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_4_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_icon_4_large.c) | C | -147 | -4 | -8 | -159 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_list_border.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_list_border.c) | C | -40 | -3 | -7 | -50 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_list_border_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_list_border_large.c) | C | -55 | -4 | -8 | -67 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_logo.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_logo.c) | C | -412 | -4 | -7 | -423 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_slider_knob.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_slider_knob.c) | C | -176 | -3 | -7 | -186 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_slider_knob_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_slider_knob_large.c) | C | -291 | -4 | -7 | -302 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_wave_bottom.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_wave_bottom.c) | C | -192 | -4 | -7 | -203 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_wave_bottom_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_wave_bottom_large.c) | C | -323 | -4 | -7 | -334 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_wave_top.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_wave_top.c) | C | -192 | -4 | -7 | -203 |
| [homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_wave_top_large.c](/homeStation/lib/lvgl/demos/music/assets/img_lv_demo_music_wave_top_large.c) | C | -323 | -4 | -7 | -334 |
| [homeStation/lib/lvgl/demos/music/assets/spectrum.py](/homeStation/lib/lvgl/demos/music/assets/spectrum.py) | Python | -28 | 0 | -5 | -33 |
| [homeStation/lib/lvgl/demos/music/assets/spectrum_1.h](/homeStation/lib/lvgl/demos/music/assets/spectrum_1.h) | C++ | -446 | 0 | -1 | -447 |
| [homeStation/lib/lvgl/demos/music/assets/spectrum_2.h](/homeStation/lib/lvgl/demos/music/assets/spectrum_2.h) | C++ | -782 | 0 | -1 | -783 |
| [homeStation/lib/lvgl/demos/music/assets/spectrum_3.h](/homeStation/lib/lvgl/demos/music/assets/spectrum_3.h) | C++ | -1,025 | 0 | -1 | -1,026 |
| [homeStation/lib/lvgl/demos/music/lv_demo_music.c](/homeStation/lib/lvgl/demos/music/lv_demo_music.c) | C | -212 | -29 | -36 | -277 |
| [homeStation/lib/lvgl/demos/music/lv_demo_music.h](/homeStation/lib/lvgl/demos/music/lv_demo_music.h) | C++ | -23 | -19 | -15 | -57 |
| [homeStation/lib/lvgl/demos/music/lv_demo_music_list.c](/homeStation/lib/lvgl/demos/music/lv_demo_music_list.c) | C | -161 | -29 | -42 | -232 |
| [homeStation/lib/lvgl/demos/music/lv_demo_music_list.h](/homeStation/lib/lvgl/demos/music/lv_demo_music_list.h) | C++ | -15 | -19 | -12 | -46 |
| [homeStation/lib/lvgl/demos/music/lv_demo_music_main.c](/homeStation/lib/lvgl/demos/music/lv_demo_music_main.c) | C | -811 | -56 | -147 | -1,014 |
| [homeStation/lib/lvgl/demos/music/lv_demo_music_main.h](/homeStation/lib/lvgl/demos/music/lv_demo_music_main.h) | C++ | -18 | -19 | -12 | -49 |
| [homeStation/lib/lvgl/demos/stress/README.md](/homeStation/lib/lvgl/demos/stress/README.md) | Markdown | -9 | 0 | -5 | -14 |
| [homeStation/lib/lvgl/demos/stress/lv_demo_stress.c](/homeStation/lib/lvgl/demos/stress/lv_demo_stress.c) | C | -357 | -41 | -78 | -476 |
| [homeStation/lib/lvgl/demos/stress/lv_demo_stress.h](/homeStation/lib/lvgl/demos/stress/lv_demo_stress.h) | C++ | -13 | -19 | -12 | -44 |
| [homeStation/lib/lvgl/demos/widgets/assets/img_clothes.c](/homeStation/lib/lvgl/demos/widgets/assets/img_clothes.c) | C | -251 | -4 | -7 | -262 |
| [homeStation/lib/lvgl/demos/widgets/assets/img_demo_widgets_avatar.c](/homeStation/lib/lvgl/demos/widgets/assets/img_demo_widgets_avatar.c) | C | -643 | -4 | -7 | -654 |
| [homeStation/lib/lvgl/demos/widgets/assets/img_lvgl_logo.c](/homeStation/lib/lvgl/demos/widgets/assets/img_lvgl_logo.c) | C | -199 | -4 | -7 | -210 |
| [homeStation/lib/lvgl/demos/widgets/lv_demo_widgets.c](/homeStation/lib/lvgl/demos/widgets/lv_demo_widgets.c) | C | -1,307 | -44 | -269 | -1,620 |
| [homeStation/lib/lvgl/demos/widgets/lv_demo_widgets.h](/homeStation/lib/lvgl/demos/widgets/lv_demo_widgets.h) | C++ | -12 | -19 | -10 | -41 |
| [homeStation/lib/lvgl/demos/widgets/lv_demo_widgets.py](/homeStation/lib/lvgl/demos/widgets/lv_demo_widgets.py) | Python | -457 | -23 | -93 | -573 |
| [homeStation/lib/lvgl/docs/CHANGELOG.md](/homeStation/lib/lvgl/docs/CHANGELOG.md) | Markdown | -1,832 | 0 | -277 | -2,109 |
| [homeStation/lib/lvgl/docs/CODE_OF_CONDUCT.md](/homeStation/lib/lvgl/docs/CODE_OF_CONDUCT.md) | Markdown | -28 | 0 | -19 | -47 |
| [homeStation/lib/lvgl/docs/CODING_STYLE.md](/homeStation/lib/lvgl/docs/CODING_STYLE.md) | Markdown | -95 | 0 | -29 | -124 |
| [homeStation/lib/lvgl/docs/CONTRIBUTING.md](/homeStation/lib/lvgl/docs/CONTRIBUTING.md) | Markdown | -209 | 0 | -88 | -297 |
| [homeStation/lib/lvgl/docs/ROADMAP.md](/homeStation/lib/lvgl/docs/ROADMAP.md) | Markdown | -24 | 0 | -4 | -28 |
| [homeStation/lib/lvgl/docs/_ext/lv_example.py](/homeStation/lib/lvgl/docs/_ext/lv_example.py) | Python | -80 | 0 | -19 | -99 |
| [homeStation/lib/lvgl/docs/_static/css/custom.css](/homeStation/lib/lvgl/docs/_static/css/custom.css) | CSS | -111 | -2 | -20 | -133 |
| [homeStation/lib/lvgl/docs/_static/css/fontawesome.min.css](/homeStation/lib/lvgl/docs/_static/css/fontawesome.min.css) | CSS | -1 | -4 | 0 | -5 |
| [homeStation/lib/lvgl/docs/_static/js/custom.js](/homeStation/lib/lvgl/docs/_static/js/custom.js) | JavaScript | -16 | -1 | -1 | -18 |
| [homeStation/lib/lvgl/docs/_templates/layout.html](/homeStation/lib/lvgl/docs/_templates/layout.html) | HTML | -27 | -1 | -4 | -32 |
| [homeStation/lib/lvgl/docs/_templates/page.html](/homeStation/lib/lvgl/docs/_templates/page.html) | HTML | -76 | 0 | -7 | -83 |
| [homeStation/lib/lvgl/docs/build.py](/homeStation/lib/lvgl/docs/build.py) | Python | -48 | -10 | -17 | -75 |
| [homeStation/lib/lvgl/docs/conf.py](/homeStation/lib/lvgl/docs/conf.py) | Python | -107 | -94 | -59 | -260 |
| [homeStation/lib/lvgl/docs/example_list.py](/homeStation/lib/lvgl/docs/example_list.py) | Python | -105 | -4 | -17 | -126 |
| [homeStation/lib/lvgl/docs/get-started/bindings/cpp.md](/homeStation/lib/lvgl/docs/get-started/bindings/cpp.md) | Markdown | -2 | 0 | -3 | -5 |
| [homeStation/lib/lvgl/docs/get-started/bindings/index.md](/homeStation/lib/lvgl/docs/get-started/bindings/index.md) | Markdown | -7 | 0 | -6 | -13 |
| [homeStation/lib/lvgl/docs/get-started/bindings/micropython.md](/homeStation/lib/lvgl/docs/get-started/bindings/micropython.md) | Markdown | -62 | 0 | -31 | -93 |
| [homeStation/lib/lvgl/docs/get-started/index.md](/homeStation/lib/lvgl/docs/get-started/index.md) | Markdown | -21 | 0 | -7 | -28 |
| [homeStation/lib/lvgl/docs/get-started/os/freertos.md](/homeStation/lib/lvgl/docs/get-started/os/freertos.md) | Markdown | -2 | 0 | -1 | -3 |
| [homeStation/lib/lvgl/docs/get-started/os/index.md](/homeStation/lib/lvgl/docs/get-started/os/index.md) | Markdown | -9 | 0 | -5 | -14 |
| [homeStation/lib/lvgl/docs/get-started/os/nuttx.md](/homeStation/lib/lvgl/docs/get-started/os/nuttx.md) | Markdown | -67 | 0 | -31 | -98 |
| [homeStation/lib/lvgl/docs/get-started/os/rt-thread.md](/homeStation/lib/lvgl/docs/get-started/os/rt-thread.md) | Markdown | -34 | 0 | -15 | -49 |
| [homeStation/lib/lvgl/docs/get-started/os/zephyr.md](/homeStation/lib/lvgl/docs/get-started/os/zephyr.md) | Markdown | -2 | 0 | -1 | -3 |
| [homeStation/lib/lvgl/docs/get-started/platforms/arduino.md](/homeStation/lib/lvgl/docs/get-started/platforms/arduino.md) | Markdown | -58 | 0 | -27 | -85 |
| [homeStation/lib/lvgl/docs/get-started/platforms/cmake.md](/homeStation/lib/lvgl/docs/get-started/platforms/cmake.md) | Markdown | -66 | 0 | -24 | -90 |
| [homeStation/lib/lvgl/docs/get-started/platforms/espressif.md](/homeStation/lib/lvgl/docs/get-started/platforms/espressif.md) | Markdown | -35 | 0 | -24 | -59 |
| [homeStation/lib/lvgl/docs/get-started/platforms/index.md](/homeStation/lib/lvgl/docs/get-started/platforms/index.md) | Markdown | -13 | 0 | -5 | -18 |
| [homeStation/lib/lvgl/docs/get-started/platforms/nxp.md](/homeStation/lib/lvgl/docs/get-started/platforms/nxp.md) | Markdown | -159 | 0 | -24 | -183 |
| [homeStation/lib/lvgl/docs/get-started/platforms/pc-simulator.md](/homeStation/lib/lvgl/docs/get-started/platforms/pc-simulator.md) | Markdown | -62 | 0 | -39 | -101 |
| [homeStation/lib/lvgl/docs/get-started/platforms/renesas.md](/homeStation/lib/lvgl/docs/get-started/platforms/renesas.md) | Markdown | -102 | 0 | -28 | -130 |
| [homeStation/lib/lvgl/docs/get-started/platforms/stm32.md](/homeStation/lib/lvgl/docs/get-started/platforms/stm32.md) | Markdown | -2 | 0 | -3 | -5 |
| [homeStation/lib/lvgl/docs/get-started/platforms/tasmota-berry.md](/homeStation/lib/lvgl/docs/get-started/platforms/tasmota-berry.md) | Markdown | -46 | 0 | -28 | -74 |
| [homeStation/lib/lvgl/docs/get-started/quick-overview.md](/homeStation/lib/lvgl/docs/get-started/quick-overview.md) | Markdown | -197 | 0 | -70 | -267 |
| [homeStation/lib/lvgl/docs/index.md](/homeStation/lib/lvgl/docs/index.md) | Markdown | -29 | 0 | -10 | -39 |
| [homeStation/lib/lvgl/docs/intro/index.md](/homeStation/lib/lvgl/docs/intro/index.md) | Markdown | -169 | 0 | -47 | -216 |
| [homeStation/lib/lvgl/docs/layouts/flex.md](/homeStation/lib/lvgl/docs/layouts/flex.md) | Markdown | -76 | 0 | -44 | -120 |
| [homeStation/lib/lvgl/docs/layouts/grid.md](/homeStation/lib/lvgl/docs/layouts/grid.md) | Markdown | -73 | 0 | -41 | -114 |
| [homeStation/lib/lvgl/docs/layouts/index.md](/homeStation/lib/lvgl/docs/layouts/index.md) | Markdown | -7 | 0 | -5 | -12 |
| [homeStation/lib/lvgl/docs/libs/bmp.md](/homeStation/lib/lvgl/docs/libs/bmp.md) | Markdown | -25 | 0 | -14 | -39 |
| [homeStation/lib/lvgl/docs/libs/ffmpeg.md](/homeStation/lib/lvgl/docs/libs/ffmpeg.md) | Markdown | -23 | 0 | -14 | -37 |
| [homeStation/lib/lvgl/docs/libs/freetype.md](/homeStation/lib/lvgl/docs/libs/freetype.md) | Markdown | -36 | 0 | -15 | -51 |
| [homeStation/lib/lvgl/docs/libs/fsdrv.md](/homeStation/lib/lvgl/docs/libs/fsdrv.md) | Markdown | -22 | 0 | -24 | -46 |
| [homeStation/lib/lvgl/docs/libs/gif.md](/homeStation/lib/lvgl/docs/libs/gif.md) | Markdown | -26 | 0 | -13 | -39 |
| [homeStation/lib/lvgl/docs/libs/index.md](/homeStation/lib/lvgl/docs/libs/index.md) | Markdown | -15 | 0 | -6 | -21 |
| [homeStation/lib/lvgl/docs/libs/png.md](/homeStation/lib/lvgl/docs/libs/png.md) | Markdown | -14 | 0 | -14 | -28 |
| [homeStation/lib/lvgl/docs/libs/qrcode.md](/homeStation/lib/lvgl/docs/libs/qrcode.md) | Markdown | -25 | 0 | -14 | -39 |
| [homeStation/lib/lvgl/docs/libs/rlottie.md](/homeStation/lib/lvgl/docs/libs/rlottie.md) | Markdown | -69 | 0 | -38 | -107 |
| [homeStation/lib/lvgl/docs/libs/sjpg.md](/homeStation/lib/lvgl/docs/libs/sjpg.md) | Markdown | -50 | 0 | -24 | -74 |
| [homeStation/lib/lvgl/docs/libs/tiny_ttf.md](/homeStation/lib/lvgl/docs/libs/tiny_ttf.md) | Markdown | -26 | 0 | -10 | -36 |
| [homeStation/lib/lvgl/docs/others/fragment.md](/homeStation/lib/lvgl/docs/others/fragment.md) | Markdown | -54 | 0 | -24 | -78 |
| [homeStation/lib/lvgl/docs/others/gridnav.md](/homeStation/lib/lvgl/docs/others/gridnav.md) | Markdown | -34 | 0 | -23 | -57 |
| [homeStation/lib/lvgl/docs/others/ime_pinyin.md](/homeStation/lib/lvgl/docs/others/ime_pinyin.md) | Markdown | -94 | 0 | -57 | -151 |
| [homeStation/lib/lvgl/docs/others/imgfont.md](/homeStation/lib/lvgl/docs/others/imgfont.md) | Markdown | -19 | 0 | -7 | -26 |
| [homeStation/lib/lvgl/docs/others/index.md](/homeStation/lib/lvgl/docs/others/index.md) | Markdown | -12 | 0 | -6 | -18 |
| [homeStation/lib/lvgl/docs/others/monkey.md](/homeStation/lib/lvgl/docs/others/monkey.md) | Markdown | -20 | 0 | -16 | -36 |
| [homeStation/lib/lvgl/docs/others/msg.md](/homeStation/lib/lvgl/docs/others/msg.md) | Markdown | -68 | 0 | -30 | -98 |
| [homeStation/lib/lvgl/docs/others/snapshot.md](/homeStation/lib/lvgl/docs/others/snapshot.md) | Markdown | -38 | 0 | -26 | -64 |
| [homeStation/lib/lvgl/docs/overview/animation.md](/homeStation/lib/lvgl/docs/overview/animation.md) | Markdown | -91 | 0 | -54 | -145 |
| [homeStation/lib/lvgl/docs/overview/color.md](/homeStation/lib/lvgl/docs/overview/color.md) | Markdown | -108 | 0 | -46 | -154 |
| [homeStation/lib/lvgl/docs/overview/coords.md](/homeStation/lib/lvgl/docs/overview/coords.md) | Markdown | -274 | 0 | -90 | -364 |
| [homeStation/lib/lvgl/docs/overview/display.md](/homeStation/lib/lvgl/docs/overview/display.md) | Markdown | -64 | 0 | -40 | -104 |
| [homeStation/lib/lvgl/docs/overview/drawing.md](/homeStation/lib/lvgl/docs/overview/drawing.md) | Markdown | -154 | 0 | -68 | -222 |
| [homeStation/lib/lvgl/docs/overview/event.md](/homeStation/lib/lvgl/docs/overview/event.md) | Markdown | -127 | 0 | -47 | -174 |
| [homeStation/lib/lvgl/docs/overview/file-system.md](/homeStation/lib/lvgl/docs/overview/file-system.md) | Markdown | -93 | 0 | -39 | -132 |
| [homeStation/lib/lvgl/docs/overview/font.md](/homeStation/lib/lvgl/docs/overview/font.md) | Markdown | -199 | 0 | -67 | -266 |
| [homeStation/lib/lvgl/docs/overview/image.md](/homeStation/lib/lvgl/docs/overview/image.md) | Markdown | -231 | 0 | -100 | -331 |
| [homeStation/lib/lvgl/docs/overview/indev.md](/homeStation/lib/lvgl/docs/overview/indev.md) | Markdown | -103 | 0 | -48 | -151 |
| [homeStation/lib/lvgl/docs/overview/index.md](/homeStation/lib/lvgl/docs/overview/index.md) | Markdown | -23 | 0 | -7 | -30 |
| [homeStation/lib/lvgl/docs/overview/layer.md](/homeStation/lib/lvgl/docs/overview/layer.md) | Markdown | -37 | 0 | -20 | -57 |
| [homeStation/lib/lvgl/docs/overview/new_widget.md](/homeStation/lib/lvgl/docs/overview/new_widget.md) | Markdown | -1 | 0 | -3 | -4 |
| [homeStation/lib/lvgl/docs/overview/object.md](/homeStation/lib/lvgl/docs/overview/object.md) | Markdown | -150 | 0 | -74 | -224 |
| [homeStation/lib/lvgl/docs/overview/renderers/arm-2d.md](/homeStation/lib/lvgl/docs/overview/renderers/arm-2d.md) | Markdown | -15 | 0 | -18 | -33 |
| [homeStation/lib/lvgl/docs/overview/renderers/dma2d.md](/homeStation/lib/lvgl/docs/overview/renderers/dma2d.md) | Markdown | -2 | 0 | -3 | -5 |
| [homeStation/lib/lvgl/docs/overview/renderers/index.md](/homeStation/lib/lvgl/docs/overview/renderers/index.md) | Markdown | -10 | 0 | -7 | -17 |
| [homeStation/lib/lvgl/docs/overview/renderers/pxp-vglite.md](/homeStation/lib/lvgl/docs/overview/renderers/pxp-vglite.md) | Markdown | -2 | 0 | -3 | -5 |
| [homeStation/lib/lvgl/docs/overview/renderers/sdl.md](/homeStation/lib/lvgl/docs/overview/renderers/sdl.md) | Markdown | -2 | 0 | -3 | -5 |
| [homeStation/lib/lvgl/docs/overview/renderers/sw.md](/homeStation/lib/lvgl/docs/overview/renderers/sw.md) | Markdown | -2 | 0 | -3 | -5 |
| [homeStation/lib/lvgl/docs/overview/scroll.md](/homeStation/lib/lvgl/docs/overview/scroll.md) | Markdown | -140 | 0 | -56 | -196 |
| [homeStation/lib/lvgl/docs/overview/style-props.md](/homeStation/lib/lvgl/docs/overview/style-props.md) | Markdown | -703 | 0 | -97 | -800 |
| [homeStation/lib/lvgl/docs/overview/style.md](/homeStation/lib/lvgl/docs/overview/style.md) | Markdown | -274 | 0 | -88 | -362 |
| [homeStation/lib/lvgl/docs/overview/timer.md](/homeStation/lib/lvgl/docs/overview/timer.md) | Markdown | -64 | 0 | -36 | -100 |
| [homeStation/lib/lvgl/docs/porting/display.md](/homeStation/lib/lvgl/docs/porting/display.md) | Markdown | -188 | 0 | -60 | -248 |
| [homeStation/lib/lvgl/docs/porting/gpu.md](/homeStation/lib/lvgl/docs/porting/gpu.md) | Markdown | -157 | 0 | -42 | -199 |
| [homeStation/lib/lvgl/docs/porting/indev.md](/homeStation/lib/lvgl/docs/porting/indev.md) | Markdown | -150 | 0 | -57 | -207 |
| [homeStation/lib/lvgl/docs/porting/index.md](/homeStation/lib/lvgl/docs/porting/index.md) | Markdown | -14 | 0 | -7 | -21 |
| [homeStation/lib/lvgl/docs/porting/log.md](/homeStation/lib/lvgl/docs/porting/log.md) | Markdown | -33 | 0 | -17 | -50 |
| [homeStation/lib/lvgl/docs/porting/os.md](/homeStation/lib/lvgl/docs/porting/os.md) | Markdown | -39 | 0 | -12 | -51 |
| [homeStation/lib/lvgl/docs/porting/project.md](/homeStation/lib/lvgl/docs/porting/project.md) | Markdown | -42 | 0 | -25 | -67 |
| [homeStation/lib/lvgl/docs/porting/sleep.md](/homeStation/lib/lvgl/docs/porting/sleep.md) | Markdown | -23 | 0 | -5 | -28 |
| [homeStation/lib/lvgl/docs/porting/tick.md](/homeStation/lib/lvgl/docs/porting/tick.md) | Markdown | -20 | 0 | -12 | -32 |
| [homeStation/lib/lvgl/docs/porting/timer-handler.md](/homeStation/lib/lvgl/docs/porting/timer-handler.md) | Markdown | -29 | 0 | -10 | -39 |
| [homeStation/lib/lvgl/docs/widgets/core/arc.md](/homeStation/lib/lvgl/docs/widgets/core/arc.md) | Markdown | -76 | 0 | -41 | -117 |
| [homeStation/lib/lvgl/docs/widgets/core/bar.md](/homeStation/lib/lvgl/docs/widgets/core/bar.md) | Markdown | -39 | 0 | -24 | -63 |
| [homeStation/lib/lvgl/docs/widgets/core/btn.md](/homeStation/lib/lvgl/docs/widgets/core/btn.md) | Markdown | -27 | 0 | -20 | -47 |
| [homeStation/lib/lvgl/docs/widgets/core/btnmatrix.md](/homeStation/lib/lvgl/docs/widgets/core/btnmatrix.md) | Markdown | -66 | 0 | -30 | -96 |
| [homeStation/lib/lvgl/docs/widgets/core/canvas.md](/homeStation/lib/lvgl/docs/widgets/core/canvas.md) | Markdown | -71 | 0 | -33 | -104 |
| [homeStation/lib/lvgl/docs/widgets/core/checkbox.md](/homeStation/lib/lvgl/docs/widgets/core/checkbox.md) | Markdown | -46 | 0 | -27 | -73 |
| [homeStation/lib/lvgl/docs/widgets/core/dropdown.md](/homeStation/lib/lvgl/docs/widgets/core/dropdown.md) | Markdown | -66 | 0 | -40 | -106 |
| [homeStation/lib/lvgl/docs/widgets/core/img.md](/homeStation/lib/lvgl/docs/widgets/core/img.md) | Markdown | -89 | 0 | -51 | -140 |
| [homeStation/lib/lvgl/docs/widgets/core/index.md](/homeStation/lib/lvgl/docs/widgets/core/index.md) | Markdown | -20 | 0 | -7 | -27 |
| [homeStation/lib/lvgl/docs/widgets/core/label.md](/homeStation/lib/lvgl/docs/widgets/core/label.md) | Markdown | -64 | 0 | -31 | -95 |
| [homeStation/lib/lvgl/docs/widgets/core/line.md](/homeStation/lib/lvgl/docs/widgets/core/line.md) | Markdown | -29 | 0 | -20 | -49 |
| [homeStation/lib/lvgl/docs/widgets/core/roller.md](/homeStation/lib/lvgl/docs/widgets/core/roller.md) | Markdown | -35 | 0 | -24 | -59 |
| [homeStation/lib/lvgl/docs/widgets/core/slider.md](/homeStation/lib/lvgl/docs/widgets/core/slider.md) | Markdown | -50 | 0 | -25 | -75 |
| [homeStation/lib/lvgl/docs/widgets/core/switch.md](/homeStation/lib/lvgl/docs/widgets/core/switch.md) | Markdown | -30 | 0 | -24 | -54 |
| [homeStation/lib/lvgl/docs/widgets/core/table.md](/homeStation/lib/lvgl/docs/widgets/core/table.md) | Markdown | -53 | 0 | -39 | -92 |
| [homeStation/lib/lvgl/docs/widgets/core/textarea.md](/homeStation/lib/lvgl/docs/widgets/core/textarea.md) | Markdown | -80 | 0 | -43 | -123 |
| [homeStation/lib/lvgl/docs/widgets/extra/animimg.md](/homeStation/lib/lvgl/docs/widgets/extra/animimg.md) | Markdown | -25 | 0 | -25 | -50 |
| [homeStation/lib/lvgl/docs/widgets/extra/calendar.md](/homeStation/lib/lvgl/docs/widgets/extra/calendar.md) | Markdown | -54 | 0 | -32 | -86 |
| [homeStation/lib/lvgl/docs/widgets/extra/chart.md](/homeStation/lib/lvgl/docs/widgets/extra/chart.md) | Markdown | -144 | 0 | -50 | -194 |
| [homeStation/lib/lvgl/docs/widgets/extra/colorwheel.md](/homeStation/lib/lvgl/docs/widgets/extra/colorwheel.md) | Markdown | -32 | 0 | -24 | -56 |
| [homeStation/lib/lvgl/docs/widgets/extra/imgbtn.md](/homeStation/lib/lvgl/docs/widgets/extra/imgbtn.md) | Markdown | -39 | 0 | -28 | -67 |
| [homeStation/lib/lvgl/docs/widgets/extra/index.md](/homeStation/lib/lvgl/docs/widgets/extra/index.md) | Markdown | -22 | 0 | -6 | -28 |
| [homeStation/lib/lvgl/docs/widgets/extra/keyboard.md](/homeStation/lib/lvgl/docs/widgets/extra/keyboard.md) | Markdown | -61 | 0 | -32 | -93 |
| [homeStation/lib/lvgl/docs/widgets/extra/led.md](/homeStation/lib/lvgl/docs/widgets/extra/led.md) | Markdown | -33 | 0 | -22 | -55 |
| [homeStation/lib/lvgl/docs/widgets/extra/list.md](/homeStation/lib/lvgl/docs/widgets/extra/list.md) | Markdown | -30 | 0 | -22 | -52 |
| [homeStation/lib/lvgl/docs/widgets/extra/menu.md](/homeStation/lib/lvgl/docs/widgets/extra/menu.md) | Markdown | -63 | 0 | -27 | -90 |
| [homeStation/lib/lvgl/docs/widgets/extra/meter.md](/homeStation/lib/lvgl/docs/widgets/extra/meter.md) | Markdown | -75 | 0 | -39 | -114 |
| [homeStation/lib/lvgl/docs/widgets/extra/msgbox.md](/homeStation/lib/lvgl/docs/widgets/extra/msgbox.md) | Markdown | -44 | 0 | -24 | -68 |
| [homeStation/lib/lvgl/docs/widgets/extra/span.md](/homeStation/lib/lvgl/docs/widgets/extra/span.md) | Markdown | -53 | 0 | -33 | -86 |
| [homeStation/lib/lvgl/docs/widgets/extra/spinbox.md](/homeStation/lib/lvgl/docs/widgets/extra/spinbox.md) | Markdown | -36 | 0 | -24 | -60 |
| [homeStation/lib/lvgl/docs/widgets/extra/spinner.md](/homeStation/lib/lvgl/docs/widgets/extra/spinner.md) | Markdown | -24 | 0 | -21 | -45 |
| [homeStation/lib/lvgl/docs/widgets/extra/tabview.md](/homeStation/lib/lvgl/docs/widgets/extra/tabview.md) | Markdown | -42 | 0 | -31 | -73 |
| [homeStation/lib/lvgl/docs/widgets/extra/tileview.md](/homeStation/lib/lvgl/docs/widgets/extra/tileview.md) | Markdown | -30 | 0 | -25 | -55 |
| [homeStation/lib/lvgl/docs/widgets/extra/win.md](/homeStation/lib/lvgl/docs/widgets/extra/win.md) | Markdown | -35 | 0 | -27 | -62 |
| [homeStation/lib/lvgl/docs/widgets/index.md](/homeStation/lib/lvgl/docs/widgets/index.md) | Markdown | -8 | 0 | -6 | -14 |
| [homeStation/lib/lvgl/docs/widgets/obj.md](/homeStation/lib/lvgl/docs/widgets/obj.md) | Markdown | -135 | 0 | -64 | -199 |
| [homeStation/lib/lvgl/env_support/cmake/custom.cmake](/homeStation/lib/lvgl/env_support/cmake/custom.cmake) | CMake | -69 | 0 | -17 | -86 |
| [homeStation/lib/lvgl/env_support/cmake/esp.cmake](/homeStation/lib/lvgl/env_support/cmake/esp.cmake) | CMake | -48 | 0 | -7 | -55 |
| [homeStation/lib/lvgl/env_support/cmake/micropython.cmake](/homeStation/lib/lvgl/env_support/cmake/micropython.cmake) | CMake | -17 | 0 | -2 | -19 |
| [homeStation/lib/lvgl/env_support/cmake/zephyr.cmake](/homeStation/lib/lvgl/env_support/cmake/zephyr.cmake) | CMake | -8 | 0 | -7 | -15 |
| [homeStation/lib/lvgl/env_support/cmsis-pack/README.md](/homeStation/lib/lvgl/env_support/cmsis-pack/README.md) | Markdown | -147 | 0 | -50 | -197 |
| [homeStation/lib/lvgl/env_support/cmsis-pack/gen_pack.sh](/homeStation/lib/lvgl/env_support/cmsis-pack/gen_pack.sh) | Shell Script | -148 | -51 | -32 | -231 |
| [homeStation/lib/lvgl/env_support/cmsis-pack/lv_conf_cmsis.h](/homeStation/lib/lvgl/env_support/cmsis-pack/lv_conf_cmsis.h) | C++ | -302 | -260 | -157 | -719 |
| [homeStation/lib/lvgl/env_support/rt-thread/SConscript](/homeStation/lib/lvgl/env_support/rt-thread/SConscript) | Python | -55 | -1 | -14 | -70 |
| [homeStation/lib/lvgl/env_support/rt-thread/lv_rt_thread_conf.h](/homeStation/lib/lvgl/env_support/rt-thread/lv_rt_thread_conf.h) | C++ | -40 | -31 | -22 | -93 |
| [homeStation/lib/lvgl/env_support/rt-thread/lv_rt_thread_port.c](/homeStation/lib/lvgl/env_support/rt-thread/lv_rt_thread_port.c) | C | -58 | -11 | -16 | -85 |
| [homeStation/lib/lvgl/env_support/rt-thread/squareline/README.md](/homeStation/lib/lvgl/env_support/rt-thread/squareline/README.md) | Markdown | -2 | 0 | -3 | -5 |
| [homeStation/lib/lvgl/env_support/rt-thread/squareline/SConscript](/homeStation/lib/lvgl/env_support/rt-thread/squareline/SConscript) | Python | -19 | -1 | -6 | -26 |
| [homeStation/lib/lvgl/env_support/rt-thread/squareline/lv_ui_entry.c](/homeStation/lib/lvgl/env_support/rt-thread/squareline/lv_ui_entry.c) | C | -7 | -9 | -4 | -20 |
| [homeStation/lib/lvgl/env_support/rt-thread/squareline/ui/lvgl/lvgl.h](/homeStation/lib/lvgl/env_support/rt-thread/squareline/ui/lvgl/lvgl.h) | C++ | -3 | -9 | -4 | -16 |
| [homeStation/lib/lvgl/env_support/zephyr/module.yml](/homeStation/lib/lvgl/env_support/zephyr/module.yml) | YAML | -2 | 0 | -1 | -3 |
| [homeStation/lib/lvgl/examples/anim/index.rst](/homeStation/lib/lvgl/examples/anim/index.rst) | reStructuredText | -9 | -3 | -6 | -18 |
| [homeStation/lib/lvgl/examples/anim/lv_example_anim.h](/homeStation/lib/lvgl/examples/anim/lv_example_anim.h) | C++ | -13 | -19 | -10 | -42 |
| [homeStation/lib/lvgl/examples/anim/lv_example_anim_1.c](/homeStation/lib/lvgl/examples/anim/lv_example_anim_1.c) | C | -42 | -3 | -9 | -54 |
| [homeStation/lib/lvgl/examples/anim/lv_example_anim_1.py](/homeStation/lib/lvgl/examples/anim/lv_example_anim_1.py) | Python | -29 | -3 | -10 | -42 |
| [homeStation/lib/lvgl/examples/anim/lv_example_anim_2.c](/homeStation/lib/lvgl/examples/anim/lv_example_anim_2.c) | C | -33 | -3 | -10 | -46 |
| [homeStation/lib/lvgl/examples/anim/lv_example_anim_2.py](/homeStation/lib/lvgl/examples/anim/lv_example_anim_2.py) | Python | -32 | -3 | -7 | -42 |
| [homeStation/lib/lvgl/examples/anim/lv_example_anim_3.c](/homeStation/lib/lvgl/examples/anim/lv_example_anim_3.c) | C | -133 | -10 | -23 | -166 |
| [homeStation/lib/lvgl/examples/anim/lv_example_anim_3.py](/homeStation/lib/lvgl/examples/anim/lv_example_anim_3.py) | Python | -94 | -9 | -21 | -124 |
| [homeStation/lib/lvgl/examples/anim/lv_example_anim_timeline_1.c](/homeStation/lib/lvgl/examples/anim/lv_example_anim_timeline_1.c) | C | -148 | -12 | -33 | -193 |
| [homeStation/lib/lvgl/examples/anim/lv_example_anim_timeline_1.py](/homeStation/lib/lvgl/examples/anim/lv_example_anim_timeline_1.py) | Python | -107 | -7 | -30 | -144 |
| [homeStation/lib/lvgl/examples/arduino/LVGL_Arduino/LVGL_Arduino.ino](/homeStation/lib/lvgl/examples/arduino/LVGL_Arduino/LVGL_Arduino.ino) | C++ | -81 | -29 | -31 | -141 |
| [homeStation/lib/lvgl/examples/assets/animimg001.c](/homeStation/lib/lvgl/examples/assets/animimg001.c) | C | -707 | -4 | -7 | -718 |
| [homeStation/lib/lvgl/examples/assets/animimg002.c](/homeStation/lib/lvgl/examples/assets/animimg002.c) | C | -707 | -4 | -7 | -718 |
| [homeStation/lib/lvgl/examples/assets/animimg003.c](/homeStation/lib/lvgl/examples/assets/animimg003.c) | C | -707 | -4 | -7 | -718 |
| [homeStation/lib/lvgl/examples/assets/emoji/img_emoji_F617.c](/homeStation/lib/lvgl/examples/assets/emoji/img_emoji_F617.c) | C | -318 | -4 | -3 | -325 |
| [homeStation/lib/lvgl/examples/assets/img_caret_down.c](/homeStation/lib/lvgl/examples/assets/img_caret_down.c) | C | -59 | -4 | -7 | -70 |
| [homeStation/lib/lvgl/examples/assets/img_cogwheel_alpha16.c](/homeStation/lib/lvgl/examples/assets/img_cogwheel_alpha16.c) | C | -119 | 0 | -7 | -126 |
| [homeStation/lib/lvgl/examples/assets/img_cogwheel_argb.c](/homeStation/lib/lvgl/examples/assets/img_cogwheel_argb.c) | C | -427 | -3 | -7 | -437 |
| [homeStation/lib/lvgl/examples/assets/img_cogwheel_chroma_keyed.c](/homeStation/lib/lvgl/examples/assets/img_cogwheel_chroma_keyed.c) | C | -427 | -4 | -7 | -438 |
| [homeStation/lib/lvgl/examples/assets/img_cogwheel_indexed16.c](/homeStation/lib/lvgl/examples/assets/img_cogwheel_indexed16.c) | C | -135 | 0 | -8 | -143 |
| [homeStation/lib/lvgl/examples/assets/img_cogwheel_rgb.c](/homeStation/lib/lvgl/examples/assets/img_cogwheel_rgb.c) | C | -427 | -4 | -7 | -438 |
| [homeStation/lib/lvgl/examples/assets/img_hand.c](/homeStation/lib/lvgl/examples/assets/img_hand.c) | C | -63 | -3 | -7 | -73 |
| [homeStation/lib/lvgl/examples/assets/img_skew_strip.c](/homeStation/lib/lvgl/examples/assets/img_skew_strip.c) | C | -107 | -4 | -7 | -118 |
| [homeStation/lib/lvgl/examples/assets/img_star.c](/homeStation/lib/lvgl/examples/assets/img_star.c) | C | -143 | -4 | -7 | -154 |
| [homeStation/lib/lvgl/examples/assets/imgbtn_left.c](/homeStation/lib/lvgl/examples/assets/imgbtn_left.c) | C | -227 | -4 | -30 | -261 |
| [homeStation/lib/lvgl/examples/assets/imgbtn_mid.c](/homeStation/lib/lvgl/examples/assets/imgbtn_mid.c) | C | -223 | -4 | -7 | -234 |
| [homeStation/lib/lvgl/examples/assets/imgbtn_right.c](/homeStation/lib/lvgl/examples/assets/imgbtn_right.c) | C | -227 | -4 | -7 | -238 |
| [homeStation/lib/lvgl/examples/event/index.rst](/homeStation/lib/lvgl/examples/event/index.rst) | reStructuredText | -9 | -3 | -8 | -20 |
| [homeStation/lib/lvgl/examples/event/lv_example_event.h](/homeStation/lib/lvgl/examples/event/lv_example_event.h) | C++ | -13 | -19 | -10 | -42 |
| [homeStation/lib/lvgl/examples/event/lv_example_event_1.c](/homeStation/lib/lvgl/examples/event/lv_example_event_1.c) | C | -22 | -3 | -6 | -31 |
| [homeStation/lib/lvgl/examples/event/lv_example_event_1.py](/homeStation/lib/lvgl/examples/event/lv_example_event_1.py) | Python | -17 | -3 | -6 | -26 |
| [homeStation/lib/lvgl/examples/event/lv_example_event_2.c](/homeStation/lib/lvgl/examples/event/lv_example_event_2.c) | C | -36 | -3 | -8 | -47 |
| [homeStation/lib/lvgl/examples/event/lv_example_event_2.py](/homeStation/lib/lvgl/examples/event/lv_example_event_2.py) | Python | -19 | 0 | -4 | -23 |
| [homeStation/lib/lvgl/examples/event/lv_example_event_3.c](/homeStation/lib/lvgl/examples/event/lv_example_event_3.c) | C | -27 | -7 | -11 | -45 |
| [homeStation/lib/lvgl/examples/event/lv_example_event_3.py](/homeStation/lib/lvgl/examples/event/lv_example_event_3.py) | Python | -17 | -7 | -9 | -33 |
| [homeStation/lib/lvgl/examples/event/lv_example_event_4.c](/homeStation/lib/lvgl/examples/event/lv_example_event_4.c) | C | -54 | -4 | -9 | -67 |
| [homeStation/lib/lvgl/examples/get_started/index.rst](/homeStation/lib/lvgl/examples/get_started/index.rst) | reStructuredText | -9 | -3 | -7 | -19 |
| [homeStation/lib/lvgl/examples/get_started/lv_example_get_started.h](/homeStation/lib/lvgl/examples/get_started/lv_example_get_started.h) | C++ | -12 | -19 | -10 | -41 |
| [homeStation/lib/lvgl/examples/get_started/lv_example_get_started_1.c](/homeStation/lib/lvgl/examples/get_started/lv_example_get_started_1.c) | C | -24 | -4 | -7 | -35 |
| [homeStation/lib/lvgl/examples/get_started/lv_example_get_started_1.py](/homeStation/lib/lvgl/examples/get_started/lv_example_get_started_1.py) | Python | -19 | -4 | -7 | -30 |
| [homeStation/lib/lvgl/examples/get_started/lv_example_get_started_2.c](/homeStation/lib/lvgl/examples/get_started/lv_example_get_started_2.c) | C | -56 | -14 | -14 | -84 |
| [homeStation/lib/lvgl/examples/get_started/lv_example_get_started_2.py](/homeStation/lib/lvgl/examples/get_started/lv_example_get_started_2.py) | Python | -39 | -13 | -11 | -63 |
| [homeStation/lib/lvgl/examples/get_started/lv_example_get_started_3.c](/homeStation/lib/lvgl/examples/get_started/lv_example_get_started_3.c) | C | -20 | -6 | -8 | -34 |
| [homeStation/lib/lvgl/examples/get_started/lv_example_get_started_3.py](/homeStation/lib/lvgl/examples/get_started/lv_example_get_started_3.py) | Python | -10 | -6 | -7 | -23 |
| [homeStation/lib/lvgl/examples/header.py](/homeStation/lib/lvgl/examples/header.py) | Python | -2 | -1 | -3 | -6 |
| [homeStation/lib/lvgl/examples/layouts/flex/index.rst](/homeStation/lib/lvgl/examples/layouts/flex/index.rst) | reStructuredText | -18 | -6 | -14 | -38 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex.h](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex.h) | C++ | -15 | -19 | -10 | -44 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_1.c](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_1.c) | C | -29 | -7 | -9 | -45 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_1.py](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_1.py) | Python | -19 | -7 | -8 | -34 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_2.c](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_2.c) | C | -24 | -3 | -6 | -33 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_2.py](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_2.py) | Python | -15 | -3 | -5 | -23 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_3.c](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_3.c) | C | -21 | -3 | -7 | -31 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_3.py](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_3.py) | Python | -14 | -3 | -7 | -24 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_4.c](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_4.c) | C | -18 | -3 | -6 | -27 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_4.py](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_4.py) | Python | -10 | -3 | -4 | -17 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_5.c](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_5.c) | C | -39 | -3 | -10 | -52 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_5.py](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_5.py) | Python | -32 | -3 | -13 | -48 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_6.c](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_6.c) | C | -19 | -4 | -4 | -27 |
| [homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_6.py](/homeStation/lib/lvgl/examples/layouts/flex/lv_example_flex_6.py) | Python | -11 | -4 | -5 | -20 |
| [homeStation/lib/lvgl/examples/layouts/grid/index.rst](/homeStation/lib/lvgl/examples/layouts/grid/index.rst) | reStructuredText | -18 | -6 | -14 | -38 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid.h](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid.h) | C++ | -15 | -19 | -10 | -44 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_1.c](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_1.c) | C | -27 | -6 | -8 | -41 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_1.py](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_1.py) | Python | -17 | -6 | -7 | -30 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_2.c](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_2.c) | C | -44 | -9 | -11 | -64 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_2.py](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_2.py) | Python | -36 | -9 | -8 | -53 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_3.c](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_3.c) | C | -25 | -12 | -8 | -45 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_3.py](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_3.py) | Python | -15 | -12 | -10 | -37 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_4.c](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_4.c) | C | -26 | -7 | -9 | -42 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_4.py](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_4.py) | Python | -16 | -7 | -10 | -33 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_5.c](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_5.c) | C | -46 | -5 | -13 | -64 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_5.py](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_5.py) | Python | -37 | -5 | -11 | -53 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_6.c](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_6.c) | C | -26 | -6 | -8 | -40 |
| [homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_6.py](/homeStation/lib/lvgl/examples/layouts/grid/lv_example_grid_6.py) | Python | -16 | -6 | -6 | -28 |
| [homeStation/lib/lvgl/examples/layouts/lv_example_layout.h](/homeStation/lib/lvgl/examples/layouts/lv_example_layout.h) | C++ | -11 | -19 | -10 | -40 |
| [homeStation/lib/lvgl/examples/libs/bmp/index.rst](/homeStation/lib/lvgl/examples/libs/bmp/index.rst) | reStructuredText | -3 | -1 | -3 | -7 |
| [homeStation/lib/lvgl/examples/libs/bmp/lv_example_bmp.h](/homeStation/lib/lvgl/examples/libs/bmp/lv_example_bmp.h) | C++ | -10 | -19 | -10 | -39 |
| [homeStation/lib/lvgl/examples/libs/bmp/lv_example_bmp_1.c](/homeStation/lib/lvgl/examples/libs/bmp/lv_example_bmp_1.c) | C | -13 | -5 | -4 | -22 |
| [homeStation/lib/lvgl/examples/libs/bmp/lv_example_bmp_1.py](/homeStation/lib/lvgl/examples/libs/bmp/lv_example_bmp_1.py) | Python | -8 | -2 | -4 | -14 |
| [homeStation/lib/lvgl/examples/libs/ffmpeg/index.rst](/homeStation/lib/lvgl/examples/libs/ffmpeg/index.rst) | reStructuredText | -6 | -2 | -5 | -13 |
| [homeStation/lib/lvgl/examples/libs/ffmpeg/lv_example_ffmpeg.h](/homeStation/lib/lvgl/examples/libs/ffmpeg/lv_example_ffmpeg.h) | C++ | -11 | -19 | -10 | -40 |
| [homeStation/lib/lvgl/examples/libs/ffmpeg/lv_example_ffmpeg_1.c](/homeStation/lib/lvgl/examples/libs/ffmpeg/lv_example_ffmpeg_1.c) | C | -18 | -5 | -7 | -30 |
| [homeStation/lib/lvgl/examples/libs/ffmpeg/lv_example_ffmpeg_2.c](/homeStation/lib/lvgl/examples/libs/ffmpeg/lv_example_ffmpeg_2.c) | C | -20 | -7 | -6 | -33 |
| [homeStation/lib/lvgl/examples/libs/freetype/index.rst](/homeStation/lib/lvgl/examples/libs/freetype/index.rst) | reStructuredText | -3 | -1 | -3 | -7 |
| [homeStation/lib/lvgl/examples/libs/freetype/lv_example_freetype.h](/homeStation/lib/lvgl/examples/libs/freetype/lv_example_freetype.h) | C++ | -10 | -19 | -10 | -39 |
| [homeStation/lib/lvgl/examples/libs/freetype/lv_example_freetype_1.c](/homeStation/lib/lvgl/examples/libs/freetype/lv_example_freetype_1.c) | C | -31 | -9 | -7 | -47 |
| [homeStation/lib/lvgl/examples/libs/freetype/lv_example_freetype_1.py](/homeStation/lib/lvgl/examples/libs/freetype/lv_example_freetype_1.py) | Python | -16 | -3 | -4 | -23 |
| [homeStation/lib/lvgl/examples/libs/gif/img_bulb_gif.c](/homeStation/lib/lvgl/examples/libs/gif/img_bulb_gif.c) | C | -1,123 | 0 | -6 | -1,129 |
| [homeStation/lib/lvgl/examples/libs/gif/img_bulb_gif.py](/homeStation/lib/lvgl/examples/libs/gif/img_bulb_gif.py) | Python | -1,108 | 0 | -3 | -1,111 |
| [homeStation/lib/lvgl/examples/libs/gif/index.rst](/homeStation/lib/lvgl/examples/libs/gif/index.rst) | reStructuredText | -3 | -1 | -3 | -7 |
| [homeStation/lib/lvgl/examples/libs/gif/lv_example_gif.h](/homeStation/lib/lvgl/examples/libs/gif/lv_example_gif.h) | C++ | -10 | -19 | -10 | -39 |
| [homeStation/lib/lvgl/examples/libs/gif/lv_example_gif_1.c](/homeStation/lib/lvgl/examples/libs/gif/lv_example_gif_1.c) | C | -14 | -5 | -5 | -24 |
| [homeStation/lib/lvgl/examples/libs/gif/lv_example_gif_1.py](/homeStation/lib/lvgl/examples/libs/gif/lv_example_gif_1.py) | Python | -19 | -5 | -4 | -28 |
| [homeStation/lib/lvgl/examples/libs/lv_example_libs.h](/homeStation/lib/lvgl/examples/libs/lv_example_libs.h) | C++ | -17 | -19 | -10 | -46 |
| [homeStation/lib/lvgl/examples/libs/png/img_wink_png.c](/homeStation/lib/lvgl/examples/libs/png/img_wink_png.c) | C | -342 | 0 | -7 | -349 |
| [homeStation/lib/lvgl/examples/libs/png/img_wink_png.py](/homeStation/lib/lvgl/examples/libs/png/img_wink_png.py) | Python | -335 | 0 | -3 | -338 |
| [homeStation/lib/lvgl/examples/libs/png/index.rst](/homeStation/lib/lvgl/examples/libs/png/index.rst) | reStructuredText | -3 | -1 | -3 | -7 |
| [homeStation/lib/lvgl/examples/libs/png/lv_example_png.h](/homeStation/lib/lvgl/examples/libs/png/lv_example_png.h) | C++ | -10 | -19 | -10 | -39 |
| [homeStation/lib/lvgl/examples/libs/png/lv_example_png_1.c](/homeStation/lib/lvgl/examples/libs/png/lv_example_png_1.c) | C | -14 | -5 | -5 | -24 |
| [homeStation/lib/lvgl/examples/libs/png/lv_example_png_1.py](/homeStation/lib/lvgl/examples/libs/png/lv_example_png_1.py) | Python | -30 | -3 | -5 | -38 |
| [homeStation/lib/lvgl/examples/libs/qrcode/index.rst](/homeStation/lib/lvgl/examples/libs/qrcode/index.rst) | reStructuredText | -3 | -1 | -3 | -7 |
| [homeStation/lib/lvgl/examples/libs/qrcode/lv_example_qrcode.h](/homeStation/lib/lvgl/examples/libs/qrcode/lv_example_qrcode.h) | C++ | -10 | -19 | -10 | -39 |
| [homeStation/lib/lvgl/examples/libs/qrcode/lv_example_qrcode_1.c](/homeStation/lib/lvgl/examples/libs/qrcode/lv_example_qrcode_1.c) | C | -14 | -5 | -14 | -33 |
| [homeStation/lib/lvgl/examples/libs/qrcode/lv_example_qrcode_1.py](/homeStation/lib/lvgl/examples/libs/qrcode/lv_example_qrcode_1.py) | Python | -10 | -3 | -3 | -16 |
| [homeStation/lib/lvgl/examples/libs/rlottie/index.rst](/homeStation/lib/lvgl/examples/libs/rlottie/index.rst) | reStructuredText | -6 | -2 | -5 | -13 |
| [homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie.h](/homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie.h) | C++ | -11 | -19 | -10 | -40 |
| [homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_1.c](/homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_1.c) | C | -18 | -5 | -5 | -28 |
| [homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_1.py](/homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_1.py) | Python | -5 | -4 | -3 | -12 |
| [homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_2.c](/homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_2.c) | C | -18 | -6 | -5 | -29 |
| [homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_2.py](/homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_2.py) | Python | -4 | -1 | -2 | -7 |
| [homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.c](/homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.c) | C | -14 | -11 | -6 | -31 |
| [homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.json](/homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.json) | JSON | -1 | 0 | 0 | -1 |
| [homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.py](/homeStation/lib/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.py) | Python | -19 | 0 | -6 | -25 |
| [homeStation/lib/lvgl/examples/libs/sjpg/index.rst](/homeStation/lib/lvgl/examples/libs/sjpg/index.rst) | reStructuredText | -3 | -1 | -3 | -7 |
| [homeStation/lib/lvgl/examples/libs/sjpg/lv_example_sjpg.h](/homeStation/lib/lvgl/examples/libs/sjpg/lv_example_sjpg.h) | C++ | -10 | -19 | -10 | -39 |
| [homeStation/lib/lvgl/examples/libs/sjpg/lv_example_sjpg_1.c](/homeStation/lib/lvgl/examples/libs/sjpg/lv_example_sjpg_1.c) | C | -9 | -5 | -4 | -18 |
| [homeStation/lib/lvgl/examples/libs/sjpg/lv_example_sjpg_1.py](/homeStation/lib/lvgl/examples/libs/sjpg/lv_example_sjpg_1.py) | Python | -8 | -2 | -4 | -14 |
| [homeStation/lib/lvgl/examples/lv_examples.h](/homeStation/lib/lvgl/examples/lv_examples.h) | C++ | -20 | -19 | -11 | -50 |
| [homeStation/lib/lvgl/examples/lv_examples.mk](/homeStation/lib/lvgl/examples/lv_examples.mk) | Makefile | -1 | 0 | -1 | -2 |
| [homeStation/lib/lvgl/examples/others/fragment/index.rst](/homeStation/lib/lvgl/examples/others/fragment/index.rst) | reStructuredText | -6 | -2 | -9 | -17 |
| [homeStation/lib/lvgl/examples/others/fragment/lv_example_fragment.h](/homeStation/lib/lvgl/examples/others/fragment/lv_example_fragment.h) | C++ | -11 | -18 | -10 | -39 |
| [homeStation/lib/lvgl/examples/others/fragment/lv_example_fragment_1.c](/homeStation/lib/lvgl/examples/others/fragment/lv_example_fragment_1.c) | C | -41 | -5 | -15 | -61 |
| [homeStation/lib/lvgl/examples/others/fragment/lv_example_fragment_2.c](/homeStation/lib/lvgl/examples/others/fragment/lv_example_fragment_2.c) | C | -97 | -5 | -26 | -128 |
| [homeStation/lib/lvgl/examples/others/gridnav/index.rst](/homeStation/lib/lvgl/examples/others/gridnav/index.rst) | reStructuredText | -12 | -4 | -8 | -24 |
| [homeStation/lib/lvgl/examples/others/gridnav/lv_example_gridnav.h](/homeStation/lib/lvgl/examples/others/gridnav/lv_example_gridnav.h) | C++ | -13 | -19 | -10 | -42 |
| [homeStation/lib/lvgl/examples/others/gridnav/lv_example_gridnav_1.c](/homeStation/lib/lvgl/examples/others/gridnav/lv_example_gridnav_1.c) | C | -46 | -10 | -17 | -73 |
| [homeStation/lib/lvgl/examples/others/gridnav/lv_example_gridnav_2.c](/homeStation/lib/lvgl/examples/others/gridnav/lv_example_gridnav_2.c) | C | -32 | -5 | -8 | -45 |
| [homeStation/lib/lvgl/examples/others/gridnav/lv_example_gridnav_3.c](/homeStation/lib/lvgl/examples/others/gridnav/lv_example_gridnav_3.c) | C | -67 | -11 | -24 | -102 |
| [homeStation/lib/lvgl/examples/others/gridnav/lv_example_gridnav_4.c](/homeStation/lib/lvgl/examples/others/gridnav/lv_example_gridnav_4.c) | C | -32 | -6 | -10 | -48 |
| [homeStation/lib/lvgl/examples/others/ime/index.rst](/homeStation/lib/lvgl/examples/others/ime/index.rst) | reStructuredText | -6 | -2 | -5 | -13 |
| [homeStation/lib/lvgl/examples/others/ime/lv_example_ime_pinyin.h](/homeStation/lib/lvgl/examples/others/ime/lv_example_ime_pinyin.h) | C++ | -11 | -19 | -10 | -40 |
| [homeStation/lib/lvgl/examples/others/ime/lv_example_ime_pinyin_1.c](/homeStation/lib/lvgl/examples/others/ime/lv_example_ime_pinyin_1.c) | C | -42 | -5 | -10 | -57 |
| [homeStation/lib/lvgl/examples/others/ime/lv_example_ime_pinyin_2.c](/homeStation/lib/lvgl/examples/others/ime/lv_example_ime_pinyin_2.c) | C | -44 | -5 | -10 | -59 |
| [homeStation/lib/lvgl/examples/others/imgfont/index.rst](/homeStation/lib/lvgl/examples/others/imgfont/index.rst) | reStructuredText | -3 | -1 | -3 | -7 |
| [homeStation/lib/lvgl/examples/others/imgfont/lv_example_imgfont.h](/homeStation/lib/lvgl/examples/others/imgfont/lv_example_imgfont.h) | C++ | -10 | -19 | -10 | -39 |
| [homeStation/lib/lvgl/examples/others/imgfont/lv_example_imgfont_1.c](/homeStation/lib/lvgl/examples/others/imgfont/lv_example_imgfont_1.c) | C | -42 | -3 | -10 | -55 |
| [homeStation/lib/lvgl/examples/others/lv_example_others.h](/homeStation/lib/lvgl/examples/others/lv_example_others.h) | C++ | -16 | -19 | -10 | -45 |
| [homeStation/lib/lvgl/examples/others/monkey/index.rst](/homeStation/lib/lvgl/examples/others/monkey/index.rst) | reStructuredText | -9 | -3 | -7 | -19 |
| [homeStation/lib/lvgl/examples/others/monkey/lv_example_monkey.h](/homeStation/lib/lvgl/examples/others/monkey/lv_example_monkey.h) | C++ | -12 | -19 | -10 | -41 |
| [homeStation/lib/lvgl/examples/others/monkey/lv_example_monkey_1.c](/homeStation/lib/lvgl/examples/others/monkey/lv_example_monkey_1.c) | C | -13 | -2 | -4 | -19 |
| [homeStation/lib/lvgl/examples/others/monkey/lv_example_monkey_2.c](/homeStation/lib/lvgl/examples/others/monkey/lv_example_monkey_2.c) | C | -18 | -3 | -5 | -26 |
| [homeStation/lib/lvgl/examples/others/monkey/lv_example_monkey_3.c](/homeStation/lib/lvgl/examples/others/monkey/lv_example_monkey_3.c) | C | -24 | -3 | -7 | -34 |
| [homeStation/lib/lvgl/examples/others/msg/index.rst](/homeStation/lib/lvgl/examples/others/msg/index.rst) | reStructuredText | -9 | -3 | -9 | -21 |
| [homeStation/lib/lvgl/examples/others/msg/lv_example_msg.h](/homeStation/lib/lvgl/examples/others/msg/lv_example_msg.h) | C++ | -12 | -19 | -10 | -41 |
| [homeStation/lib/lvgl/examples/others/msg/lv_example_msg_1.c](/homeStation/lib/lvgl/examples/others/msg/lv_example_msg_1.c) | C | -31 | -8 | -11 | -50 |
| [homeStation/lib/lvgl/examples/others/msg/lv_example_msg_2.c](/homeStation/lib/lvgl/examples/others/msg/lv_example_msg_2.c) | C | -142 | -10 | -20 | -172 |
| [homeStation/lib/lvgl/examples/others/msg/lv_example_msg_3.c](/homeStation/lib/lvgl/examples/others/msg/lv_example_msg_3.c) | C | -120 | -13 | -22 | -155 |
| [homeStation/lib/lvgl/examples/others/snapshot/index.rst](/homeStation/lib/lvgl/examples/others/snapshot/index.rst) | reStructuredText | -3 | -1 | -5 | -9 |
| [homeStation/lib/lvgl/examples/others/snapshot/lv_example_snapshot.h](/homeStation/lib/lvgl/examples/others/snapshot/lv_example_snapshot.h) | C++ | -10 | -19 | -10 | -39 |
| [homeStation/lib/lvgl/examples/others/snapshot/lv_example_snapshot_1.c](/homeStation/lib/lvgl/examples/others/snapshot/lv_example_snapshot_1.c) | C | -47 | -3 | -9 | -59 |
| [homeStation/lib/lvgl/examples/others/snapshot/lv_example_snapshot_1.py](/homeStation/lib/lvgl/examples/others/snapshot/lv_example_snapshot_1.py) | Python | -51 | -7 | -14 | -72 |
| [homeStation/lib/lvgl/examples/porting/lv_port_disp_template.c](/homeStation/lib/lvgl/examples/porting/lv_port_disp_template.c) | C | -64 | -105 | -39 | -208 |
| [homeStation/lib/lvgl/examples/porting/lv_port_disp_template.h](/homeStation/lib/lvgl/examples/porting/lv_port_disp_template.h) | C++ | -19 | -25 | -14 | -58 |
| [homeStation/lib/lvgl/examples/porting/lv_port_fs_template.c](/homeStation/lib/lvgl/examples/porting/lv_port_fs_template.c) | C | -93 | -121 | -48 | -262 |
| [homeStation/lib/lvgl/examples/porting/lv_port_fs_template.h](/homeStation/lib/lvgl/examples/porting/lv_port_fs_template.h) | C++ | -13 | -20 | -12 | -45 |
| [homeStation/lib/lvgl/examples/porting/lv_port_indev_template.c](/homeStation/lib/lvgl/examples/porting/lv_port_indev_template.c) | C | -197 | -133 | -85 | -415 |
| [homeStation/lib/lvgl/examples/porting/lv_port_indev_template.h](/homeStation/lib/lvgl/examples/porting/lv_port_indev_template.h) | C++ | -13 | -20 | -13 | -46 |
| [homeStation/lib/lvgl/examples/scroll/index.rst](/homeStation/lib/lvgl/examples/scroll/index.rst) | reStructuredText | -18 | -6 | -10 | -34 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll.h](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll.h) | C++ | -15 | -19 | -11 | -45 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_1.c](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_1.c) | C | -31 | -4 | -9 | -44 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_1.py](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_1.py) | Python | -28 | -4 | -7 | -39 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_2.c](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_2.c) | C | -44 | -4 | -10 | -58 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_2.py](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_2.py) | Python | -30 | -4 | -14 | -48 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_3.c](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_3.c) | C | -37 | -3 | -10 | -50 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_3.py](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_3.py) | Python | -25 | -3 | -11 | -39 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_4.c](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_4.c) | C | -49 | -7 | -13 | -69 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_4.py](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_4.py) | Python | -45 | -7 | -11 | -63 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_5.c](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_5.c) | C | -15 | -3 | -6 | -24 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_5.py](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_5.py) | Python | -8 | -3 | -3 | -14 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_6.c](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_6.c) | C | -56 | -10 | -15 | -81 |
| [homeStation/lib/lvgl/examples/scroll/lv_example_scroll_6.py](/homeStation/lib/lvgl/examples/scroll/lv_example_scroll_6.py) | Python | -41 | -11 | -17 | -69 |
| [homeStation/lib/lvgl/examples/styles/index.rst](/homeStation/lib/lvgl/examples/styles/index.rst) | reStructuredText | -45 | -15 | -39 | -99 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style.h](/homeStation/lib/lvgl/examples/styles/lv_example_style.h) | C++ | -24 | -19 | -10 | -53 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_1.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_1.c) | C | -19 | -5 | -8 | -32 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_1.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_1.py) | Python | -13 | -5 | -7 | -25 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_10.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_10.c) | C | -24 | -8 | -9 | -41 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_10.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_10.py) | Python | -18 | -8 | -10 | -36 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_11.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_11.c) | C | -36 | -7 | -8 | -51 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_11.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_11.py) | Python | -30 | -7 | -7 | -44 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_12.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_12.c) | C | -15 | -4 | -6 | -25 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_12.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_12.py) | Python | -9 | -4 | -5 | -18 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_13.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_13.c) | C | -21 | -4 | -5 | -30 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_13.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_13.py) | Python | -15 | -4 | -4 | -23 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_14.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_14.c) | C | -38 | -9 | -18 | -65 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_14.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_14.py) | Python | -31 | -9 | -16 | -56 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_15.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_15.c) | C | -32 | -8 | -11 | -51 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_2.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_2.c) | C | -21 | -6 | -7 | -34 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_2.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_2.py) | Python | -12 | -6 | -4 | -22 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_3.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_3.c) | C | -18 | -6 | -6 | -30 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_3.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_3.py) | Python | -12 | -6 | -4 | -22 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_4.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_4.c) | C | -17 | -6 | -7 | -30 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_4.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_4.py) | Python | -11 | -6 | -5 | -22 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_5.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_5.c) | C | -16 | -8 | -6 | -30 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_5.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_5.py) | Python | -12 | -6 | -5 | -23 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_6.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_6.c) | C | -21 | -5 | -8 | -34 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_6.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_6.py) | Python | -27 | -8 | -9 | -44 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_7.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_7.c) | C | -13 | -4 | -5 | -22 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_7.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_7.py) | Python | -7 | -4 | -3 | -14 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_8.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_8.c) | C | -23 | -4 | -7 | -34 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_8.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_8.py) | Python | -17 | -4 | -7 | -28 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_9.c](/homeStation/lib/lvgl/examples/styles/lv_example_style_9.c) | C | -16 | -4 | -7 | -27 |
| [homeStation/lib/lvgl/examples/styles/lv_example_style_9.py](/homeStation/lib/lvgl/examples/styles/lv_example_style_9.py) | Python | -12 | -4 | -6 | -22 |
| [homeStation/lib/lvgl/examples/test_ex.sh](/homeStation/lib/lvgl/examples/test_ex.sh) | Shell Script | -3 | -1 | -1 | -5 |
| [homeStation/lib/lvgl/examples/widgets/animimg/index.rst](/homeStation/lib/lvgl/examples/widgets/animimg/index.rst) | reStructuredText | -4 | -1 | -3 | -8 |
| [homeStation/lib/lvgl/examples/widgets/animimg/lv_example_animimg_1.c](/homeStation/lib/lvgl/examples/widgets/animimg/lv_example_animimg_1.c) | C | -20 | 0 | -4 | -24 |
| [homeStation/lib/lvgl/examples/widgets/animimg/lv_example_animimg_1.py](/homeStation/lib/lvgl/examples/widgets/animimg/lv_example_animimg_1.py) | Python | -41 | -2 | -12 | -55 |
| [homeStation/lib/lvgl/examples/widgets/arc/index.rst](/homeStation/lib/lvgl/examples/widgets/arc/index.rst) | reStructuredText | -7 | -2 | -6 | -15 |
| [homeStation/lib/lvgl/examples/widgets/arc/lv_example_arc_1.c](/homeStation/lib/lvgl/examples/widgets/arc/lv_example_arc_1.c) | C | -23 | -3 | -10 | -36 |
| [homeStation/lib/lvgl/examples/widgets/arc/lv_example_arc_1.py](/homeStation/lib/lvgl/examples/widgets/arc/lv_example_arc_1.py) | Python | -4 | -1 | -4 | -9 |
| [homeStation/lib/lvgl/examples/widgets/arc/lv_example_arc_2.c](/homeStation/lib/lvgl/examples/widgets/arc/lv_example_arc_2.c) | C | -25 | -4 | -9 | -38 |
| [homeStation/lib/lvgl/examples/widgets/arc/lv_example_arc_2.py](/homeStation/lib/lvgl/examples/widgets/arc/lv_example_arc_2.py) | Python | -16 | -10 | -12 | -38 |
| [homeStation/lib/lvgl/examples/widgets/bar/index.rst](/homeStation/lib/lvgl/examples/widgets/bar/index.rst) | reStructuredText | -18 | -6 | -13 | -37 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_1.c](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_1.c) | C | -10 | 0 | -3 | -13 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_1.py](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_1.py) | Python | -4 | 0 | -2 | -6 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_2.c](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_2.c) | C | -25 | -3 | -7 | -35 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_2.py](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_2.py) | Python | -19 | -3 | -6 | -28 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_3.c](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_3.c) | C | -30 | -3 | -8 | -41 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_3.py](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_3.py) | Python | -22 | -3 | -8 | -33 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_4.c](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_4.c) | C | -19 | -3 | -6 | -28 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_4.py](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_4.py) | Python | -30 | -6 | -10 | -46 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_5.c](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_5.c) | C | -22 | -3 | -8 | -33 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_5.py](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_5.py) | Python | -15 | -3 | -5 | -23 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_6.c](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_6.c) | C | -51 | -5 | -14 | -70 |
| [homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_6.py](/homeStation/lib/lvgl/examples/widgets/bar/lv_example_bar_6.py) | Python | -37 | -6 | -12 | -55 |
| [homeStation/lib/lvgl/examples/widgets/bar/test.py](/homeStation/lib/lvgl/examples/widgets/bar/test.py) | Python | -39 | -7 | -12 | -58 |
| [homeStation/lib/lvgl/examples/widgets/btn/index.rst](/homeStation/lib/lvgl/examples/widgets/btn/index.rst) | reStructuredText | -9 | -3 | -9 | -21 |
| [homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_1.c](/homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_1.c) | C | -31 | 0 | -8 | -39 |
| [homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_1.py](/homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_1.py) | Python | -19 | -5 | -9 | -33 |
| [homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_2.c](/homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_2.c) | C | -44 | -7 | -15 | -66 |
| [homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_2.py](/homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_2.py) | Python | -38 | -7 | -16 | -61 |
| [homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_3.c](/homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_3.c) | C | -28 | -10 | -8 | -46 |
| [homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_3.py](/homeStation/lib/lvgl/examples/widgets/btn/lv_example_btn_3.py) | Python | -20 | -10 | -9 | -39 |
| [homeStation/lib/lvgl/examples/widgets/btnmatrix/index.rst](/homeStation/lib/lvgl/examples/widgets/btnmatrix/index.rst) | reStructuredText | -9 | -3 | -11 | -23 |
| [homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_1.c](/homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_1.c) | C | -27 | 0 | -7 | -34 |
| [homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_1.py](/homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_1.py) | Python | -17 | -1 | -7 | -25 |
| [homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_2.c](/homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_2.c) | C | -58 | -8 | -13 | -79 |
| [homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_2.py](/homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_2.py) | Python | -60 | -9 | -13 | -82 |
| [homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_3.c](/homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_3.c) | C | -50 | -5 | -14 | -69 |
| [homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_3.py](/homeStation/lib/lvgl/examples/widgets/btnmatrix/lv_example_btnmatrix_3.py) | Python | -48 | -5 | -12 | -65 |
| [homeStation/lib/lvgl/examples/widgets/calendar/index.rst](/homeStation/lib/lvgl/examples/widgets/calendar/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/calendar/lv_example_calendar_1.c](/homeStation/lib/lvgl/examples/widgets/calendar/lv_example_calendar_1.c) | C | -40 | -1 | -11 | -52 |
| [homeStation/lib/lvgl/examples/widgets/calendar/lv_example_calendar_1.py](/homeStation/lib/lvgl/examples/widgets/calendar/lv_example_calendar_1.py) | Python | -21 | -1 | -9 | -31 |
| [homeStation/lib/lvgl/examples/widgets/canvas/index.rst](/homeStation/lib/lvgl/examples/widgets/canvas/index.rst) | reStructuredText | -6 | -2 | -6 | -14 |
| [homeStation/lib/lvgl/examples/widgets/canvas/lv_example_canvas_1.c](/homeStation/lib/lvgl/examples/widgets/canvas/lv_example_canvas_1.c) | C | -40 | -2 | -12 | -54 |
| [homeStation/lib/lvgl/examples/widgets/canvas/lv_example_canvas_1.py](/homeStation/lib/lvgl/examples/widgets/canvas/lv_example_canvas_1.py) | Python | -33 | -2 | -9 | -44 |
| [homeStation/lib/lvgl/examples/widgets/canvas/lv_example_canvas_2.c](/homeStation/lib/lvgl/examples/widgets/canvas/lv_example_canvas_2.c) | C | -26 | -9 | -10 | -45 |
| [homeStation/lib/lvgl/examples/widgets/canvas/lv_example_canvas_2.py](/homeStation/lib/lvgl/examples/widgets/canvas/lv_example_canvas_2.py) | Python | -23 | -9 | -12 | -44 |
| [homeStation/lib/lvgl/examples/widgets/chart/index.rst](/homeStation/lib/lvgl/examples/widgets/chart/index.rst) | reStructuredText | -24 | -8 | -18 | -50 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_1.c](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_1.c) | C | -34 | -4 | -7 | -45 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_1.py](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_1.py) | Python | -19 | -4 | -4 | -27 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_2.c](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_2.c) | C | -97 | -13 | -21 | -131 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_2.py](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_2.py) | Python | -48 | -12 | -17 | -77 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_3.c](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_3.c) | C | -57 | -9 | -11 | -77 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_3.py](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_3.py) | Python | -33 | -10 | -10 | -53 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_4.c](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_4.c) | C | -64 | -6 | -17 | -87 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_4.py](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_4.py) | Python | -51 | -7 | -16 | -74 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_5.c](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_5.c) | C | -81 | -8 | -11 | -100 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_5.py](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_5.py) | Python | -69 | -7 | -14 | -90 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_6.c](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_6.c) | C | -67 | -3 | -18 | -88 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_6.py](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_6.py) | Python | -56 | -11 | -22 | -89 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_7.c](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_7.c) | C | -48 | -6 | -13 | -67 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_7.py](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_7.py) | Python | -47 | -15 | -16 | -78 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_8.c](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_8.c) | C | -79 | -28 | -25 | -132 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_8.py](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_8.py) | Python | -67 | -29 | -29 | -125 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_9.c](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_9.c) | C | -30 | -5 | -12 | -47 |
| [homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_9.py](/homeStation/lib/lvgl/examples/widgets/chart/lv_example_chart_9.py) | Python | -20 | -4 | -8 | -32 |
| [homeStation/lib/lvgl/examples/widgets/checkbox/index.rst](/homeStation/lib/lvgl/examples/widgets/checkbox/index.rst) | reStructuredText | -6 | -2 | -5 | -13 |
| [homeStation/lib/lvgl/examples/widgets/checkbox/lv_example_checkbox_1.c](/homeStation/lib/lvgl/examples/widgets/checkbox/lv_example_checkbox_1.c) | C | -35 | 0 | -9 | -44 |
| [homeStation/lib/lvgl/examples/widgets/checkbox/lv_example_checkbox_1.py](/homeStation/lib/lvgl/examples/widgets/checkbox/lv_example_checkbox_1.py) | Python | -28 | 0 | -9 | -37 |
| [homeStation/lib/lvgl/examples/widgets/checkbox/lv_example_checkbox_2.c](/homeStation/lib/lvgl/examples/widgets/checkbox/lv_example_checkbox_2.c) | C | -55 | -10 | -22 | -87 |
| [homeStation/lib/lvgl/examples/widgets/colorwheel/index.rst](/homeStation/lib/lvgl/examples/widgets/colorwheel/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/colorwheel/lv_example_colorwheel_1.c](/homeStation/lib/lvgl/examples/widgets/colorwheel/lv_example_colorwheel_1.c) | C | -10 | 0 | -4 | -14 |
| [homeStation/lib/lvgl/examples/widgets/colorwheel/lv_example_colorwheel_1.py](/homeStation/lib/lvgl/examples/widgets/colorwheel/lv_example_colorwheel_1.py) | Python | -3 | 0 | -2 | -5 |
| [homeStation/lib/lvgl/examples/widgets/dropdown/index.rst](/homeStation/lib/lvgl/examples/widgets/dropdown/index.rst) | reStructuredText | -9 | -3 | -9 | -21 |
| [homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_1.c](/homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_1.c) | C | -29 | -1 | -6 | -36 |
| [homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_1.py](/homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_1.py) | Python | -21 | -2 | -4 | -27 |
| [homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_2.c](/homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_2.c) | C | -29 | -3 | -8 | -40 |
| [homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_2.py](/homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_2.py) | Python | -25 | -3 | -7 | -35 |
| [homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_3.c](/homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_3.c) | C | -29 | -7 | -8 | -44 |
| [homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_3.py](/homeStation/lib/lvgl/examples/widgets/dropdown/lv_example_dropdown_3.py) | Python | -33 | -10 | -11 | -54 |
| [homeStation/lib/lvgl/examples/widgets/img/index.rst](/homeStation/lib/lvgl/examples/widgets/img/index.rst) | reStructuredText | -12 | -4 | -13 | -29 |
| [homeStation/lib/lvgl/examples/widgets/img/lv_example_img_1.c](/homeStation/lib/lvgl/examples/widgets/img/lv_example_img_1.c) | C | -14 | 0 | -5 | -19 |
| [homeStation/lib/lvgl/examples/widgets/img/lv_example_img_1.py](/homeStation/lib/lvgl/examples/widgets/img/lv_example_img_1.py) | Python | -24 | -3 | -6 | -33 |
| [homeStation/lib/lvgl/examples/widgets/img/lv_example_img_2.c](/homeStation/lib/lvgl/examples/widgets/img/lv_example_img_2.c) | C | -46 | -6 | -13 | -65 |
| [homeStation/lib/lvgl/examples/widgets/img/lv_example_img_2.py](/homeStation/lib/lvgl/examples/widgets/img/lv_example_img_2.py) | Python | -46 | -9 | -16 | -71 |
| [homeStation/lib/lvgl/examples/widgets/img/lv_example_img_3.c](/homeStation/lib/lvgl/examples/widgets/img/lv_example_img_3.c) | C | -31 | -4 | -9 | -44 |
| [homeStation/lib/lvgl/examples/widgets/img/lv_example_img_3.py](/homeStation/lib/lvgl/examples/widgets/img/lv_example_img_3.py) | Python | -42 | -7 | -13 | -62 |
| [homeStation/lib/lvgl/examples/widgets/img/lv_example_img_4.c](/homeStation/lib/lvgl/examples/widgets/img/lv_example_img_4.c) | C | -31 | -3 | -8 | -42 |
| [homeStation/lib/lvgl/examples/widgets/img/lv_example_img_4.py](/homeStation/lib/lvgl/examples/widgets/img/lv_example_img_4.py) | Python | -36 | -6 | -10 | -52 |
| [homeStation/lib/lvgl/examples/widgets/imgbtn/index.rst](/homeStation/lib/lvgl/examples/widgets/imgbtn/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/imgbtn/lv_example_imgbtn_1.c](/homeStation/lib/lvgl/examples/widgets/imgbtn/lv_example_imgbtn_1.c) | C | -29 | -4 | -9 | -42 |
| [homeStation/lib/lvgl/examples/widgets/imgbtn/lv_example_imgbtn_1.py](/homeStation/lib/lvgl/examples/widgets/imgbtn/lv_example_imgbtn_1.py) | Python | -54 | -6 | -15 | -75 |
| [homeStation/lib/lvgl/examples/widgets/keyboard/index.rst](/homeStation/lib/lvgl/examples/widgets/keyboard/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/keyboard/lv_example_keyboard_1.c](/homeStation/lib/lvgl/examples/widgets/keyboard/lv_example_keyboard_1.c) | C | -32 | -2 | -7 | -41 |
| [homeStation/lib/lvgl/examples/widgets/keyboard/lv_example_keyboard_1.py](/homeStation/lib/lvgl/examples/widgets/keyboard/lv_example_keyboard_1.py) | Python | -20 | -2 | -7 | -29 |
| [homeStation/lib/lvgl/examples/widgets/label/index.rst](/homeStation/lib/lvgl/examples/widgets/label/index.rst) | reStructuredText | -15 | -5 | -12 | -32 |
| [homeStation/lib/lvgl/examples/widgets/label/lv_example_label_1.c](/homeStation/lib/lvgl/examples/widgets/label/lv_example_label_1.c) | C | -19 | -3 | -4 | -26 |
| [homeStation/lib/lvgl/examples/widgets/label/lv_example_label_1.py](/homeStation/lib/lvgl/examples/widgets/label/lv_example_label_1.py) | Python | -13 | -3 | -4 | -20 |
| [homeStation/lib/lvgl/examples/widgets/label/lv_example_label_2.c](/homeStation/lib/lvgl/examples/widgets/label/lv_example_label_2.c) | C | -20 | -9 | -8 | -37 |
| [homeStation/lib/lvgl/examples/widgets/label/lv_example_label_2.py](/homeStation/lib/lvgl/examples/widgets/label/lv_example_label_2.py) | Python | -14 | -9 | -8 | -31 |
| [homeStation/lib/lvgl/examples/widgets/label/lv_example_label_3.c](/homeStation/lib/lvgl/examples/widgets/label/lv_example_label_3.c) | C | -24 | -3 | -5 | -32 |
| [homeStation/lib/lvgl/examples/widgets/label/lv_example_label_3.py](/homeStation/lib/lvgl/examples/widgets/label/lv_example_label_3.py) | Python | -24 | -4 | -9 | -37 |
| [homeStation/lib/lvgl/examples/widgets/label/lv_example_label_4.c](/homeStation/lib/lvgl/examples/widgets/label/lv_example_label_4.c) | C | -44 | -9 | -11 | -64 |
| [homeStation/lib/lvgl/examples/widgets/label/lv_example_label_5.c](/homeStation/lib/lvgl/examples/widgets/label/lv_example_label_5.c) | C | -20 | -5 | -6 | -31 |
| [homeStation/lib/lvgl/examples/widgets/label/lv_example_label_5.py](/homeStation/lib/lvgl/examples/widgets/label/lv_example_label_5.py) | Python | -5 | -3 | -3 | -11 |
| [homeStation/lib/lvgl/examples/widgets/led/index.rst](/homeStation/lib/lvgl/examples/widgets/led/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/led/lv_example_led_1.c](/homeStation/lib/lvgl/examples/widgets/led/lv_example_led_1.c) | C | -16 | -6 | -5 | -27 |
| [homeStation/lib/lvgl/examples/widgets/led/lv_example_led_1.py](/homeStation/lib/lvgl/examples/widgets/led/lv_example_led_1.py) | Python | -10 | -6 | -5 | -21 |
| [homeStation/lib/lvgl/examples/widgets/line/index.rst](/homeStation/lib/lvgl/examples/widgets/line/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/line/lv_example_line_1.c](/homeStation/lib/lvgl/examples/widgets/line/lv_example_line_1.c) | C | -17 | -3 | -5 | -25 |
| [homeStation/lib/lvgl/examples/widgets/line/lv_example_line_1.py](/homeStation/lib/lvgl/examples/widgets/line/lv_example_line_1.py) | Python | -14 | -3 | -4 | -21 |
| [homeStation/lib/lvgl/examples/widgets/list/index.rst](/homeStation/lib/lvgl/examples/widgets/list/index.rst) | reStructuredText | -6 | -2 | -6 | -14 |
| [homeStation/lib/lvgl/examples/widgets/list/lv_example_list_1.c](/homeStation/lib/lvgl/examples/widgets/list/lv_example_list_1.c) | C | -44 | -2 | -8 | -54 |
| [homeStation/lib/lvgl/examples/widgets/list/lv_example_list_1.py](/homeStation/lib/lvgl/examples/widgets/list/lv_example_list_1.py) | Python | -33 | -2 | -6 | -41 |
| [homeStation/lib/lvgl/examples/widgets/list/lv_example_list_2.c](/homeStation/lib/lvgl/examples/widgets/list/lv_example_list_2.c) | C | -136 | -5 | -29 | -170 |
| [homeStation/lib/lvgl/examples/widgets/list/lv_example_list_2.py](/homeStation/lib/lvgl/examples/widgets/list/lv_example_list_2.py) | Python | -116 | -3 | -19 | -138 |
| [homeStation/lib/lvgl/examples/widgets/list/test.py](/homeStation/lib/lvgl/examples/widgets/list/test.py) | Python | -35 | -3 | -6 | -44 |
| [homeStation/lib/lvgl/examples/widgets/lv_example_widgets.h](/homeStation/lib/lvgl/examples/widgets/lv_example_widgets.h) | C++ | -88 | -19 | -42 | -149 |
| [homeStation/lib/lvgl/examples/widgets/menu/index.rst](/homeStation/lib/lvgl/examples/widgets/menu/index.rst) | reStructuredText | -15 | -5 | -12 | -32 |
| [homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_1.c](/homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_1.c) | C | -27 | -3 | -11 | -41 |
| [homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_1.py](/homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_1.py) | Python | -19 | -3 | -6 | -28 |
| [homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_2.c](/homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_2.c) | C | -38 | -2 | -13 | -53 |
| [homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_2.py](/homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_2.py) | Python | -26 | -3 | -7 | -36 |
| [homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_3.c](/homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_3.c) | C | -40 | -4 | -16 | -60 |
| [homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_3.py](/homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_3.py) | Python | -29 | -3 | -11 | -43 |
| [homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_4.c](/homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_4.c) | C | -48 | -4 | -19 | -71 |
| [homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_4.py](/homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_4.py) | Python | -33 | -3 | -11 | -47 |
| [homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_5.c](/homeStation/lib/lvgl/examples/widgets/menu/lv_example_menu_5.c) | C | -163 | -2 | -35 | -200 |
| [homeStation/lib/lvgl/examples/widgets/meter/index.rst](/homeStation/lib/lvgl/examples/widgets/meter/index.rst) | reStructuredText | -12 | -4 | -13 | -29 |
| [homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_1.c](/homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_1.c) | C | -44 | -10 | -13 | -67 |
| [homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_1.py](/homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_1.py) | Python | -36 | -11 | -12 | -59 |
| [homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_2.c](/homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_2.c) | C | -41 | -7 | -13 | -61 |
| [homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_2.py](/homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_2.py) | Python | -49 | -8 | -13 | -70 |
| [homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_3.c](/homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_3.c) | C | -36 | -8 | -11 | -55 |
| [homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_3.py](/homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_3.py) | Python | -56 | -13 | -15 | -84 |
| [homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_4.c](/homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_4.c) | C | -24 | -6 | -9 | -39 |
| [homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_4.py](/homeStation/lib/lvgl/examples/widgets/meter/lv_example_meter_4.py) | Python | -18 | -6 | -9 | -33 |
| [homeStation/lib/lvgl/examples/widgets/msgbox/index.rst](/homeStation/lib/lvgl/examples/widgets/msgbox/index.rst) | reStructuredText | -3 | -1 | -5 | -9 |
| [homeStation/lib/lvgl/examples/widgets/msgbox/lv_example_msgbox_1.c](/homeStation/lib/lvgl/examples/widgets/msgbox/lv_example_msgbox_1.c) | C | -15 | 0 | -5 | -20 |
| [homeStation/lib/lvgl/examples/widgets/msgbox/lv_example_msgbox_1.py](/homeStation/lib/lvgl/examples/widgets/msgbox/lv_example_msgbox_1.py) | Python | -7 | 0 | -4 | -11 |
| [homeStation/lib/lvgl/examples/widgets/obj/index.rst](/homeStation/lib/lvgl/examples/widgets/obj/index.rst) | reStructuredText | -6 | -2 | -6 | -14 |
| [homeStation/lib/lvgl/examples/widgets/obj/lv_example_obj_1.c](/homeStation/lib/lvgl/examples/widgets/obj/lv_example_obj_1.c) | C | -19 | 0 | -4 | -23 |
| [homeStation/lib/lvgl/examples/widgets/obj/lv_example_obj_1.py](/homeStation/lib/lvgl/examples/widgets/obj/lv_example_obj_1.py) | Python | -11 | 0 | -4 | -15 |
| [homeStation/lib/lvgl/examples/widgets/obj/lv_example_obj_2.c](/homeStation/lib/lvgl/examples/widgets/obj/lv_example_obj_2.c) | C | -24 | -3 | -9 | -36 |
| [homeStation/lib/lvgl/examples/widgets/obj/lv_example_obj_2.py](/homeStation/lib/lvgl/examples/widgets/obj/lv_example_obj_2.py) | Python | -14 | -3 | -9 | -26 |
| [homeStation/lib/lvgl/examples/widgets/roller/index.rst](/homeStation/lib/lvgl/examples/widgets/roller/index.rst) | reStructuredText | -9 | -3 | -8 | -20 |
| [homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_1.c](/homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_1.c) | C | -34 | -3 | -5 | -42 |
| [homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_1.py](/homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_1.py) | Python | -24 | -3 | -5 | -32 |
| [homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_2.c](/homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_2.c) | C | -46 | -7 | -8 | -61 |
| [homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_2.py](/homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_2.py) | Python | -44 | -7 | -10 | -61 |
| [homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_3.c](/homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_3.c) | C | -76 | -4 | -17 | -97 |
| [homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_3.py](/homeStation/lib/lvgl/examples/widgets/roller/lv_example_roller_3.py) | Python | -72 | -8 | -20 | -100 |
| [homeStation/lib/lvgl/examples/widgets/slider/index.rst](/homeStation/lib/lvgl/examples/widgets/slider/index.rst) | reStructuredText | -9 | -3 | -9 | -21 |
| [homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_1.c](/homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_1.c) | C | -22 | -5 | -7 | -34 |
| [homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_1.py](/homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_1.py) | Python | -10 | -5 | -6 | -21 |
| [homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_2.c](/homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_2.c) | C | -41 | -5 | -12 | -58 |
| [homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_2.py](/homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_2.py) | Python | -35 | -5 | -9 | -49 |
| [homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_3.c](/homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_3.c) | C | -41 | -6 | -10 | -57 |
| [homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_3.py](/homeStation/lib/lvgl/examples/widgets/slider/lv_example_slider_3.py) | Python | -26 | -9 | -9 | -44 |
| [homeStation/lib/lvgl/examples/widgets/span/index.rst](/homeStation/lib/lvgl/examples/widgets/span/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/span/lv_example_span_1.c](/homeStation/lib/lvgl/examples/widgets/span/lv_example_span_1.c) | C | -45 | -3 | -11 | -59 |
| [homeStation/lib/lvgl/examples/widgets/span/lv_example_span_1.py](/homeStation/lib/lvgl/examples/widgets/span/lv_example_span_1.py) | Python | -32 | -11 | -11 | -54 |
| [homeStation/lib/lvgl/examples/widgets/spinbox/index.rst](/homeStation/lib/lvgl/examples/widgets/spinbox/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/spinbox/lv_example_spinbox_1.c](/homeStation/lib/lvgl/examples/widgets/spinbox/lv_example_spinbox_1.c) | C | -38 | 0 | -11 | -49 |
| [homeStation/lib/lvgl/examples/widgets/spinbox/lv_example_spinbox_1.py](/homeStation/lib/lvgl/examples/widgets/spinbox/lv_example_spinbox_1.py) | Python | -25 | 0 | -6 | -31 |
| [homeStation/lib/lvgl/examples/widgets/spinner/index.rst](/homeStation/lib/lvgl/examples/widgets/spinner/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/spinner/lv_example_spinner_1.c](/homeStation/lib/lvgl/examples/widgets/spinner/lv_example_spinner_1.c) | C | -9 | -1 | -3 | -13 |
| [homeStation/lib/lvgl/examples/widgets/spinner/lv_example_spinner_1.py](/homeStation/lib/lvgl/examples/widgets/spinner/lv_example_spinner_1.py) | Python | -3 | -1 | -3 | -7 |
| [homeStation/lib/lvgl/examples/widgets/switch/index.rst](/homeStation/lib/lvgl/examples/widgets/switch/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/switch/lv_example_switch_1.c](/homeStation/lib/lvgl/examples/widgets/switch/lv_example_switch_1.c) | C | -28 | 0 | -9 | -37 |
| [homeStation/lib/lvgl/examples/widgets/switch/lv_example_switch_1.py](/homeStation/lib/lvgl/examples/widgets/switch/lv_example_switch_1.py) | Python | -21 | 0 | -8 | -29 |
| [homeStation/lib/lvgl/examples/widgets/table/index.rst](/homeStation/lib/lvgl/examples/widgets/table/index.rst) | reStructuredText | -6 | -2 | -7 | -15 |
| [homeStation/lib/lvgl/examples/widgets/table/lv_example_table_1.c](/homeStation/lib/lvgl/examples/widgets/table/lv_example_table_1.c) | C | -47 | -8 | -11 | -66 |
| [homeStation/lib/lvgl/examples/widgets/table/lv_example_table_1.py](/homeStation/lib/lvgl/examples/widgets/table/lv_example_table_1.py) | Python | -35 | -8 | -11 | -54 |
| [homeStation/lib/lvgl/examples/widgets/table/lv_example_table_2.c](/homeStation/lib/lvgl/examples/widgets/table/lv_example_table_2.c) | C | -72 | -8 | -24 | -104 |
| [homeStation/lib/lvgl/examples/widgets/table/lv_example_table_2.py](/homeStation/lib/lvgl/examples/widgets/table/lv_example_table_2.py) | Python | -64 | -10 | -22 | -96 |
| [homeStation/lib/lvgl/examples/widgets/tabview/index.rst](/homeStation/lib/lvgl/examples/widgets/tabview/index.rst) | reStructuredText | -6 | -2 | -7 | -15 |
| [homeStation/lib/lvgl/examples/widgets/tabview/lv_example_tabview_1.c](/homeStation/lib/lvgl/examples/widgets/tabview/lv_example_tabview_1.c) | C | -32 | -3 | -8 | -43 |
| [homeStation/lib/lvgl/examples/widgets/tabview/lv_example_tabview_1.py](/homeStation/lib/lvgl/examples/widgets/tabview/lv_example_tabview_1.py) | Python | -22 | -3 | -11 | -36 |
| [homeStation/lib/lvgl/examples/widgets/tabview/lv_example_tabview_2.c](/homeStation/lib/lvgl/examples/widgets/tabview/lv_example_tabview_2.c) | C | -31 | -3 | -13 | -47 |
| [homeStation/lib/lvgl/examples/widgets/tabview/lv_example_tabview_2.py](/homeStation/lib/lvgl/examples/widgets/tabview/lv_example_tabview_2.py) | Python | -24 | -3 | -13 | -40 |
| [homeStation/lib/lvgl/examples/widgets/textarea/index.rst](/homeStation/lib/lvgl/examples/widgets/textarea/index.rst) | reStructuredText | -9 | -3 | -9 | -21 |
| [homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_1.c](/homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_1.c) | C | -36 | 0 | -9 | -45 |
| [homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_1.py](/homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_1.py) | Python | -26 | 0 | -7 | -33 |
| [homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_2.c](/homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_2.c) | C | -41 | -6 | -13 | -60 |
| [homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_2.py](/homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_2.py) | Python | -32 | -6 | -12 | -50 |
| [homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_3.c](/homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_3.c) | C | -29 | -6 | -7 | -42 |
| [homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_3.py](/homeStation/lib/lvgl/examples/widgets/textarea/lv_example_textarea_3.py) | Python | -33 | -11 | -7 | -51 |
| [homeStation/lib/lvgl/examples/widgets/tileview/index.rst](/homeStation/lib/lvgl/examples/widgets/tileview/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/tileview/lv_example_tileview_1.c](/homeStation/lib/lvgl/examples/widgets/tileview/lv_example_tileview_1.c) | C | -30 | -8 | -12 | -50 |
| [homeStation/lib/lvgl/examples/widgets/tileview/lv_example_tileview_1.py](/homeStation/lib/lvgl/examples/widgets/tileview/lv_example_tileview_1.py) | Python | -24 | -8 | -8 | -40 |
| [homeStation/lib/lvgl/examples/widgets/win/index.rst](/homeStation/lib/lvgl/examples/widgets/win/index.rst) | reStructuredText | -3 | -1 | -4 | -8 |
| [homeStation/lib/lvgl/examples/widgets/win/lv_example_win_1.c](/homeStation/lib/lvgl/examples/widgets/win/lv_example_win_1.c) | C | -35 | 0 | -11 | -46 |
| [homeStation/lib/lvgl/examples/widgets/win/lv_example_win_1.py](/homeStation/lib/lvgl/examples/widgets/win/lv_example_win_1.py) | Python | -31 | 0 | -6 | -37 |
| [homeStation/lib/lvgl/idf_component.yml](/homeStation/lib/lvgl/idf_component.yml) | YAML | -5 | 0 | -1 | -6 |
| [homeStation/lib/lvgl/library.json](/homeStation/lib/lvgl/library.json) | JSON | -17 | 0 | -1 | -18 |
| [homeStation/lib/lvgl/library.properties](/homeStation/lib/lvgl/library.properties) | Java Properties | -10 | 0 | -1 | -11 |
| [homeStation/lib/lvgl/lv_conf_template.h](/homeStation/lib/lvgl/lv_conf_template.h) | C++ | -326 | -288 | -171 | -785 |
| [homeStation/lib/lvgl/lvgl.h](/homeStation/lib/lvgl/lvgl.h) | C++ | -65 | -49 | -25 | -139 |
| [homeStation/lib/lvgl/lvgl.mk](/homeStation/lib/lvgl/lvgl.mk) | Makefile | -9 | 0 | -1 | -10 |
| [homeStation/lib/lvgl/scripts/build_html_examples.sh](/homeStation/lib/lvgl/scripts/build_html_examples.sh) | Shell Script | -20 | -1 | -1 | -22 |
| [homeStation/lib/lvgl/scripts/built_in_font/built_in_font_gen.py](/homeStation/lib/lvgl/scripts/built_in_font/built_in_font_gen.py) | Python | -51 | -3 | -9 | -63 |
| [homeStation/lib/lvgl/scripts/built_in_font/generate_all.py](/homeStation/lib/lvgl/scripts/built_in_font/generate_all.py) | Python | -58 | -1 | -30 | -89 |
| [homeStation/lib/lvgl/scripts/changelog-template.hbs](/homeStation/lib/lvgl/scripts/changelog-template.hbs) | Handlebars | -93 | 0 | -14 | -107 |
| [homeStation/lib/lvgl/scripts/changelog_gen.sh](/homeStation/lib/lvgl/scripts/changelog_gen.sh) | Shell Script | -1 | -13 | -2 | -16 |
| [homeStation/lib/lvgl/scripts/code-format.cfg](/homeStation/lib/lvgl/scripts/code-format.cfg) | Properties | -42 | 0 | -1 | -43 |
| [homeStation/lib/lvgl/scripts/code-format.py](/homeStation/lib/lvgl/scripts/code-format.py) | Python | -9 | -1 | -6 | -16 |
| [homeStation/lib/lvgl/scripts/cppcheck_run.sh](/homeStation/lib/lvgl/scripts/cppcheck_run.sh) | Shell Script | -1 | 0 | -1 | -2 |
| [homeStation/lib/lvgl/scripts/filetohex.py](/homeStation/lib/lvgl/scripts/filetohex.py) | Python | -6 | -1 | -5 | -12 |
| [homeStation/lib/lvgl/scripts/find_version.sh](/homeStation/lib/lvgl/scripts/find_version.sh) | Shell Script | -6 | -2 | -1 | -9 |
| [homeStation/lib/lvgl/scripts/genexamplelist.sh](/homeStation/lib/lvgl/scripts/genexamplelist.sh) | Shell Script | -14 | -1 | -1 | -16 |
| [homeStation/lib/lvgl/scripts/infer_run.sh](/homeStation/lib/lvgl/scripts/infer_run.sh) | Shell Script | -1 | -7 | -2 | -10 |
| [homeStation/lib/lvgl/scripts/install-prerequisites.sh](/homeStation/lib/lvgl/scripts/install-prerequisites.sh) | Shell Script | -2 | -6 | -2 | -10 |
| [homeStation/lib/lvgl/scripts/jpg_to_sjpg.py](/homeStation/lib/lvgl/scripts/jpg_to_sjpg.py) | Python | -84 | -12 | -43 | -139 |
| [homeStation/lib/lvgl/scripts/lv_conf_internal_gen.py](/homeStation/lib/lvgl/scripts/lv_conf_internal_gen.py) | Python | -87 | -63 | -35 | -185 |
| [homeStation/lib/lvgl/scripts/release/com.py](/homeStation/lib/lvgl/scripts/release/com.py) | Python | -79 | -1 | -29 | -109 |
| [homeStation/lib/lvgl/scripts/release/patch.py](/homeStation/lib/lvgl/scripts/release/patch.py) | Python | -47 | -10 | -18 | -75 |
| [homeStation/lib/lvgl/scripts/release/release.py](/homeStation/lib/lvgl/scripts/release/release.py) | Python | 0 | -16 | -2 | -18 |
| [homeStation/lib/lvgl/scripts/style_api_gen.py](/homeStation/lib/lvgl/scripts/style_api_gen.py) | Python | -381 | -1 | -134 | -516 |
| [homeStation/lib/lvgl/src/core/lv_core.mk](/homeStation/lib/lvgl/src/core/lv_core.mk) | Makefile | -18 | 0 | -3 | -21 |
| [homeStation/lib/lvgl/src/core/lv_disp.c](/homeStation/lib/lvgl/src/core/lv_disp.c) | C | -338 | -122 | -80 | -540 |
| [homeStation/lib/lvgl/src/core/lv_disp.h](/homeStation/lib/lvgl/src/core/lv_disp.h) | C++ | -77 | -150 | -38 | -265 |
| [homeStation/lib/lvgl/src/core/lv_event.c](/homeStation/lib/lvgl/src/core/lv_event.c) | C | -396 | -47 | -85 | -528 |
| [homeStation/lib/lvgl/src/core/lv_event.h](/homeStation/lib/lvgl/src/core/lv_event.h) | C++ | -110 | -203 | -51 | -364 |
| [homeStation/lib/lvgl/src/core/lv_group.c](/homeStation/lib/lvgl/src/core/lv_group.c) | C | -342 | -63 | -94 | -499 |
| [homeStation/lib/lvgl/src/core/lv_group.h](/homeStation/lib/lvgl/src/core/lv_group.h) | C++ | -75 | -145 | -47 | -267 |
| [homeStation/lib/lvgl/src/core/lv_indev.c](/homeStation/lib/lvgl/src/core/lv_indev.c) | C | -830 | -178 | -173 | -1,181 |
| [homeStation/lib/lvgl/src/core/lv_indev.h](/homeStation/lib/lvgl/src/core/lv_indev.h) | C++ | -31 | -117 | -29 | -177 |
| [homeStation/lib/lvgl/src/core/lv_indev_scroll.c](/homeStation/lib/lvgl/src/core/lv_indev_scroll.c) | C | -499 | -92 | -100 | -691 |
| [homeStation/lib/lvgl/src/core/lv_indev_scroll.h](/homeStation/lib/lvgl/src/core/lv_indev_scroll.h) | C++ | -14 | -38 | -14 | -66 |
| [homeStation/lib/lvgl/src/core/lv_obj.c](/homeStation/lib/lvgl/src/core/lv_obj.c) | C | -743 | -83 | -151 | -977 |
| [homeStation/lib/lvgl/src/core/lv_obj.h](/homeStation/lib/lvgl/src/core/lv_obj.h) | C++ | -181 | -165 | -66 | -412 |
| [homeStation/lib/lvgl/src/core/lv_obj_class.c](/homeStation/lib/lvgl/src/core/lv_obj_class.c) | C | -116 | -45 | -42 | -203 |
| [homeStation/lib/lvgl/src/core/lv_obj_class.h](/homeStation/lib/lvgl/src/core/lv_obj_class.h) | C++ | -45 | -29 | -21 | -95 |
| [homeStation/lib/lvgl/src/core/lv_obj_draw.c](/homeStation/lib/lvgl/src/core/lv_obj_draw.c) | C | -309 | -31 | -59 | -399 |
| [homeStation/lib/lvgl/src/core/lv_obj_draw.h](/homeStation/lib/lvgl/src/core/lv_obj_draw.h) | C++ | -59 | -87 | -27 | -173 |
| [homeStation/lib/lvgl/src/core/lv_obj_pos.c](/homeStation/lib/lvgl/src/core/lv_obj_pos.c) | C | -881 | -86 | -222 | -1,189 |
| [homeStation/lib/lvgl/src/core/lv_obj_pos.h](/homeStation/lib/lvgl/src/core/lv_obj_pos.h) | C++ | -67 | -323 | -60 | -450 |
| [homeStation/lib/lvgl/src/core/lv_obj_scroll.c](/homeStation/lib/lvgl/src/core/lv_obj_scroll.c) | C | -609 | -65 | -127 | -801 |
| [homeStation/lib/lvgl/src/core/lv_obj_scroll.h](/homeStation/lib/lvgl/src/core/lv_obj_scroll.h) | C++ | -55 | -207 | -46 | -308 |
| [homeStation/lib/lvgl/src/core/lv_obj_style.c](/homeStation/lib/lvgl/src/core/lv_obj_style.c) | C | -669 | -95 | -137 | -901 |
| [homeStation/lib/lvgl/src/core/lv_obj_style.h](/homeStation/lib/lvgl/src/core/lv_obj_style.h) | C++ | -97 | -123 | -44 | -264 |
| [homeStation/lib/lvgl/src/core/lv_obj_style_gen.c](/homeStation/lib/lvgl/src/core/lv_obj_style_gen.c) | C | -596 | 0 | -86 | -682 |
| [homeStation/lib/lvgl/src/core/lv_obj_style_gen.h](/homeStation/lib/lvgl/src/core/lv_obj_style_gen.h) | C++ | -560 | 0 | -96 | -656 |
| [homeStation/lib/lvgl/src/core/lv_obj_tree.c](/homeStation/lib/lvgl/src/core/lv_obj_tree.c) | C | -315 | -43 | -91 | -449 |
| [homeStation/lib/lvgl/src/core/lv_obj_tree.h](/homeStation/lib/lvgl/src/core/lv_obj_tree.h) | C++ | -34 | -109 | -30 | -173 |
| [homeStation/lib/lvgl/src/core/lv_refr.c](/homeStation/lib/lvgl/src/core/lv_refr.c) | C | -974 | -192 | -186 | -1,352 |
| [homeStation/lib/lvgl/src/core/lv_refr.h](/homeStation/lib/lvgl/src/core/lv_refr.h) | C++ | -23 | -70 | -23 | -116 |
| [homeStation/lib/lvgl/src/core/lv_theme.c](/homeStation/lib/lvgl/src/core/lv_theme.c) | C | -52 | -46 | -21 | -119 |
| [homeStation/lib/lvgl/src/core/lv_theme.h](/homeStation/lib/lvgl/src/core/lv_theme.h) | C++ | -34 | -66 | -21 | -121 |
| [homeStation/lib/lvgl/src/draw/arm2d/lv_draw_arm2d.mk](/homeStation/lib/lvgl/src/draw/arm2d/lv_draw_arm2d.mk) | Makefile | -4 | 0 | -3 | -7 |
| [homeStation/lib/lvgl/src/draw/arm2d/lv_gpu_arm2d.c](/homeStation/lib/lvgl/src/draw/arm2d/lv_gpu_arm2d.c) | C | -1,300 | -100 | -175 | -1,575 |
| [homeStation/lib/lvgl/src/draw/arm2d/lv_gpu_arm2d.h](/homeStation/lib/lvgl/src/draw/arm2d/lv_gpu_arm2d.h) | C++ | -18 | -19 | -15 | -52 |
| [homeStation/lib/lvgl/src/draw/lv_draw.c](/homeStation/lib/lvgl/src/draw/lv_draw.c) | C | -9 | -32 | -13 | -54 |
| [homeStation/lib/lvgl/src/draw/lv_draw.h](/homeStation/lib/lvgl/src/draw/lv_draw.h) | C++ | -79 | -97 | -44 | -220 |
| [homeStation/lib/lvgl/src/draw/lv_draw.mk](/homeStation/lib/lvgl/src/draw/lv_draw.mk) | Makefile | -22 | 0 | -4 | -26 |
| [homeStation/lib/lvgl/src/draw/lv_draw_arc.c](/homeStation/lib/lvgl/src/draw/lv_draw_arc.c) | C | -97 | -32 | -24 | -153 |
| [homeStation/lib/lvgl/src/draw/lv_draw_arc.h](/homeStation/lib/lvgl/src/draw/lv_draw_arc.h) | C++ | -29 | -41 | -14 | -84 |
| [homeStation/lib/lvgl/src/draw/lv_draw_img.c](/homeStation/lib/lvgl/src/draw/lv_draw_img.c) | C | -255 | -66 | -55 | -376 |
| [homeStation/lib/lvgl/src/draw/lv_draw_img.h](/homeStation/lib/lvgl/src/draw/lv_draw_img.h) | C++ | -33 | -49 | -23 | -105 |
| [homeStation/lib/lvgl/src/draw/lv_draw_label.c](/homeStation/lib/lvgl/src/draw/lv_draw_label.c) | C | -288 | -66 | -64 | -418 |
| [homeStation/lib/lvgl/src/draw/lv_draw_label.h](/homeStation/lib/lvgl/src/draw/lv_draw_label.h) | C++ | -43 | -40 | -18 | -101 |
| [homeStation/lib/lvgl/src/draw/lv_draw_layer.c](/homeStation/lib/lvgl/src/draw/lv_draw_layer.c) | C | -47 | -28 | -19 | -94 |
| [homeStation/lib/lvgl/src/draw/lv_draw_layer.h](/homeStation/lib/lvgl/src/draw/lv_draw_layer.h) | C++ | -24 | -45 | -15 | -84 |
| [homeStation/lib/lvgl/src/draw/lv_draw_line.c](/homeStation/lib/lvgl/src/draw/lv_draw_line.c) | C | -17 | -28 | -12 | -57 |
| [homeStation/lib/lvgl/src/draw/lv_draw_line.h](/homeStation/lib/lvgl/src/draw/lv_draw_line.h) | C++ | -28 | -26 | -14 | -68 |
| [homeStation/lib/lvgl/src/draw/lv_draw_mask.c](/homeStation/lib/lvgl/src/draw/lv_draw_mask.c) | C | -1,144 | -199 | -189 | -1,532 |
| [homeStation/lib/lvgl/src/draw/lv_draw_mask.h](/homeStation/lib/lvgl/src/draw/lv_draw_mask.h) | C++ | -160 | -158 | -78 | -396 |
| [homeStation/lib/lvgl/src/draw/lv_draw_rect.c](/homeStation/lib/lvgl/src/draw/lv_draw_rect.c) | C | -27 | -34 | -13 | -74 |
| [homeStation/lib/lvgl/src/draw/lv_draw_rect.h](/homeStation/lib/lvgl/src/draw/lv_draw_rect.h) | C++ | -47 | -30 | -20 | -97 |
| [homeStation/lib/lvgl/src/draw/lv_draw_transform.c](/homeStation/lib/lvgl/src/draw/lv_draw_transform.c) | C | -15 | -28 | -12 | -55 |
| [homeStation/lib/lvgl/src/draw/lv_draw_transform.h](/homeStation/lib/lvgl/src/draw/lv_draw_transform.h) | C++ | -15 | -19 | -11 | -45 |
| [homeStation/lib/lvgl/src/draw/lv_draw_triangle.c](/homeStation/lib/lvgl/src/draw/lv_draw_triangle.c) | C | -13 | -28 | -12 | -53 |
| [homeStation/lib/lvgl/src/draw/lv_draw_triangle.h](/homeStation/lib/lvgl/src/draw/lv_draw_triangle.h) | C++ | -13 | -19 | -11 | -43 |
| [homeStation/lib/lvgl/src/draw/lv_img_buf.c](/homeStation/lib/lvgl/src/draw/lv_img_buf.c) | C | -278 | -68 | -47 | -393 |
| [homeStation/lib/lvgl/src/draw/lv_img_buf.h](/homeStation/lib/lvgl/src/draw/lv_img_buf.h) | C++ | -104 | -107 | -39 | -250 |
| [homeStation/lib/lvgl/src/draw/lv_img_cache.c](/homeStation/lib/lvgl/src/draw/lv_img_cache.c) | C | -122 | -64 | -30 | -216 |
| [homeStation/lib/lvgl/src/draw/lv_img_cache.h](/homeStation/lib/lvgl/src/draw/lv_img_cache.h) | C++ | -17 | -47 | -15 | -79 |
| [homeStation/lib/lvgl/src/draw/lv_img_decoder.c](/homeStation/lib/lvgl/src/draw/lv_img_decoder.c) | C | -502 | -141 | -88 | -731 |
| [homeStation/lib/lvgl/src/draw/lv_img_decoder.h](/homeStation/lib/lvgl/src/draw/lv_img_decoder.h) | C++ | -68 | -160 | -47 | -275 |
| [homeStation/lib/lvgl/src/draw/nxp/lv_draw_nxp.mk](/homeStation/lib/lvgl/src/draw/nxp/lv_draw_nxp.mk) | Makefile | -5 | 0 | -3 | -8 |
| [homeStation/lib/lvgl/src/draw/nxp/pxp/lv_draw_nxp_pxp.mk](/homeStation/lib/lvgl/src/draw/nxp/pxp/lv_draw_nxp_pxp.mk) | Makefile | -7 | 0 | -3 | -10 |
| [homeStation/lib/lvgl/src/draw/nxp/pxp/lv_draw_pxp.c](/homeStation/lib/lvgl/src/draw/nxp/pxp/lv_draw_pxp.c) | C | -149 | -76 | -51 | -276 |
| [homeStation/lib/lvgl/src/draw/nxp/pxp/lv_draw_pxp.h](/homeStation/lib/lvgl/src/draw/nxp/pxp/lv_draw_pxp.h) | C++ | -16 | -42 | -15 | -73 |
| [homeStation/lib/lvgl/src/draw/nxp/pxp/lv_draw_pxp_blend.c](/homeStation/lib/lvgl/src/draw/nxp/pxp/lv_draw_pxp_blend.c) | C | -370 | -129 | -75 | -574 |
| [homeStation/lib/lvgl/src/draw/nxp/pxp/lv_draw_pxp_blend.h](/homeStation/lib/lvgl/src/draw/nxp/pxp/lv_draw_pxp_blend.h) | C++ | -24 | -89 | -18 | -131 |
| [homeStation/lib/lvgl/src/draw/nxp/pxp/lv_gpu_nxp_pxp.c](/homeStation/lib/lvgl/src/draw/nxp/pxp/lv_gpu_nxp_pxp.c) | C | -54 | -55 | -30 | -139 |
| [homeStation/lib/lvgl/src/draw/nxp/pxp/lv_gpu_nxp_pxp.h](/homeStation/lib/lvgl/src/draw/nxp/pxp/lv_gpu_nxp_pxp.h) | C++ | -63 | -73 | -31 | -167 |
| [homeStation/lib/lvgl/src/draw/nxp/pxp/lv_gpu_nxp_pxp_osa.c](/homeStation/lib/lvgl/src/draw/nxp/pxp/lv_gpu_nxp_pxp_osa.c) | C | -79 | -70 | -32 | -181 |
| [homeStation/lib/lvgl/src/draw/nxp/pxp/lv_gpu_nxp_pxp_osa.h](/homeStation/lib/lvgl/src/draw/nxp/pxp/lv_gpu_nxp_pxp_osa.h) | C++ | -15 | -48 | -16 | -79 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_nxp_vglite.mk](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_nxp_vglite.mk) | Makefile | -10 | 0 | -3 | -13 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite.c](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite.c) | C | -368 | -80 | -110 | -558 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite.h](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite.h) | C++ | -16 | -42 | -15 | -73 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_arc.c](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_arc.c) | C | -446 | -160 | -74 | -680 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_arc.h](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_arc.h) | C++ | -15 | -55 | -14 | -84 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_blend.c](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_blend.c) | C | -355 | -161 | -120 | -636 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_blend.h](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_blend.h) | C++ | -36 | -112 | -21 | -169 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_line.c](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_line.c) | C | -58 | -54 | -31 | -143 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_line.h](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_line.h) | C++ | -17 | -53 | -14 | -84 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_rect.c](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_rect.c) | C | -266 | -108 | -86 | -460 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_rect.h](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_draw_vglite_rect.h) | C++ | -18 | -65 | -15 | -98 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_vglite_buf.c](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_vglite_buf.c) | C | -63 | -51 | -28 | -142 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_vglite_buf.h](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_vglite_buf.h) | C++ | -22 | -84 | -19 | -125 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_vglite_utils.c](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_vglite_utils.c) | C | -72 | -55 | -23 | -150 |
| [homeStation/lib/lvgl/src/draw/nxp/vglite/lv_vglite_utils.h](/homeStation/lib/lvgl/src/draw/nxp/vglite/lv_vglite_utils.h) | C++ | -83 | -86 | -32 | -201 |
| [homeStation/lib/lvgl/src/draw/renesas/lv_draw_renesas.mk](/homeStation/lib/lvgl/src/draw/renesas/lv_draw_renesas.mk) | Makefile | -5 | 0 | -3 | -8 |
| [homeStation/lib/lvgl/src/draw/renesas/lv_gpu_d2_draw_label.c](/homeStation/lib/lvgl/src/draw/renesas/lv_gpu_d2_draw_label.c) | C | -218 | -35 | -40 | -293 |
| [homeStation/lib/lvgl/src/draw/renesas/lv_gpu_d2_ra6m3.c](/homeStation/lib/lvgl/src/draw/renesas/lv_gpu_d2_ra6m3.c) | C | -584 | -37 | -122 | -743 |
| [homeStation/lib/lvgl/src/draw/renesas/lv_gpu_d2_ra6m3.h](/homeStation/lib/lvgl/src/draw/renesas/lv_gpu_d2_ra6m3.h) | C++ | -25 | -16 | -16 | -57 |
| [homeStation/lib/lvgl/src/draw/sdl/README.md](/homeStation/lib/lvgl/src/draw/sdl/README.md) | Markdown | -18 | 0 | -10 | -28 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl.c) | C | -53 | -28 | -23 | -104 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl.h](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl.h) | C++ | -33 | -38 | -26 | -97 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl.mk](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl.mk) | Makefile | -17 | 0 | -3 | -20 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_arc.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_arc.c) | C | -177 | -30 | -39 | -246 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_bg.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_bg.c) | C | -53 | -30 | -24 | -107 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_composite.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_composite.c) | C | -213 | -36 | -31 | -280 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_composite.h](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_composite.h) | C++ | -27 | -41 | -17 | -85 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_img.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_img.c) | C | -400 | -41 | -59 | -500 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_img.h](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_img.h) | C++ | -23 | -44 | -20 | -87 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_label.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_label.c) | C | -121 | -35 | -34 | -190 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_layer.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_layer.c) | C | -86 | -31 | -31 | -148 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_layer.h](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_layer.h) | C++ | -25 | -19 | -13 | -57 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_line.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_line.c) | C | -102 | -29 | -27 | -158 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_mask.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_mask.c) | C | -43 | -28 | -14 | -85 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_mask.h](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_mask.h) | C++ | -17 | -19 | -16 | -52 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_polygon.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_polygon.c) | C | -87 | -28 | -25 | -140 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_priv.h](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_priv.h) | C++ | -23 | -31 | -20 | -74 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_rect.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_rect.c) | C | -816 | -59 | -139 | -1,014 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_rect.h](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_rect.h) | C++ | -25 | -55 | -25 | -105 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_stack_blur.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_stack_blur.c) | C | -167 | -33 | -50 | -250 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_stack_blur.h](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_stack_blur.h) | C++ | -14 | -19 | -14 | -47 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_texture_cache.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_texture_cache.c) | C | -125 | -26 | -26 | -177 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_texture_cache.h](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_texture_cache.h) | C++ | -57 | -28 | -25 | -110 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_utils.c](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_utils.c) | C | -133 | -29 | -22 | -184 |
| [homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_utils.h](/homeStation/lib/lvgl/src/draw/sdl/lv_draw_sdl_utils.h) | C++ | -26 | -19 | -21 | -66 |
| [homeStation/lib/lvgl/src/draw/stm32_dma2d/lv_draw_stm32_dma2d.mk](/homeStation/lib/lvgl/src/draw/stm32_dma2d/lv_draw_stm32_dma2d.mk) | Makefile | -4 | 0 | -3 | -7 |
| [homeStation/lib/lvgl/src/draw/stm32_dma2d/lv_gpu_stm32_dma2d.c](/homeStation/lib/lvgl/src/draw/stm32_dma2d/lv_gpu_stm32_dma2d.c) | C | -549 | -144 | -103 | -796 |
| [homeStation/lib/lvgl/src/draw/stm32_dma2d/lv_gpu_stm32_dma2d.h](/homeStation/lib/lvgl/src/draw/stm32_dma2d/lv_gpu_stm32_dma2d.h) | C++ | -35 | -20 | -13 | -68 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw.c) | C | -55 | -33 | -21 | -109 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw.h](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw.h) | C++ | -54 | -23 | -30 | -107 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw.mk](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw.mk) | Makefile | -15 | 0 | -3 | -18 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_arc.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_arc.c) | C | -416 | -44 | -78 | -538 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_blend.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_blend.c) | C | -876 | -63 | -123 | -1,062 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_blend.h](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_blend.h) | C++ | -27 | -30 | -14 | -71 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_dither.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_dither.c) | C | -126 | -65 | -23 | -214 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_dither.h](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_dither.h) | C++ | -38 | -17 | -17 | -72 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_gradient.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_gradient.c) | C | -271 | -36 | -40 | -347 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_gradient.h](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_gradient.h) | C++ | -42 | -40 | -16 | -98 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_img.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_img.c) | C | -219 | -40 | -41 | -300 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_layer.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_layer.c) | C | -92 | -33 | -26 | -151 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_letter.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_letter.c) | C | -429 | -62 | -83 | -574 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_line.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_line.c) | C | -319 | -50 | -75 | -444 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_polygon.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_polygon.c) | C | -125 | -47 | -36 | -208 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_rect.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_rect.c) | C | -1,088 | -124 | -225 | -1,437 |
| [homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_transform.c](/homeStation/lib/lvgl/src/draw/sw/lv_draw_sw_transform.c) | C | -396 | -41 | -60 | -497 |
| [homeStation/lib/lvgl/src/draw/swm341_dma2d/lv_draw_swm341_dma2d.mk](/homeStation/lib/lvgl/src/draw/swm341_dma2d/lv_draw_swm341_dma2d.mk) | Makefile | -4 | 0 | -3 | -7 |
| [homeStation/lib/lvgl/src/draw/swm341_dma2d/lv_gpu_swm341_dma2d.c](/homeStation/lib/lvgl/src/draw/swm341_dma2d/lv_gpu_swm341_dma2d.c) | C | -152 | -41 | -49 | -242 |
| [homeStation/lib/lvgl/src/draw/swm341_dma2d/lv_gpu_swm341_dma2d.h](/homeStation/lib/lvgl/src/draw/swm341_dma2d/lv_gpu_swm341_dma2d.h) | C++ | -24 | -22 | -19 | -65 |
| [homeStation/lib/lvgl/src/extra/README.md](/homeStation/lib/lvgl/src/extra/README.md) | Markdown | -26 | 0 | -5 | -31 |
| [homeStation/lib/lvgl/src/extra/layouts/flex/lv_flex.c](/homeStation/lib/lvgl/src/extra/layouts/flex/lv_flex.c) | C | -456 | -58 | -90 | -604 |
| [homeStation/lib/lvgl/src/extra/layouts/flex/lv_flex.h](/homeStation/lib/lvgl/src/extra/layouts/flex/lv_flex.h) | C++ | -82 | -44 | -27 | -153 |
| [homeStation/lib/lvgl/src/extra/layouts/grid/lv_grid.c](/homeStation/lib/lvgl/src/extra/layouts/grid/lv_grid.c) | C | -586 | -82 | -115 | -783 |
| [homeStation/lib/lvgl/src/extra/layouts/grid/lv_grid.h](/homeStation/lib/lvgl/src/extra/layouts/grid/lv_grid.h) | C++ | -117 | -44 | -34 | -195 |
| [homeStation/lib/lvgl/src/extra/layouts/lv_layouts.h](/homeStation/lib/lvgl/src/extra/layouts/lv_layouts.h) | C++ | -16 | -19 | -10 | -45 |
| [homeStation/lib/lvgl/src/extra/libs/bmp/lv_bmp.c](/homeStation/lib/lvgl/src/extra/libs/bmp/lv_bmp.c) | C | -165 | -50 | -44 | -259 |
| [homeStation/lib/lvgl/src/extra/libs/bmp/lv_bmp.h](/homeStation/lib/lvgl/src/extra/libs/bmp/lv_bmp.h) | C++ | -13 | -19 | -11 | -43 |
| [homeStation/lib/lvgl/src/extra/libs/ffmpeg/lv_ffmpeg.c](/homeStation/lib/lvgl/src/extra/libs/ffmpeg/lv_ffmpeg.c) | C | -636 | -69 | -171 | -876 |
| [homeStation/lib/lvgl/src/extra/libs/ffmpeg/lv_ffmpeg.h](/homeStation/lib/lvgl/src/extra/libs/ffmpeg/lv_ffmpeg.h) | C++ | -34 | -51 | -20 | -105 |
| [homeStation/lib/lvgl/src/extra/libs/freetype/lv_freetype.c](/homeStation/lib/lvgl/src/extra/libs/freetype/lv_freetype.c) | C | -552 | -44 | -92 | -688 |
| [homeStation/lib/lvgl/src/extra/libs/freetype/lv_freetype.h](/homeStation/lib/lvgl/src/extra/libs/freetype/lv_freetype.h) | C++ | -29 | -40 | -15 | -84 |
| [homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fs_fatfs.c](/homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fs_fatfs.c) | C | -141 | -109 | -41 | -291 |
| [homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fs_littlefs.c](/homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fs_littlefs.c) | C | -153 | -116 | -64 | -333 |
| [homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fs_posix.c](/homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fs_posix.c) | C | -169 | -108 | -43 | -320 |
| [homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fs_stdio.c](/homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fs_stdio.c) | C | -181 | -108 | -41 | -330 |
| [homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fs_win32.c](/homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fs_win32.c) | C | -297 | -118 | -52 | -467 |
| [homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fsdrv.h](/homeStation/lib/lvgl/src/extra/libs/fsdrv/lv_fsdrv.h) | C++ | -26 | -19 | -16 | -61 |
| [homeStation/lib/lvgl/src/extra/libs/gif/gifdec.c](/homeStation/lib/lvgl/src/extra/libs/gif/gifdec.c) | C | -572 | -50 | -56 | -678 |
| [homeStation/lib/lvgl/src/extra/libs/gif/gifdec.h](/homeStation/lib/lvgl/src/extra/libs/gif/gifdec.h) | C++ | -47 | 0 | -14 | -61 |
| [homeStation/lib/lvgl/src/extra/libs/gif/lv_gif.c](/homeStation/lib/lvgl/src/extra/libs/gif/lv_gif.c) | C | -93 | -30 | -32 | -155 |
| [homeStation/lib/lvgl/src/extra/libs/gif/lv_gif.h](/homeStation/lib/lvgl/src/extra/libs/gif/lv_gif.h) | C++ | -24 | -19 | -16 | -59 |
| [homeStation/lib/lvgl/src/extra/libs/lv_libs.h](/homeStation/lib/lvgl/src/extra/libs/lv_libs.h) | C++ | -19 | -19 | -10 | -48 |
| [homeStation/lib/lvgl/src/extra/libs/png/lodepng.c](/homeStation/lib/lvgl/src/extra/libs/png/lodepng.c) | C | -4,789 | -859 | -822 | -6,470 |
| [homeStation/lib/lvgl/src/extra/libs/png/lodepng.h](/homeStation/lib/lvgl/src/extra/libs/png/lodepng.h) | C++ | -437 | -1,414 | -131 | -1,982 |
| [homeStation/lib/lvgl/src/extra/libs/png/lv_png.c](/homeStation/lib/lvgl/src/extra/libs/png/lv_png.c) | C | -168 | -67 | -44 | -279 |
| [homeStation/lib/lvgl/src/extra/libs/png/lv_png.h](/homeStation/lib/lvgl/src/extra/libs/png/lv_png.h) | C++ | -13 | -22 | -12 | -47 |
| [homeStation/lib/lvgl/src/extra/libs/qrcode/lv_qrcode.c](/homeStation/lib/lvgl/src/extra/libs/qrcode/lv_qrcode.c) | C | -127 | -50 | -39 | -216 |
| [homeStation/lib/lvgl/src/extra/libs/qrcode/lv_qrcode.h](/homeStation/lib/lvgl/src/extra/libs/qrcode/lv_qrcode.h) | C++ | -16 | -39 | -15 | -70 |
| [homeStation/lib/lvgl/src/extra/libs/qrcode/qrcodegen.c](/homeStation/lib/lvgl/src/extra/libs/qrcode/qrcodegen.c) | C | -719 | -172 | -145 | -1,036 |
| [homeStation/lib/lvgl/src/extra/libs/qrcode/qrcodegen.h](/homeStation/lib/lvgl/src/extra/libs/qrcode/qrcodegen.h) | C++ | -63 | -200 | -57 | -320 |
| [homeStation/lib/lvgl/src/extra/libs/rlottie/lv_rlottie.c](/homeStation/lib/lvgl/src/extra/libs/rlottie/lv_rlottie.c) | C | -190 | -48 | -47 | -285 |
| [homeStation/lib/lvgl/src/extra/libs/rlottie/lv_rlottie.h](/homeStation/lib/lvgl/src/extra/libs/rlottie/lv_rlottie.h) | C++ | -40 | -20 | -16 | -76 |
| [homeStation/lib/lvgl/src/extra/libs/sjpg/lv_sjpg.c](/homeStation/lib/lvgl/src/extra/libs/sjpg/lv_sjpg.c) | C | -664 | -102 | -152 | -918 |
| [homeStation/lib/lvgl/src/extra/libs/sjpg/lv_sjpg.h](/homeStation/lib/lvgl/src/extra/libs/sjpg/lv_sjpg.h) | C++ | -12 | -19 | -13 | -44 |
| [homeStation/lib/lvgl/src/extra/libs/sjpg/tjpgd.c](/homeStation/lib/lvgl/src/extra/libs/sjpg/tjpgd.c) | C | -883 | -95 | -178 | -1,156 |
| [homeStation/lib/lvgl/src/extra/libs/sjpg/tjpgd.h](/homeStation/lib/lvgl/src/extra/libs/sjpg/tjpgd.h) | C++ | -72 | -7 | -15 | -94 |
| [homeStation/lib/lvgl/src/extra/libs/sjpg/tjpgdcnf.h](/homeStation/lib/lvgl/src/extra/libs/sjpg/tjpgdcnf.h) | C++ | -5 | -22 | -7 | -34 |
| [homeStation/lib/lvgl/src/extra/libs/tiny_ttf/lv_tiny_ttf.c](/homeStation/lib/lvgl/src/extra/libs/tiny_ttf/lv_tiny_ttf.c) | C | -261 | -7 | -17 | -285 |
| [homeStation/lib/lvgl/src/extra/libs/tiny_ttf/lv_tiny_ttf.h](/homeStation/lib/lvgl/src/extra/libs/tiny_ttf/lv_tiny_ttf.h) | C++ | -20 | -25 | -18 | -63 |
| [homeStation/lib/lvgl/src/extra/libs/tiny_ttf/stb_rect_pack.h](/homeStation/lib/lvgl/src/extra/libs/tiny_ttf/stb_rect_pack.h) | C++ | -331 | -229 | -78 | -638 |
| [homeStation/lib/lvgl/src/extra/libs/tiny_ttf/stb_truetype_htcw.h](/homeStation/lib/lvgl/src/extra/libs/tiny_ttf/stb_truetype_htcw.h) | C++ | -3,988 | -1,003 | -582 | -5,573 |
| [homeStation/lib/lvgl/src/extra/lv_extra.c](/homeStation/lib/lvgl/src/extra/lv_extra.c) | C | -47 | -29 | -22 | -98 |
| [homeStation/lib/lvgl/src/extra/lv_extra.h](/homeStation/lib/lvgl/src/extra/lv_extra.h) | C++ | -15 | -22 | -12 | -49 |
| [homeStation/lib/lvgl/src/extra/lv_extra.mk](/homeStation/lib/lvgl/src/extra/lv_extra.mk) | Makefile | -1 | 0 | -1 | -2 |
| [homeStation/lib/lvgl/src/extra/others/fragment/README.md](/homeStation/lib/lvgl/src/extra/others/fragment/README.md) | Markdown | 0 | 0 | -1 | -1 |
| [homeStation/lib/lvgl/src/extra/others/fragment/lv_fragment.c](/homeStation/lib/lvgl/src/extra/others/fragment/lv_fragment.c) | C | -110 | -17 | -18 | -145 |
| [homeStation/lib/lvgl/src/extra/others/fragment/lv_fragment.h](/homeStation/lib/lvgl/src/extra/others/fragment/lv_fragment.h) | C++ | -67 | -221 | -52 | -340 |
| [homeStation/lib/lvgl/src/extra/others/fragment/lv_fragment_manager.c](/homeStation/lib/lvgl/src/extra/others/fragment/lv_fragment_manager.c) | C | -204 | -40 | -38 | -282 |
| [homeStation/lib/lvgl/src/extra/others/gridnav/lv_gridnav.c](/homeStation/lib/lvgl/src/extra/others/gridnav/lv_gridnav.c) | C | -309 | -32 | -36 | -377 |
| [homeStation/lib/lvgl/src/extra/others/gridnav/lv_gridnav.h](/homeStation/lib/lvgl/src/extra/others/gridnav/lv_gridnav.h) | C++ | -21 | -77 | -26 | -124 |
| [homeStation/lib/lvgl/src/extra/others/ime/lv_ime_pinyin.c](/homeStation/lib/lvgl/src/extra/others/ime/lv_ime_pinyin.c) | C | -959 | -82 | -161 | -1,202 |
| [homeStation/lib/lvgl/src/extra/others/ime/lv_ime_pinyin.h](/homeStation/lib/lvgl/src/extra/others/ime/lv_ime_pinyin.h) | C++ | -52 | -64 | -30 | -146 |
| [homeStation/lib/lvgl/src/extra/others/imgfont/lv_imgfont.c](/homeStation/lib/lvgl/src/extra/others/imgfont/lv_imgfont.c) | C | -71 | -31 | -25 | -127 |
| [homeStation/lib/lvgl/src/extra/others/imgfont/lv_imgfont.h](/homeStation/lib/lvgl/src/extra/others/imgfont/lv_imgfont.h) | C++ | -16 | -30 | -15 | -61 |
| [homeStation/lib/lvgl/src/extra/others/lv_others.h](/homeStation/lib/lvgl/src/extra/others/lv_others.h) | C++ | -16 | -19 | -10 | -45 |
| [homeStation/lib/lvgl/src/extra/others/monkey/lv_monkey.c](/homeStation/lib/lvgl/src/extra/others/monkey/lv_monkey.c) | C | -131 | -22 | -35 | -188 |
| [homeStation/lib/lvgl/src/extra/others/monkey/lv_monkey.h](/homeStation/lib/lvgl/src/extra/others/monkey/lv_monkey.h) | C++ | -35 | -60 | -24 | -119 |
| [homeStation/lib/lvgl/src/extra/others/msg/lv_msg.c](/homeStation/lib/lvgl/src/extra/others/msg/lv_msg.c) | C | -124 | -33 | -33 | -190 |
| [homeStation/lib/lvgl/src/extra/others/msg/lv_msg.h](/homeStation/lib/lvgl/src/extra/others/msg/lv_msg.h) | C++ | -41 | -77 | -28 | -146 |
| [homeStation/lib/lvgl/src/extra/others/snapshot/lv_snapshot.c](/homeStation/lib/lvgl/src/extra/others/snapshot/lv_snapshot.c) | C | -117 | -62 | -35 | -214 |
| [homeStation/lib/lvgl/src/extra/others/snapshot/lv_snapshot.h](/homeStation/lib/lvgl/src/extra/others/snapshot/lv_snapshot.h) | C++ | -19 | -50 | -16 | -85 |
| [homeStation/lib/lvgl/src/extra/themes/basic/lv_theme_basic.c](/homeStation/lib/lvgl/src/extra/themes/basic/lv_theme_basic.c) | C | -332 | -38 | -59 | -429 |
| [homeStation/lib/lvgl/src/extra/themes/basic/lv_theme_basic.h](/homeStation/lib/lvgl/src/extra/themes/basic/lv_theme_basic.h) | C++ | -14 | -28 | -14 | -56 |
| [homeStation/lib/lvgl/src/extra/themes/default/lv_theme_default.c](/homeStation/lib/lvgl/src/extra/themes/default/lv_theme_default.c) | C | -975 | -43 | -164 | -1,182 |
| [homeStation/lib/lvgl/src/extra/themes/default/lv_theme_default.h](/homeStation/lib/lvgl/src/extra/themes/default/lv_theme_default.h) | C++ | -16 | -34 | -15 | -65 |
| [homeStation/lib/lvgl/src/extra/themes/lv_themes.h](/homeStation/lib/lvgl/src/extra/themes/lv_themes.h) | C++ | -12 | -19 | -10 | -41 |
| [homeStation/lib/lvgl/src/extra/themes/mono/lv_theme_mono.c](/homeStation/lib/lvgl/src/extra/themes/mono/lv_theme_mono.c) | C | -403 | -38 | -64 | -505 |
| [homeStation/lib/lvgl/src/extra/themes/mono/lv_theme_mono.h](/homeStation/lib/lvgl/src/extra/themes/mono/lv_theme_mono.h) | C++ | -14 | -30 | -14 | -58 |
| [homeStation/lib/lvgl/src/extra/widgets/animimg/lv_animimg.c](/homeStation/lib/lvgl/src/extra/widgets/animimg/lv_animimg.c) | C | -77 | -36 | -26 | -139 |
| [homeStation/lib/lvgl/src/extra/widgets/animimg/lv_animimg.h](/homeStation/lib/lvgl/src/extra/widgets/animimg/lv_animimg.h) | C++ | -31 | -50 | -23 | -104 |
| [homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar.c](/homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar.c) | C | -264 | -62 | -77 | -403 |
| [homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar.h](/homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar.h) | C++ | -40 | -95 | -30 | -165 |
| [homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar_header_arrow.c](/homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar_header_arrow.c) | C | -88 | -30 | -32 | -150 |
| [homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar_header_arrow.h](/homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar_header_arrow.h) | C++ | -14 | -24 | -12 | -50 |
| [homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar_header_dropdown.c](/homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar_header_dropdown.c) | C | -82 | -29 | -32 | -143 |
| [homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar_header_dropdown.h](/homeStation/lib/lvgl/src/extra/widgets/calendar/lv_calendar_header_dropdown.h) | C++ | -14 | -24 | -12 | -50 |
| [homeStation/lib/lvgl/src/extra/widgets/chart/lv_chart.c](/homeStation/lib/lvgl/src/extra/widgets/chart/lv_chart.c) | C | -1,367 | -106 | -338 | -1,811 |
| [homeStation/lib/lvgl/src/extra/widgets/chart/lv_chart.h](/homeStation/lib/lvgl/src/extra/widgets/chart/lv_chart.h) | C++ | -132 | -266 | -63 | -461 |
| [homeStation/lib/lvgl/src/extra/widgets/colorwheel/lv_colorwheel.c](/homeStation/lib/lvgl/src/extra/widgets/colorwheel/lv_colorwheel.c) | C | -476 | -121 | -117 | -714 |
| [homeStation/lib/lvgl/src/extra/widgets/colorwheel/lv_colorwheel.h](/homeStation/lib/lvgl/src/extra/widgets/colorwheel/lv_colorwheel.h) | C++ | -41 | -74 | -28 | -143 |
| [homeStation/lib/lvgl/src/extra/widgets/imgbtn/lv_imgbtn.c](/homeStation/lib/lvgl/src/extra/widgets/imgbtn/lv_imgbtn.c) | C | -245 | -79 | -63 | -387 |
| [homeStation/lib/lvgl/src/extra/widgets/imgbtn/lv_imgbtn.h](/homeStation/lib/lvgl/src/extra/widgets/imgbtn/lv_imgbtn.h) | C++ | -36 | -71 | -25 | -132 |
| [homeStation/lib/lvgl/src/extra/widgets/keyboard/lv_keyboard.c](/homeStation/lib/lvgl/src/extra/widgets/keyboard/lv_keyboard.c) | C | -271 | -101 | -59 | -431 |
| [homeStation/lib/lvgl/src/extra/widgets/keyboard/lv_keyboard.h](/homeStation/lib/lvgl/src/extra/widgets/keyboard/lv_keyboard.h) | C++ | -59 | -97 | -32 | -188 |
| [homeStation/lib/lvgl/src/extra/widgets/led/lv_led.c](/homeStation/lib/lvgl/src/extra/widgets/led/lv_led.c) | C | -112 | -73 | -37 | -222 |
| [homeStation/lib/lvgl/src/extra/widgets/led/lv_led.h](/homeStation/lib/lvgl/src/extra/widgets/led/lv_led.h) | C++ | -34 | -58 | -25 | -117 |
| [homeStation/lib/lvgl/src/extra/widgets/list/lv_list.c](/homeStation/lib/lvgl/src/extra/widgets/list/lv_list.c) | C | -70 | -28 | -23 | -121 |
| [homeStation/lib/lvgl/src/extra/widgets/list/lv_list.h](/homeStation/lib/lvgl/src/extra/widgets/list/lv_list.h) | C++ | -20 | -19 | -16 | -55 |
| [homeStation/lib/lvgl/src/extra/widgets/lv_widgets.h](/homeStation/lib/lvgl/src/extra/widgets/lv_widgets.h) | C++ | -28 | -19 | -10 | -57 |
| [homeStation/lib/lvgl/src/extra/widgets/menu/lv_menu.c](/homeStation/lib/lvgl/src/extra/widgets/menu/lv_menu.c) | C | -560 | -65 | -148 | -773 |
| [homeStation/lib/lvgl/src/extra/widgets/menu/lv_menu.h](/homeStation/lib/lvgl/src/extra/widgets/menu/lv_menu.h) | C++ | -84 | -116 | -34 | -234 |
| [homeStation/lib/lvgl/src/extra/widgets/meter/lv_meter.c](/homeStation/lib/lvgl/src/extra/widgets/meter/lv_meter.c) | C | -536 | -40 | -127 | -703 |
| [homeStation/lib/lvgl/src/extra/widgets/meter/lv_meter.h](/homeStation/lib/lvgl/src/extra/widgets/meter/lv_meter.h) | C++ | -99 | -130 | -38 | -267 |
| [homeStation/lib/lvgl/src/extra/widgets/msgbox/lv_msgbox.c](/homeStation/lib/lvgl/src/extra/widgets/msgbox/lv_msgbox.c) | C | -147 | -29 | -37 | -213 |
| [homeStation/lib/lvgl/src/extra/widgets/msgbox/lv_msgbox.h](/homeStation/lib/lvgl/src/extra/widgets/msgbox/lv_msgbox.h) | C++ | -40 | -34 | -26 | -100 |
| [homeStation/lib/lvgl/src/extra/widgets/span/lv_span.c](/homeStation/lib/lvgl/src/extra/widgets/span/lv_span.c) | C | -824 | -80 | -138 | -1,042 |
| [homeStation/lib/lvgl/src/extra/widgets/span/lv_span.h](/homeStation/lib/lvgl/src/extra/widgets/span/lv_span.h) | C++ | -65 | -140 | -41 | -246 |
| [homeStation/lib/lvgl/src/extra/widgets/spinbox/lv_spinbox.c](/homeStation/lib/lvgl/src/extra/widgets/spinbox/lv_spinbox.c) | C | -308 | -124 | -82 | -514 |
| [homeStation/lib/lvgl/src/extra/widgets/spinbox/lv_spinbox.h](/homeStation/lib/lvgl/src/extra/widgets/spinbox/lv_spinbox.h) | C++ | -44 | -106 | -33 | -183 |
| [homeStation/lib/lvgl/src/extra/widgets/spinner/lv_spinner.c](/homeStation/lib/lvgl/src/extra/widgets/spinner/lv_spinner.c) | C | -48 | -33 | -24 | -105 |
| [homeStation/lib/lvgl/src/extra/widgets/spinner/lv_spinner.h](/homeStation/lib/lvgl/src/extra/widgets/spinner/lv_spinner.h) | C++ | -17 | -20 | -14 | -51 |
| [homeStation/lib/lvgl/src/extra/widgets/tabview/lv_tabview.c](/homeStation/lib/lvgl/src/extra/widgets/tabview/lv_tabview.c) | C | -262 | -31 | -62 | -355 |
| [homeStation/lib/lvgl/src/extra/widgets/tabview/lv_tabview.h](/homeStation/lib/lvgl/src/extra/widgets/tabview/lv_tabview.h) | C++ | -27 | -19 | -20 | -66 |
| [homeStation/lib/lvgl/src/extra/widgets/tileview/lv_tileview.c](/homeStation/lib/lvgl/src/extra/widgets/tileview/lv_tileview.c) | C | -127 | -31 | -37 | -195 |
| [homeStation/lib/lvgl/src/extra/widgets/tileview/lv_tileview.h](/homeStation/lib/lvgl/src/extra/widgets/tileview/lv_tileview.h) | C++ | -27 | -27 | -19 | -73 |
| [homeStation/lib/lvgl/src/extra/widgets/win/lv_win.c](/homeStation/lib/lvgl/src/extra/widgets/win/lv_win.c) | C | -61 | -28 | -22 | -111 |
| [homeStation/lib/lvgl/src/extra/widgets/win/lv_win.h](/homeStation/lib/lvgl/src/extra/widgets/win/lv_win.h) | C++ | -19 | -19 | -14 | -52 |
| [homeStation/lib/lvgl/src/font/lv_font.c](/homeStation/lib/lvgl/src/font/lv_font.c) | C | -71 | -53 | -23 | -147 |
| [homeStation/lib/lvgl/src/font/lv_font.h](/homeStation/lib/lvgl/src/font/lv_font.h) | C++ | -146 | -61 | -55 | -262 |
| [homeStation/lib/lvgl/src/font/lv_font.mk](/homeStation/lib/lvgl/src/font/lv_font.mk) | Makefile | -33 | 0 | -4 | -37 |
| [homeStation/lib/lvgl/src/font/lv_font_dejavu_16_persian_hebrew.c](/homeStation/lib/lvgl/src/font/lv_font_dejavu_16_persian_hebrew.c) | C | -5,373 | -620 | -622 | -6,615 |
| [homeStation/lib/lvgl/src/font/lv_font_fmt_txt.c](/homeStation/lib/lvgl/src/font/lv_font_fmt_txt.c) | C | -406 | -110 | -79 | -595 |
| [homeStation/lib/lvgl/src/font/lv_font_fmt_txt.h](/homeStation/lib/lvgl/src/font/lv_font_fmt_txt.h) | C++ | -84 | -117 | -40 | -241 |
| [homeStation/lib/lvgl/src/font/lv_font_loader.c](/homeStation/lib/lvgl/src/font/lv_font_loader.c) | C | -499 | -53 | -130 | -682 |
| [homeStation/lib/lvgl/src/font/lv_font_loader.h](/homeStation/lib/lvgl/src/font/lv_font_loader.h) | C++ | -11 | -19 | -11 | -41 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_10.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_10.c) | C | -1,292 | -188 | -184 | -1,664 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_12.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_12.c) | C | -1,553 | -188 | -184 | -1,925 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_12_subpx.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_12_subpx.c) | C | -3,494 | -188 | -184 | -3,866 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_14.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_14.c) | C | -1,829 | -188 | -184 | -2,201 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_16.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_16.c) | C | -2,098 | -188 | -184 | -2,470 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_18.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_18.c) | C | -2,498 | -188 | -184 | -2,870 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_20.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_20.c) | C | -2,855 | -188 | -184 | -3,227 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_22.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_22.c) | C | -3,284 | -188 | -184 | -3,656 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_24.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_24.c) | C | -3,695 | -188 | -184 | -4,067 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_26.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_26.c) | C | -4,230 | -188 | -184 | -4,602 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_28.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_28.c) | C | -4,779 | -188 | -184 | -5,151 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_28_compressed.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_28_compressed.c) | C | -2,909 | -188 | -184 | -3,281 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_30.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_30.c) | C | -5,361 | -188 | -184 | -5,733 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_32.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_32.c) | C | -5,850 | -188 | -184 | -6,222 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_34.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_34.c) | C | -6,649 | -188 | -184 | -7,021 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_36.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_36.c) | C | -7,293 | -188 | -184 | -7,665 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_38.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_38.c) | C | -8,038 | -188 | -184 | -8,410 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_40.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_40.c) | C | -8,886 | -188 | -184 | -9,258 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_42.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_42.c) | C | -9,728 | -188 | -184 | -10,100 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_44.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_44.c) | C | -10,554 | -188 | -184 | -10,926 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_46.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_46.c) | C | -11,506 | -188 | -184 | -11,878 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_48.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_48.c) | C | -12,207 | -188 | -184 | -12,579 |
| [homeStation/lib/lvgl/src/font/lv_font_montserrat_8.c](/homeStation/lib/lvgl/src/font/lv_font_montserrat_8.c) | C | -1,078 | -188 | -184 | -1,450 |
| [homeStation/lib/lvgl/src/font/lv_font_simsun_16_cjk.c](/homeStation/lib/lvgl/src/font/lv_font_simsun_16_cjk.c) | C | -20,908 | -1,437 | -1,437 | -23,782 |
| [homeStation/lib/lvgl/src/font/lv_font_unscii_16.c](/homeStation/lib/lvgl/src/font/lv_font_unscii_16.c) | C | -414 | -120 | -119 | -653 |
| [homeStation/lib/lvgl/src/font/lv_font_unscii_8.c](/homeStation/lib/lvgl/src/font/lv_font_unscii_8.c) | C | -250 | -120 | -119 | -489 |
| [homeStation/lib/lvgl/src/font/lv_symbol_def.h](/homeStation/lib/lvgl/src/font/lv_symbol_def.h) | C++ | -260 | -22 | -72 | -354 |
| [homeStation/lib/lvgl/src/hal/lv_hal.h](/homeStation/lib/lvgl/src/hal/lv_hal.h) | C++ | -14 | -25 | -10 | -49 |
| [homeStation/lib/lvgl/src/hal/lv_hal.mk](/homeStation/lib/lvgl/src/hal/lv_hal.mk) | Makefile | -6 | 0 | -3 | -9 |
| [homeStation/lib/lvgl/src/hal/lv_hal_disp.c](/homeStation/lib/lvgl/src/hal/lv_hal_disp.c) | C | -471 | -156 | -94 | -721 |
| [homeStation/lib/lvgl/src/hal/lv_hal_disp.h](/homeStation/lib/lvgl/src/hal/lv_hal_disp.h) | C++ | -127 | -179 | -68 | -374 |
| [homeStation/lib/lvgl/src/hal/lv_hal_indev.c](/homeStation/lib/lvgl/src/hal/lv_hal_indev.c) | C | -98 | -72 | -26 | -196 |
| [homeStation/lib/lvgl/src/hal/lv_hal_indev.h](/homeStation/lib/lvgl/src/hal/lv_hal_indev.h) | C++ | -107 | -86 | -48 | -241 |
| [homeStation/lib/lvgl/src/hal/lv_hal_tick.c](/homeStation/lib/lvgl/src/hal/lv_hal_tick.c) | C | -41 | -47 | -17 | -105 |
| [homeStation/lib/lvgl/src/hal/lv_hal_tick.h](/homeStation/lib/lvgl/src/hal/lv_hal_tick.h) | C++ | -20 | -34 | -16 | -70 |
| [homeStation/lib/lvgl/src/lv_api_map.h](/homeStation/lib/lvgl/src/lv_api_map.h) | C++ | -32 | -37 | -20 | -89 |
| [homeStation/lib/lvgl/src/lv_conf_internal.h](/homeStation/lib/lvgl/src/lv_conf_internal.h) | C++ | -2,061 | -294 | -182 | -2,537 |
| [homeStation/lib/lvgl/src/lv_conf_kconfig.h](/homeStation/lib/lvgl/src/lv_conf_kconfig.h) | C++ | -134 | -27 | -22 | -183 |
| [homeStation/lib/lvgl/src/lvgl.h](/homeStation/lib/lvgl/src/lvgl.h) | C++ | -10 | -19 | -11 | -40 |
| [homeStation/lib/lvgl/src/misc/lv_anim.c](/homeStation/lib/lvgl/src/misc/lv_anim.c) | C | -305 | -84 | -82 | -471 |
| [homeStation/lib/lvgl/src/misc/lv_anim.h](/homeStation/lib/lvgl/src/misc/lv_anim.h) | C++ | -164 | -257 | -64 | -485 |
| [homeStation/lib/lvgl/src/misc/lv_anim_timeline.c](/homeStation/lib/lvgl/src/misc/lv_anim_timeline.c) | C | -124 | -31 | -44 | -199 |
| [homeStation/lib/lvgl/src/misc/lv_anim_timeline.h](/homeStation/lib/lvgl/src/misc/lv_anim_timeline.h) | C++ | -21 | -62 | -21 | -104 |
| [homeStation/lib/lvgl/src/misc/lv_area.c](/homeStation/lib/lvgl/src/misc/lv_area.c) | C | -381 | -136 | -91 | -608 |
| [homeStation/lib/lvgl/src/misc/lv_area.h](/homeStation/lib/lvgl/src/misc/lv_area.h) | C++ | -123 | -134 | -48 | -305 |
| [homeStation/lib/lvgl/src/misc/lv_assert.h](/homeStation/lib/lvgl/src/misc/lv_assert.h) | C++ | -42 | -22 | -16 | -80 |
| [homeStation/lib/lvgl/src/misc/lv_async.c](/homeStation/lib/lvgl/src/misc/lv_async.c) | C | -47 | -33 | -26 | -106 |
| [homeStation/lib/lvgl/src/misc/lv_async.h](/homeStation/lib/lvgl/src/misc/lv_async.h) | C++ | -13 | -35 | -14 | -62 |
| [homeStation/lib/lvgl/src/misc/lv_bidi.c](/homeStation/lib/lvgl/src/misc/lv_bidi.c) | C | -444 | -133 | -109 | -686 |
| [homeStation/lib/lvgl/src/misc/lv_bidi.h](/homeStation/lib/lvgl/src/misc/lv_bidi.h) | C++ | -41 | -80 | -21 | -142 |
| [homeStation/lib/lvgl/src/misc/lv_color.c](/homeStation/lib/lvgl/src/misc/lv_color.c) | C | -269 | -48 | -53 | -370 |
| [homeStation/lib/lvgl/src/misc/lv_color.h](/homeStation/lib/lvgl/src/misc/lv_color.h) | C++ | -465 | -172 | -79 | -716 |
| [homeStation/lib/lvgl/src/misc/lv_fs.c](/homeStation/lib/lvgl/src/misc/lv_fs.c) | C | -363 | -48 | -108 | -519 |
| [homeStation/lib/lvgl/src/misc/lv_fs.h](/homeStation/lib/lvgl/src/misc/lv_fs.h) | C++ | -90 | -133 | -39 | -262 |
| [homeStation/lib/lvgl/src/misc/lv_gc.c](/homeStation/lib/lvgl/src/misc/lv_gc.c) | C | -9 | -28 | -11 | -48 |
| [homeStation/lib/lvgl/src/misc/lv_gc.h](/homeStation/lib/lvgl/src/misc/lv_gc.h) | C++ | -63 | -19 | -16 | -98 |
| [homeStation/lib/lvgl/src/misc/lv_ll.c](/homeStation/lib/lvgl/src/misc/lv_ll.c) | C | -211 | -132 | -66 | -409 |
| [homeStation/lib/lvgl/src/misc/lv_ll.h](/homeStation/lib/lvgl/src/misc/lv_ll.h) | C++ | -34 | -105 | -29 | -168 |
| [homeStation/lib/lvgl/src/misc/lv_log.c](/homeStation/lib/lvgl/src/misc/lv_log.c) | C | -77 | -44 | -24 | -145 |
| [homeStation/lib/lvgl/src/misc/lv_log.h](/homeStation/lib/lvgl/src/misc/lv_log.h) | C++ | -83 | -45 | -27 | -155 |
| [homeStation/lib/lvgl/src/misc/lv_lru.c](/homeStation/lib/lvgl/src/misc/lv_lru.c) | C | -243 | -50 | -57 | -350 |
| [homeStation/lib/lvgl/src/misc/lv_lru.h](/homeStation/lib/lvgl/src/misc/lv_lru.h) | C++ | -42 | -24 | -22 | -88 |
| [homeStation/lib/lvgl/src/misc/lv_math.c](/homeStation/lib/lvgl/src/misc/lv_math.c) | C | -142 | -96 | -36 | -274 |
| [homeStation/lib/lvgl/src/misc/lv_math.h](/homeStation/lib/lvgl/src/misc/lv_math.h) | C++ | -43 | -74 | -27 | -144 |
| [homeStation/lib/lvgl/src/misc/lv_mem.c](/homeStation/lib/lvgl/src/misc/lv_mem.c) | C | -386 | -102 | -79 | -567 |
| [homeStation/lib/lvgl/src/misc/lv_mem.h](/homeStation/lib/lvgl/src/misc/lv_mem.h) | C++ | -79 | -123 | -42 | -244 |
| [homeStation/lib/lvgl/src/misc/lv_misc.mk](/homeStation/lib/lvgl/src/misc/lv_misc.mk) | Makefile | -24 | 0 | -3 | -27 |
| [homeStation/lib/lvgl/src/misc/lv_printf.c](/homeStation/lib/lvgl/src/misc/lv_printf.c) | C | -646 | -145 | -89 | -880 |
| [homeStation/lib/lvgl/src/misc/lv_printf.h](/homeStation/lib/lvgl/src/misc/lv_printf.h) | C++ | -42 | -43 | -14 | -99 |
| [homeStation/lib/lvgl/src/misc/lv_style.c](/homeStation/lib/lvgl/src/misc/lv_style.c) | C | -381 | -39 | -68 | -488 |
| [homeStation/lib/lvgl/src/misc/lv_style.h](/homeStation/lib/lvgl/src/misc/lv_style.h) | C++ | -328 | -194 | -72 | -594 |
| [homeStation/lib/lvgl/src/misc/lv_style_gen.c](/homeStation/lib/lvgl/src/misc/lv_style_gen.c) | C | -596 | 0 | -86 | -682 |
| [homeStation/lib/lvgl/src/misc/lv_style_gen.h](/homeStation/lib/lvgl/src/misc/lv_style_gen.h) | C++ | -425 | 0 | -86 | -511 |
| [homeStation/lib/lvgl/src/misc/lv_templ.c](/homeStation/lib/lvgl/src/misc/lv_templ.c) | C | -1 | -30 | -10 | -41 |
| [homeStation/lib/lvgl/src/misc/lv_templ.h](/homeStation/lib/lvgl/src/misc/lv_templ.h) | C++ | -9 | -19 | -10 | -38 |
| [homeStation/lib/lvgl/src/misc/lv_timer.c](/homeStation/lib/lvgl/src/misc/lv_timer.c) | C | -181 | -113 | -48 | -342 |
| [homeStation/lib/lvgl/src/misc/lv_timer.h](/homeStation/lib/lvgl/src/misc/lv_timer.h) | C++ | -52 | -98 | -34 | -184 |
| [homeStation/lib/lvgl/src/misc/lv_tlsf.c](/homeStation/lib/lvgl/src/misc/lv_tlsf.c) | C | -808 | -233 | -206 | -1,247 |
| [homeStation/lib/lvgl/src/misc/lv_tlsf.h](/homeStation/lib/lvgl/src/misc/lv_tlsf.h) | C++ | -36 | -45 | -15 | -96 |
| [homeStation/lib/lvgl/src/misc/lv_txt.c](/homeStation/lib/lvgl/src/misc/lv_txt.c) | C | -529 | -215 | -121 | -865 |
| [homeStation/lib/lvgl/src/misc/lv_txt.h](/homeStation/lib/lvgl/src/misc/lv_txt.h) | C++ | -75 | -154 | -36 | -265 |
| [homeStation/lib/lvgl/src/misc/lv_txt_ap.c](/homeStation/lib/lvgl/src/misc/lv_txt_ap.c) | C | -241 | -29 | -32 | -302 |
| [homeStation/lib/lvgl/src/misc/lv_txt_ap.h](/homeStation/lib/lvgl/src/misc/lv_txt_ap.h) | C++ | -19 | -19 | -12 | -50 |
| [homeStation/lib/lvgl/src/misc/lv_types.h](/homeStation/lib/lvgl/src/misc/lv_types.h) | C++ | -45 | -27 | -23 | -95 |
| [homeStation/lib/lvgl/src/misc/lv_utils.c](/homeStation/lib/lvgl/src/misc/lv_utils.c) | C | -23 | -45 | -12 | -80 |
| [homeStation/lib/lvgl/src/misc/lv_utils.h](/homeStation/lib/lvgl/src/misc/lv_utils.h) | C++ | -12 | -36 | -11 | -59 |
| [homeStation/lib/lvgl/src/widgets/lv_arc.c](/homeStation/lib/lvgl/src/widgets/lv_arc.c) | C | -695 | -119 | -207 | -1,021 |
| [homeStation/lib/lvgl/src/widgets/lv_arc.h](/homeStation/lib/lvgl/src/widgets/lv_arc.h) | C++ | -65 | -150 | -43 | -258 |
| [homeStation/lib/lvgl/src/widgets/lv_bar.c](/homeStation/lib/lvgl/src/widgets/lv_bar.c) | C | -447 | -59 | -108 | -614 |
| [homeStation/lib/lvgl/src/widgets/lv_bar.h](/homeStation/lib/lvgl/src/widgets/lv_bar.h) | C++ | -53 | -82 | -30 | -165 |
| [homeStation/lib/lvgl/src/widgets/lv_btn.c](/homeStation/lib/lvgl/src/widgets/lv_btn.c) | C | -29 | -28 | -16 | -73 |
| [homeStation/lib/lvgl/src/widgets/lv_btn.h](/homeStation/lib/lvgl/src/widgets/lv_btn.h) | C++ | -18 | -24 | -15 | -57 |
| [homeStation/lib/lvgl/src/widgets/lv_btnmatrix.c](/homeStation/lib/lvgl/src/widgets/lv_btnmatrix.c) | C | -785 | -112 | -194 | -1,091 |
| [homeStation/lib/lvgl/src/widgets/lv_btnmatrix.h](/homeStation/lib/lvgl/src/widgets/lv_btnmatrix.h) | C++ | -62 | -129 | -36 | -227 |
| [homeStation/lib/lvgl/src/widgets/lv_canvas.c](/homeStation/lib/lvgl/src/widgets/lv_canvas.c) | C | -600 | -56 | -181 | -837 |
| [homeStation/lib/lvgl/src/widgets/lv_canvas.h](/homeStation/lib/lvgl/src/widgets/lv_canvas.h) | C++ | -62 | -180 | -39 | -281 |
| [homeStation/lib/lvgl/src/widgets/lv_checkbox.c](/homeStation/lib/lvgl/src/widgets/lv_checkbox.c) | C | -180 | -35 | -50 | -265 |
| [homeStation/lib/lvgl/src/widgets/lv_checkbox.h](/homeStation/lib/lvgl/src/widgets/lv_checkbox.h) | C++ | -26 | -51 | -21 | -98 |
| [homeStation/lib/lvgl/src/widgets/lv_dropdown.c](/homeStation/lib/lvgl/src/widgets/lv_dropdown.c) | C | -875 | -80 | -202 | -1,157 |
| [homeStation/lib/lvgl/src/widgets/lv_dropdown.h](/homeStation/lib/lvgl/src/widgets/lv_dropdown.h) | C++ | -61 | -150 | -44 | -255 |
| [homeStation/lib/lvgl/src/widgets/lv_img.c](/homeStation/lib/lvgl/src/widgets/lv_img.c) | C | -508 | -61 | -124 | -693 |
| [homeStation/lib/lvgl/src/widgets/lv_img.h](/homeStation/lib/lvgl/src/widgets/lv_img.h) | C++ | -56 | -139 | -40 | -235 |
| [homeStation/lib/lvgl/src/widgets/lv_label.c](/homeStation/lib/lvgl/src/widgets/lv_label.c) | C | -949 | -119 | -207 | -1,275 |
| [homeStation/lib/lvgl/src/widgets/lv_label.h](/homeStation/lib/lvgl/src/widgets/lv_label.h) | C++ | -74 | -132 | -41 | -247 |
| [homeStation/lib/lvgl/src/widgets/lv_line.c](/homeStation/lib/lvgl/src/widgets/lv_line.c) | C | -122 | -37 | -43 | -202 |
| [homeStation/lib/lvgl/src/widgets/lv_line.h](/homeStation/lib/lvgl/src/widgets/lv_line.h) | C++ | -24 | -49 | -21 | -94 |
| [homeStation/lib/lvgl/src/widgets/lv_objx_templ.c](/homeStation/lib/lvgl/src/widgets/lv_objx_templ.c) | C | -44 | -66 | -31 | -141 |
| [homeStation/lib/lvgl/src/widgets/lv_objx_templ.h](/homeStation/lib/lvgl/src/widgets/lv_objx_templ.h) | C++ | -18 | -44 | -20 | -82 |
| [homeStation/lib/lvgl/src/widgets/lv_roller.c](/homeStation/lib/lvgl/src/widgets/lv_roller.c) | C | -544 | -126 | -120 | -790 |
| [homeStation/lib/lvgl/src/widgets/lv_roller.h](/homeStation/lib/lvgl/src/widgets/lv_roller.h) | C++ | -39 | -70 | -30 | -139 |
| [homeStation/lib/lvgl/src/widgets/lv_slider.c](/homeStation/lib/lvgl/src/widgets/lv_slider.c) | C | -338 | -51 | -59 | -448 |
| [homeStation/lib/lvgl/src/widgets/lv_slider.h](/homeStation/lib/lvgl/src/widgets/lv_slider.h) | C++ | -77 | -88 | -31 | -196 |
| [homeStation/lib/lvgl/src/widgets/lv_switch.c](/homeStation/lib/lvgl/src/widgets/lv_switch.c) | C | -174 | -51 | -53 | -278 |
| [homeStation/lib/lvgl/src/widgets/lv_switch.h](/homeStation/lib/lvgl/src/widgets/lv_switch.h) | C++ | -20 | -25 | -17 | -62 |
| [homeStation/lib/lvgl/src/widgets/lv_table.c](/homeStation/lib/lvgl/src/widgets/lv_table.c) | C | -836 | -72 | -217 | -1,125 |
| [homeStation/lib/lvgl/src/widgets/lv_table.h](/homeStation/lib/lvgl/src/widgets/lv_table.h) | C++ | -69 | -133 | -39 | -241 |
| [homeStation/lib/lvgl/src/widgets/lv_textarea.c](/homeStation/lib/lvgl/src/widgets/lv_textarea.c) | C | -970 | -134 | -267 | -1,371 |
| [homeStation/lib/lvgl/src/widgets/lv_textarea.h](/homeStation/lib/lvgl/src/widgets/lv_textarea.h) | C++ | -85 | -216 | -58 | -359 |
| [homeStation/lib/lvgl/src/widgets/lv_widgets.mk](/homeStation/lib/lvgl/src/widgets/lv_widgets.mk) | Makefile | -18 | 0 | -3 | -21 |
| [homeStation/lib/lvgl/tests/CMakeLists.txt](/homeStation/lib/lvgl/tests/CMakeLists.txt) | CMake | -351 | 0 | -27 | -378 |
| [homeStation/lib/lvgl/tests/README.md](/homeStation/lib/lvgl/tests/README.md) | Markdown | -42 | 0 | -16 | -58 |
| [homeStation/lib/lvgl/tests/config.yml](/homeStation/lib/lvgl/tests/config.yml) | YAML | -5 | 0 | -1 | -6 |
| [homeStation/lib/lvgl/tests/main.py](/homeStation/lib/lvgl/tests/main.py) | Python | -161 | -4 | -44 | -209 |
| [homeStation/lib/lvgl/tests/makefile/Makefile](/homeStation/lib/lvgl/tests/makefile/Makefile) | Makefile | -7 | 0 | -3 | -10 |
| [homeStation/lib/lvgl/tests/makefile/test.c](/homeStation/lib/lvgl/tests/makefile/test.c) | C | -8 | 0 | -2 | -10 |
| [homeStation/lib/lvgl/tests/src/lv_test_conf.h](/homeStation/lib/lvgl/tests/src/lv_test_conf.h) | C++ | -16 | -19 | -15 | -50 |
| [homeStation/lib/lvgl/tests/src/lv_test_helpers.h](/homeStation/lib/lvgl/tests/src/lv_test_helpers.h) | C++ | -15 | -2 | -7 | -24 |
| [homeStation/lib/lvgl/tests/src/lv_test_indev.c](/homeStation/lib/lvgl/tests/src/lv_test_indev.c) | C | -116 | 0 | -25 | -141 |
| [homeStation/lib/lvgl/tests/src/lv_test_indev.h](/homeStation/lib/lvgl/tests/src/lv_test_indev.h) | C++ | -31 | -8 | -16 | -55 |
| [homeStation/lib/lvgl/tests/src/lv_test_init.c](/homeStation/lib/lvgl/tests/src/lv_test_init.c) | C | -79 | 0 | -22 | -101 |
| [homeStation/lib/lvgl/tests/src/lv_test_init.h](/homeStation/lib/lvgl/tests/src/lv_test_init.h) | C++ | -13 | 0 | -8 | -21 |
| [homeStation/lib/lvgl/tests/src/test_cases/_test_template.c](/homeStation/lib/lvgl/tests/src/test_cases/_test_template.c) | C | -14 | -2 | -6 | -22 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_arc.c](/homeStation/lib/lvgl/tests/src/test_cases/test_arc.c) | C | -149 | -14 | -52 | -215 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_bar.c](/homeStation/lib/lvgl/tests/src/test_cases/test_bar.c) | C | -140 | -56 | -58 | -254 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_checkbox.c](/homeStation/lib/lvgl/tests/src/test_cases/test_checkbox.c) | C | -67 | 0 | -30 | -97 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_config.c](/homeStation/lib/lvgl/tests/src/test_cases/test_config.c) | C | -15 | 0 | -5 | -20 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_demo_stress.c](/homeStation/lib/lvgl/tests/src/test_cases/test_demo_stress.c) | C | -25 | -2 | -6 | -33 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_demo_widgets.c](/homeStation/lib/lvgl/tests/src/test_cases/test_demo_widgets.c) | C | -13 | 0 | -6 | -19 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_dropdown.c](/homeStation/lib/lvgl/tests/src/test_cases/test_dropdown.c) | C | -352 | -4 | -90 | -446 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_event.c](/homeStation/lib/lvgl/tests/src/test_cases/test_event.c) | C | -20 | -1 | -7 | -28 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_font_loader.c](/homeStation/lib/lvgl/tests/src/test_cases/test_font_loader.c) | C | -143 | -36 | -42 | -221 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_fs.c](/homeStation/lib/lvgl/tests/src/test_cases/test_fs.c) | C | -37 | -5 | -12 | -54 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_line.c](/homeStation/lib/lvgl/tests/src/test_cases/test_line.c) | C | -67 | -9 | -20 | -96 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_mem.c](/homeStation/lib/lvgl/tests/src/test_cases/test_mem.c) | C | -18 | -3 | -6 | -27 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_obj_tree.c](/homeStation/lib/lvgl/tests/src/test_cases/test_obj_tree.c) | C | -27 | -1 | -12 | -40 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_slider.c](/homeStation/lib/lvgl/tests/src/test_cases/test_slider.c) | C | -144 | -21 | -50 | -215 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_snapshot.c](/homeStation/lib/lvgl/tests/src/test_cases/test_snapshot.c) | C | -31 | 0 | -17 | -48 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_style.c](/homeStation/lib/lvgl/tests/src/test_cases/test_style.c) | C | -88 | -9 | -13 | -110 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_switch.c](/homeStation/lib/lvgl/tests/src/test_cases/test_switch.c) | C | -99 | -7 | -35 | -141 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_table.c](/homeStation/lib/lvgl/tests/src/test_cases/test_table.c) | C | -182 | -11 | -55 | -248 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_textarea.c](/homeStation/lib/lvgl/tests/src/test_cases/test_textarea.c) | C | -74 | -7 | -27 | -108 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_tiny_ttf.c](/homeStation/lib/lvgl/tests/src/test_cases/test_tiny_ttf.c) | C | -35 | -5 | -10 | -50 |
| [homeStation/lib/lvgl/tests/src/test_cases/test_txt.c](/homeStation/lib/lvgl/tests/src/test_cases/test_txt.c) | C | -146 | -1 | -61 | -208 |
| [homeStation/lib/lvgl/tests/src/test_fonts/font_1.c](/homeStation/lib/lvgl/tests/src/test_fonts/font_1.c) | C | -1,022 | -185 | -174 | -1,381 |
| [homeStation/lib/lvgl/tests/src/test_fonts/font_2.c](/homeStation/lib/lvgl/tests/src/test_fonts/font_2.c) | C | -1,052 | -185 | -174 | -1,411 |
| [homeStation/lib/lvgl/tests/src/test_fonts/font_3.c](/homeStation/lib/lvgl/tests/src/test_fonts/font_3.c) | C | -721 | -119 | -109 | -949 |
| [homeStation/lib/lvgl/tests/src/test_fonts/ubuntu_font.c](/homeStation/lib/lvgl/tests/src/test_fonts/ubuntu_font.c) | C | -11,968 | 0 | -3 | -11,971 |
| [homeStation/lib/lvgl/tests/unity/generate_test_runner.rb](/homeStation/lib/lvgl/tests/unity/generate_test_runner.rb) | Ruby | -438 | -19 | -55 | -512 |
| [homeStation/lib/lvgl/tests/unity/run_test.erb](/homeStation/lib/lvgl/tests/unity/run_test.erb) | Ruby | -35 | -2 | -1 | -38 |
| [homeStation/lib/lvgl/tests/unity/type_sanitizer.rb](/homeStation/lib/lvgl/tests/unity/type_sanitizer.rb) | Ruby | -5 | -1 | -1 | -7 |
| [homeStation/lib/lvgl/tests/unity/unity.c](/homeStation/lib/lvgl/tests/unity/unity.c) | C | -1,760 | -148 | -206 | -2,114 |
| [homeStation/lib/lvgl/tests/unity/unity.h](/homeStation/lib/lvgl/tests/unity/unity.h) | C++ | -510 | -106 | -53 | -669 |
| [homeStation/lib/lvgl/tests/unity/unity_internals.h](/homeStation/lib/lvgl/tests/unity/unity_internals.h) | C++ | -805 | -103 | -135 | -1,043 |
| [homeStation/lib/lvgl/tests/unity/unity_support.c](/homeStation/lib/lvgl/tests/unity/unity_support.c) | C | -196 | -44 | -68 | -308 |
| [homeStation/lib/lvgl/tests/unity/unity_support.h](/homeStation/lib/lvgl/tests/unity/unity_support.h) | C++ | -30 | 0 | -13 | -43 |
| [homeStation/platformio.ini](/homeStation/platformio.ini) | Ini | -4 | -9 | -2 | -15 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details