# Details

Date : 2024-11-02 16:57:04

Directory c:\\Users\\Janek\\Desktop\\inz\\ArduinoPrototype\\PIOver\\homeStation\\src

Total : 23 files,  1444 codes, 122 comments, 423 blanks, all 1989 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [homeStation/src/I2C.cpp](/homeStation/src/I2C.cpp) | C++ | 40 | 0 | 6 | 46 |
| [homeStation/src/I2C.h](/homeStation/src/I2C.h) | C++ | 8 | 5 | 4 | 17 |
| [homeStation/src/calibration.cpp](/homeStation/src/calibration.cpp) | C++ | 54 | 12 | 16 | 82 |
| [homeStation/src/calibration.h](/homeStation/src/calibration.h) | C++ | 14 | 0 | 6 | 20 |
| [homeStation/src/clock.cpp](/homeStation/src/clock.cpp) | C++ | 28 | 19 | 7 | 54 |
| [homeStation/src/clock.h](/homeStation/src/clock.h) | C++ | 14 | 0 | 5 | 19 |
| [homeStation/src/errorHandler.cpp](/homeStation/src/errorHandler.cpp) | C++ | 12 | 3 | 4 | 19 |
| [homeStation/src/errorHandler.h](/homeStation/src/errorHandler.h) | C++ | 6 | 0 | 3 | 9 |
| [homeStation/src/espnow_simplified.cpp](/homeStation/src/espnow_simplified.cpp) | C++ | 40 | 1 | 9 | 50 |
| [homeStation/src/espnow_simplified.h](/homeStation/src/espnow_simplified.h) | C++ | 48 | 0 | 11 | 59 |
| [homeStation/src/main.cpp](/homeStation/src/main.cpp) | C++ | 76 | 17 | 18 | 111 |
| [homeStation/src/ui.c](/homeStation/src/ui.c) | C | 168 | 17 | 37 | 222 |
| [homeStation/src/ui.h](/homeStation/src/ui.h) | C++ | 91 | 12 | 13 | 116 |
| [homeStation/src/ui_Garden.c](/homeStation/src/ui_Garden.c) | C | 110 | 4 | 25 | 139 |
| [homeStation/src/ui_MainMenu.c](/homeStation/src/ui_MainMenu.c) | C | 130 | 4 | 21 | 155 |
| [homeStation/src/ui_Tent.c](/homeStation/src/ui_Tent.c) | C | 145 | 4 | 28 | 177 |
| [homeStation/src/ui_comp_hook.c](/homeStation/src/ui_comp_hook.c) | C | 0 | 4 | 2 | 6 |
| [homeStation/src/ui_events.c](/homeStation/src/ui_events.c) | C | 46 | 4 | 6 | 56 |
| [homeStation/src/ui_events.h](/homeStation/src/ui_events.h) | C++ | 20 | 4 | 7 | 31 |
| [homeStation/src/ui_helpers.c](/homeStation/src/ui_helpers.c) | C | 222 | 4 | 122 | 348 |
| [homeStation/src/ui_helpers.h](/homeStation/src/ui_helpers.h) | C++ | 83 | 5 | 61 | 149 |
| [homeStation/src/wateringHandler.cpp](/homeStation/src/wateringHandler.cpp) | C++ | 73 | 2 | 9 | 84 |
| [homeStation/src/wateringHandler.h](/homeStation/src/wateringHandler.h) | C++ | 16 | 1 | 3 | 20 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)