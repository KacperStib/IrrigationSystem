#include <Arduino.h>

#define PROBE1 0
#define PROBE2 1
#define PROBE3 3

float measure(uint8_t PROBE);
float calculateAverage();