# Details

Date : 2024-11-02 16:55:55

Directory c:\\Users\\Janek\\Desktop\\inz\\ArduinoPrototype\\PIOver\\tentStation\\src

Total : 17 files,  340 codes, 71 comments, 101 blanks, all 512 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [tentStation/src/BMP.280.cpp](/tentStation/src/BMP.280.cpp) | C++ | 0 | 0 | 1 | 1 |
| [tentStation/src/BMP280.h](/tentStation/src/BMP280.h) | C++ | 0 | 0 | 1 | 1 |
| [tentStation/src/HCSR04.cpp](/tentStation/src/HCSR04.cpp) | C++ | 19 | 4 | 8 | 31 |
| [tentStation/src/HCSR04.h](/tentStation/src/HCSR04.h) | C++ | 7 | 0 | 3 | 10 |
| [tentStation/src/I2C.cpp](/tentStation/src/I2C.cpp) | C++ | 40 | 5 | 7 | 52 |
| [tentStation/src/I2C.h](/tentStation/src/I2C.h) | C++ | 8 | 5 | 4 | 17 |
| [tentStation/src/PROBES.cpp](/tentStation/src/PROBES.cpp) | C++ | 13 | 3 | 5 | 21 |
| [tentStation/src/PROBES.h](/tentStation/src/PROBES.h) | C++ | 6 | 0 | 2 | 8 |
| [tentStation/src/SHT31.cpp](/tentStation/src/SHT31.cpp) | C++ | 17 | 12 | 6 | 35 |
| [tentStation/src/SHT31.h](/tentStation/src/SHT31.h) | C++ | 18 | 0 | 3 | 21 |
| [tentStation/src/SHT41.cpp](/tentStation/src/SHT41.cpp) | C++ | 11 | 9 | 4 | 24 |
| [tentStation/src/SHT41.h](/tentStation/src/SHT41.h) | C++ | 7 | 0 | 3 | 10 |
| [tentStation/src/TSL2591.cpp](/tentStation/src/TSL2591.cpp) | C++ | 38 | 15 | 16 | 69 |
| [tentStation/src/TSL2591.h](/tentStation/src/TSL2591.h) | C++ | 24 | 0 | 7 | 31 |
| [tentStation/src/espnow_simplified.cpp](/tentStation/src/espnow_simplified.cpp) | C++ | 24 | 1 | 7 | 32 |
| [tentStation/src/espnow_simplified.h](/tentStation/src/espnow_simplified.h) | C++ | 27 | 0 | 5 | 32 |
| [tentStation/src/main.cpp](/tentStation/src/main.cpp) | C++ | 81 | 17 | 19 | 117 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)