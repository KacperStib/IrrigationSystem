# Summary

Date : 2024-11-02 16:55:55

Directory c:\\Users\\Janek\\Desktop\\inz\\ArduinoPrototype\\PIOver\\tentStation\\src

Total : 17 files,  340 codes, 71 comments, 101 blanks, all 512 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C++ | 17 | 340 | 71 | 101 | 512 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 17 | 340 | 71 | 101 | 512 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)