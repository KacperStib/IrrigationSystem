// pinout
#define VALVE1 10
#define VALVE2 9
#define VALVE3 8
#define VALVE4 7
#define RAIN_SENSOR 4

// in minutes
#define WATERING_TIME 10
#define RAIN_DELAY 480 // 8 hours
